package stepDefinitions;

import java.awt.AWTException;
import java.io.IOException;

import com.FedEx.GeminiAutomationSG.PageObjects.CustomerProfilePage;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;
import com.FedEx.GeminiAutomationSG.Utilities.ApplicationFunctions;
import com.FedEx.GeminiAutomationSG.Utilities.ExcelUtility;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CustomerProfile extends BaseClass {
	
	CustomerProfilePage customerProfilePage = new CustomerProfilePage(driver);
	ApplicationFunctions applicationFunctions = new ApplicationFunctions(driver);
	ExcelUtility excelUtility = new ExcelUtility();

	@Given("Select Role as {string}")
	public void select_role_as(String role) {
		customerProfilePage.select_Role(role);
	}

	@Given("Click on Create New Importer icon")
	public void click_on_create_new_importer_icon() {
		customerProfilePage.click_CreateNewImporter_Button();
	}

	@Given("Click on Consignee icon")
	public void click_on_consignee_icon() {
		customerProfilePage.click_Consignee_Icon();
	}

	@Given("Enter Company Name as {string}, {string} , {string}")
	public void enter_company_name_as(String sheetName, String columnName, String rowIndex) throws IOException {
		System.out.println(excelUtility.readExcelValue(sheetName, columnName, rowIndex));
		customerProfilePage.set_CompanyName(excelUtility.readExcelValue(sheetName, columnName, rowIndex));
	}

	@Given("Enter Address Line1 as {string}, {string} , {string}")
	public void enter_address_line1_as(String sheetName, String columnName1, String rowIndex) throws IOException {
		customerProfilePage.set_AddressLine(excelUtility.readExcelValue(sheetName,columnName1 , rowIndex));
	}
	@Given("Enter City as {string}, {string} , {string}")
	public void enter_city_as(String sheetName, String columnName2, String rowIndex) throws IOException {
		customerProfilePage.set_City(excelUtility.readExcelValue(sheetName, columnName2, rowIndex));
	}
	
	@Given("Enter Postal Code as {string}, {string} , {string}")
	public void enter_postal_code_as(String sheetName, String columnName3, String rowIndex) throws IOException {
		customerProfilePage.set_PostalCode(excelUtility.readExcelValue(sheetName, columnName3, rowIndex));
	}
	
	@Given("Select Country as {string}")
	public void select_country_as(String value) {
		customerProfilePage.select_Country(value);;
	}
	
	@Given("Select Language Pref as {string}, {string} , {string}")
	public void select_language_pref_as(String sheetName, String columnName4, String rowIndex) throws IOException {
		customerProfilePage.select_LanguagePref(excelUtility.readExcelValue(sheetName, columnName4, rowIndex));
	}
	
	@Given("Click on Save button")
	public void click_on_save_button() {
		customerProfilePage.click_Save_Button();
	}

	@Given("Click on Add Linked Profiles icon")
	public void click_on_add_linked_profiles_icon() {
		customerProfilePage.click_AddLinkedProfiles_Icon();
	}

	@Given("Select Linked Profile Role as {string}")
	public void select_linked_profile_role_as(String linkedProfilesRole) {
		customerProfilePage.select_LinkedProfiles_Role(linkedProfilesRole);
	}

	@Given("Click on Add Linked Profiles Link")
	public void click_on_add_linked_profiles_link() {
		customerProfilePage.click_AddLinkedProfiles_Link();
	}

	@Then("Enter Search Profile Company Name as {string}, {string} , {string}")
	public void enter_search_profile_company_name_as(String sheetName, String columnName5, String rowIndex) throws IOException {
		customerProfilePage.set_SearchProfile_CompanyName(excelUtility.readExcelValue(sheetName, columnName5, rowIndex));
	}

	@Given("Click on Go button")
	public void click_on_go_button() {
		customerProfilePage.click_Go_Button();
	}

	@Given("Select First Card")
	public void select_first_card() {
		customerProfilePage.select_First_Card();
	}

	@Given("Click on Save Profile button")
	public void click_on_save_profile_button() {
		customerProfilePage.click_Save_LinkedProfiles_Button();
	}

	@Given("Click on Save Customer Profile button")
	public void click_on_save_customer_profile_button() {
		customerProfilePage.click_Save_CustomerProfile_Button();
	}

	@Then("Verify ToasterMessage {string}")
	public void verify_toastermessage(String message) {
		applicationFunctions = new ApplicationFunctions(driver);
		applicationFunctions.verify_ToasterMessage();
	}

	@Given("Enter Company Name as {string}")
	public void enter_company_name_as(String companyName) {
		customerProfilePage = new CustomerProfilePage(driver);
		customerProfilePage.enter_CompanyName(companyName);
	}

	@Given("Click on Search icon")
	public void click_on_search_icon() {
		customerProfilePage.click_Search_Button();
	}

	@Given("Click on Edit icon")
	public void click_on_edit_icon() {
		customerProfilePage.click_CustomerProfile_Edit_Button();
	}

	@Then("Verify Confirmation Thershold {string} and Payment Threshold {string} field accept decimal values")
	public void verify_confirmation_thershold_and_payment_threshold_field_accept_decimal_values(
			String confirmationThershold, String paymentThreshold) {
		customerProfilePage.set_ConfirmationThershold(confirmationThershold);
		customerProfilePage.set_PaymentThreshold(paymentThreshold);
	}
	
	@Given("Select any row")
	public void select_any_row() {
		customerProfilePage.selectAnyRow();
	}
	
	@Given("Select Alias as {string}")
	public void select_alias_as(String role) {
		customerProfilePage.selectAlias(role);
	}
	
	@And("Validate default displayed field {string}")
	public void Validate_default_displayed_field(String fieldName) throws AWTException {
		customerProfilePage.validateDefaultDisplayedField(fieldName);
	}
	
	@And("Click on Alias Icon")
	public void Click_on_Alias_Icon() {
		customerProfilePage.clickAliasIcon();
	}
	
	@And("Delete the Alias")
	public void Delete_the_Alias() {
		customerProfilePage.deleteAlias();
	}
	
}
