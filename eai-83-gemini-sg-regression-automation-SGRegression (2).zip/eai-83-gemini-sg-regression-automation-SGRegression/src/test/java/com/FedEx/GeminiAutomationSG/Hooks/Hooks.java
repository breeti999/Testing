package com.FedEx.GeminiAutomationSG.Hooks;

import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;

public class Hooks extends BaseClass {

	@AfterStep
	public void as(Scenario scenario) throws IOException, InterruptedException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
		scenario.attach(screenshot, "image/png", scenario.toString());
	}

	@After
	public void takeScreenShotOnFailedScenario(Scenario scenario) {
		System.out.println("This is from After hook");
		if ((scenario.isFailed())) {
			TakesScreenshot ts = (TakesScreenshot) driver;
			byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshot, "image/png", scenario.getName());
		}
		driver.quit();
	}

}
