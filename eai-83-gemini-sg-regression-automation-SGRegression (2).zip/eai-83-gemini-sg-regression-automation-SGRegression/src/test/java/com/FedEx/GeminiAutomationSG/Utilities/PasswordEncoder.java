package com.FedEx.GeminiAutomationSG.Utilities;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class PasswordEncoder {

	public static void main(String[] args) {

		String value = "Ragu2031";

		byte[] bytes = value.getBytes();
		byte[] encoded = Base64.getEncoder().encode(bytes);
		String encodedValue = new String(encoded, StandardCharsets.UTF_8);
		System.out.println(encodedValue);
		
	}

}
