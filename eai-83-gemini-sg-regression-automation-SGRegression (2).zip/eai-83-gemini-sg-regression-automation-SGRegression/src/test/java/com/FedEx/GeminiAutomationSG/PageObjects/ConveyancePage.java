package com.FedEx.GeminiAutomationSG.PageObjects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.validator.GenericValidator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class ConveyancePage extends BaseClass {

	public HashMap<Integer, String> hmap;
	
	// ==================== CONSTRUCTOR ==================== //
	public ConveyancePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@FindBy(xpath = "//input[@name='conveyanceNumber']")
	WebElement conveyanceNumber_TxtBx;

	@FindBy(xpath = "//select[@name='dateType']")
	WebElement dateType_Dpdn;
	
	@FindBy(xpath = "//button[@title='Search']")
	public WebElement conveyance_search;

	@FindBy(id = "fx-gn-search-conveyance-icon")
	WebElement search_Icn;

	@FindBy(xpath = "(//datatable-body-cell[contains(@class,'datatable-body-cell')])[1]")
	WebElement first_Row_Data;

	@FindBy(id = "Conveyance-Date-0")
	public WebElement conveyanceDate_Txt;

	@FindBy(id = "conveyance-open-popup")
	WebElement edit_Icn;

	@FindBy(xpath = "//h3[text()='Modify Conveyance Details']")
	WebElement modifyConveyanceDetails_Hdr;

	@FindBy(xpath = "//div[contains(text(),'Please wait until we load data')]")
	WebElement pleaseWaitUntilWeLoadData_Txt;

	@FindBy(xpath = "//input[@name='flightNumber']")
	WebElement flightNumber_TxtBx;

	@FindBy(xpath = "//select[@name='originport']")
	WebElement originPort_Dpdn;

	@FindBy(xpath = "//select[@name='originDepLocation']")
	WebElement originDepartingLocation_Dpdn;

	@FindBy(xpath = "//select[@name='Finalclearencelocation']")
	WebElement finalClearenceLocation_Dpdn;

	@FindBy(xpath = "//input[@name='mawb']")
	WebElement MAWB_TxtBx;

	@FindBy(xpath = "//select[@name='modeoftransport']")
	WebElement modeOfTransport_Dpdn;

	@FindBy(xpath = "//button[@title='Submit']")
	public 	WebElement submit_Btn;

	@FindBy(id = "cancel")
	WebElement cancel_Btn;
	
	@FindBy(xpath = "//select[@name='originport']/option")
	List<WebElement> OriginPort_list;
	
	@FindBy(xpath = "//select[@name='originDepLocation']/option")
	List<WebElement> OriginDeparting_list;
	
	
	

	// ==================== ACTION METHODS ===================//
	public void set_ConveyanceNumber(String value) {
		waitTillElementVisible(conveyanceNumber_TxtBx);
		conveyanceNumber_TxtBx.sendKeys(value);
	}

	public void verify_DateType_Dropdown() {
		waitTillElementVisible(dateType_Dpdn);
		List<String> expectedDropDownValues = new ArrayList<String>();
		expectedDropDownValues.addAll(Arrays.asList("Select", "Route Arrival", "Operational", "Conveyance Date"));
		Select entriesDropDown = new Select(dateType_Dpdn);
		List<WebElement> actualDropDownValues = entriesDropDown.getOptions();
		for (int i = 0; i < actualDropDownValues.size(); i++) {
			if (actualDropDownValues.get(i).getText().contains(expectedDropDownValues.get(i).toString())) {
				log.info("Value Matching :" + "Actual Value: " + actualDropDownValues.get(i).getText()
						+ " and Expected Value: " + expectedDropDownValues.get(i));
			} else {
				
				log.info("Value are not Matching: " + "Actual Value: " + actualDropDownValues.get(i).getText()
						+ " and Expected Value: " + expectedDropDownValues.get(i));
				Assert.fail();
			}
		}
	}

	public void select_DateType(String value) {
		selectUsingVisibleText(dateType_Dpdn, value);
	}

	public void click_Search_Icon() throws InterruptedException {
		waitTillElementVisible(search_Icn);
		search_Icn.click();
		Thread.sleep(5000);
		search_Icn.click();
		Thread.sleep(5000);
	}

	public void select_Row() {
		first_Row_Data.click();
	}

	public void verify_DateFormat() {
		waitTillElementVisible(conveyanceDate_Txt);
		Assert.assertTrue(GenericValidator.isDate(conveyanceDate_Txt.getText(), "dd/MM/yyyy", true));
	}

	public void click_Edit_Icon() {
		waitTillElementVisible(edit_Icn);
		scrollIntoViewUsingJavaScript(edit_Icn);
		clickElementUsingJavaScript(edit_Icn);
		waitTillElementInVisible(pleaseWaitUntilWeLoadData_Txt, 120);
	}

	public void set_FlightNumber(String value) {
		waitTillElementVisible(flightNumber_TxtBx);
		flightNumber_TxtBx.clear();
		flightNumber_TxtBx.click();
		enterValueIntoTextField(flightNumber_TxtBx, value);
	}

	public void select_OriginPort() {
		waitTillElementVisible(originPort_Dpdn);
		hmap = new HashMap<>();
		int i=1;
		for (WebElement txt : OriginPort_list) {
			hmap.put(i,txt.getText());
			i++;
		}
		System.out.println(hmap);
		Object[] arraylist = hmap.keySet().toArray();
		Object key = arraylist[new Random().nextInt(arraylist.length)];
		System.err.println("select_OriginPort:"+hmap.get(key));
		selectUsingVisibleText(originPort_Dpdn, hmap.get(key));
		
	}

	public void select_OriginDepartingLocation() throws InterruptedException {
		Thread.sleep(5000);
		waitTillElementVisible(originDepartingLocation_Dpdn);
		hmap = new HashMap<Integer,String>();
		int i=1;
		for (WebElement txt : OriginDeparting_list) {
			hmap.put(i,txt.getText());
			i++;
		}		
		Object[] arraylist = hmap.keySet().toArray();
		Object key = arraylist[new Random().nextInt(arraylist.length)];
		System.err.println("OriginDepartingLocation :"+hmap.get(key));
		if(hmap.get(key).equalsIgnoreCase("Select")) {
			selectUsingVisibleText(originDepartingLocation_Dpdn, hmap.get(2));
			System.err.println("OriginDepartingLocation- *Selecting next possible element* :"+hmap.get(2));
		}
		selectUsingVisibleText(originDepartingLocation_Dpdn, hmap.get(key));
		
	}

	public void set_MAWB(String value) {
		waitTillElementVisible(MAWB_TxtBx);
		MAWB_TxtBx.clear();
		MAWB_TxtBx.click();
		enterValueIntoTextField(MAWB_TxtBx, value);
	}

	public void click_Submit_Button() {
		clickElement(submit_Btn);
	}

	public void verify_Fields_Displayed_Under_ModifyConveyanceDetails_PopUp() {
		checkElementIsVisible(modifyConveyanceDetails_Hdr);
		checkElementIsVisible(flightNumber_TxtBx);
		checkElementIsVisible(originPort_Dpdn);
		checkElementIsVisible(finalClearenceLocation_Dpdn);
		checkElementIsVisible(MAWB_TxtBx);
		checkElementIsVisible(modeOfTransport_Dpdn);
//		clickElementUsingJavaScript(cancel_Btn);
	}

	public void validate_DataBase() throws ClassNotFoundException, SQLException {
		String DB_URL = "udba0133.ute.apac.fedex.com";
		String DB_USER = "GEMINI_SCHEMA";
		String DB_PASSWORD = "EQHnUdIVhqGmfvEe5OKvVAfdn";
		String Query = "select * from IB_CONVC_INFO where CONVC_DT='20230316' and CONVC_NBR='SM015";
		Class.forName("com.oracle.jdbc.Driver");
		Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(Query);
		while (rs.next()) {
			System.out.println("DB Connected");
		}
	}

}
