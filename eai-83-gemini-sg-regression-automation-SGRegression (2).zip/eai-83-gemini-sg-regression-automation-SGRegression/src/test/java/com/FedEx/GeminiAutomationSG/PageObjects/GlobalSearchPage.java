package com.FedEx.GeminiAutomationSG.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

import groovyjarjarantlr4.v4.codegen.model.ThrowEarlyExitException;

public class GlobalSearchPage extends BaseClass {

	public GlobalSearchPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public static String FirstAWBGS;

	// Web Elements
	@FindBy(id = "fx-gn-header-search-icon")
	public WebElement iconEntryGlobalSearch;

	@FindBy(id = "fx-gn-shipment-search-value")
	public WebElement txtEntryShipmentValue;

	@FindBy(xpath = "(//span[contains(@class,'shipment-result')])[1]")
	public WebElement iconShipmentSearch;

	@FindBy(id = "fx-gn-data-grid-select-all-toggle-global-component")
	public WebElement tgleShipmentAll;

	@FindBy(xpath = "//div[@title='Close']")
	public WebElement iconShipmentSearchClose;

	@FindBy(id = "AWB-0")
	public WebElement firstRecordAWB;

	// Action Methods
	public void click_entryGlobalSearch() {
		waitTillElementVisible(iconEntryGlobalSearch);
		scrollIntoViewUsingJavaScript(iconEntryGlobalSearch);
		clickElementUsingJavaScript(iconEntryGlobalSearch);
	}

	public void enter_shipmentValue(String value) throws InterruptedException {
//		enterValueIntoTextField(txtEntryShipmentValue, value);
		try {
			System.out.println("Excel value:" + value);
			waitTillElementVisible(txtEntryShipmentValue);
			//txtEntryShipmentValue.sendKeys(value + " ");
			//txtEntryShipmentValue.clear();
			txtEntryShipmentValue.sendKeys(value + " ");
			Thread.sleep(2000);
			System.out.println("******************** After Excel value:" + value);
			String[] arrSplit = value.split(",");
		    FirstAWBGS = arrSplit[0];
		    log.info(FirstAWBGS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_entryShipmentSearch() throws InterruptedException {
		elementToBeClickable(iconShipmentSearch);
		clickElement(iconShipmentSearch);
		Thread.sleep(3000);
	}

	public void validate_ShipmentSelected() throws InterruptedException {
		try {
			tgleShipmentAll.isSelected();
		} catch (Exception  e) {
			e.printStackTrace();
			throw e;
			
		}
	}

	public void click_entryShipmentSearchClose() throws InterruptedException {
		clickElement(iconShipmentSearchClose);
	}

	public void click_firstRecordAWB() throws InterruptedException {
		checkElementIsVisible(firstRecordAWB);
		clickElement(firstRecordAWB);
	}

	public String get_firstRecordAWB() throws InterruptedException {
		checkElementIsVisible(firstRecordAWB);
		return firstRecordAWB.getText();
	}

}
