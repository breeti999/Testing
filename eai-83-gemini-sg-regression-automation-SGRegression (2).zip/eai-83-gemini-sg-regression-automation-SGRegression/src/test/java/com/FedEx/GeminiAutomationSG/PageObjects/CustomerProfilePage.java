package com.FedEx.GeminiAutomationSG.PageObjects;

import java.awt.AWTException;

import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class CustomerProfilePage extends BaseClass {

	// ==================== CONSTRUCTOR ==================== //
	public CustomerProfilePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@FindBy(xpath = "//select[@name='role']")
	WebElement role_Dpdn;

	@FindBy(xpath = "//*[@title='Create New Importer']")
	WebElement createNewImporter_Btn;

	@FindBy(xpath = "//input[@id='fx-gn-master-consignee']")
	WebElement consignee_Icn;

	@FindBy(xpath = "//input[@id='fx-gn-master-companyName']")
	WebElement companyName_TxtBx;

	@FindBy(xpath = "//input[@id='fx-gn-contact-detail-street1']")
	WebElement addressLine_TxtBx;

	@FindBy(xpath = "//input[@id='fx-gn-contact-detail-city']")
	WebElement city_TxtBx;

	@FindBy(xpath = "//input[@id='fx-gn-contact-detail-zip']")
	WebElement postalCode_TxtBx;
	
	@FindBy(xpath = "//select[@id='fx-gn-contact-detail-country']")
	WebElement country_Dpdn;

	@FindBy(xpath = "//select[@id='fx-gn-contact-detail-languagePref']")
	WebElement languagePref_Dpdn;

	@FindBy(xpath = "//button[@id='fx-gn-contact-save']")
	WebElement save_Btn;

	@FindBy(xpath = "//button[@id='add_linked_profiles_icon']")
	WebElement addLinkedProfiles_Icn;

	@FindBy(xpath = "//select[@id='fx-gn-linked-profile-role']")
	WebElement linkedProfilesRole_Dpdn;

	@FindBy(xpath = "//a[@id='add_linked_profiles_icon']")
	WebElement addLinkedProfiles_Lnk;

	@FindBy(xpath = "//input[@id='fx-gn-customer-search-companyName']")
	WebElement searchProfileCompanyName_TxtBx;

	@FindBy(xpath = "//button[@id='fx-gn-consignee-search-btn']")
	WebElement Go_Btn;

	@FindBy(css = "//div[@class='page-spinner-border page-spinner-border-sm ng-star-inserted']")
	private WebElement spinner_Icn;

	@FindBy(xpath = "(//div[@id='searchProfileResult']//div)[1]")
	WebElement selectFirstCard;

	@FindBy(xpath = "//button[@id='fx-gn-linked-profile-save']")
	WebElement saveLinkedProfiles_Btn;

	@FindBy(xpath = "//button[@id='fx-gn-cp-save']")
	WebElement saveCustomerProfile_Btn;

	@FindBy(xpath = "//input[@id='fx-gn-customer-profile-search-companyName']")
	WebElement CompanyName_TxtBx;

	@FindBy(xpath = "//a[@title='Search']")
	WebElement search_Btn;

	@FindBy(id = "Company-0")
	WebElement first_Row;

	@FindBy(xpath = "//a[@id='edit_customer-profile']")
	WebElement edit_CustomerProfile_Btn;

	@FindBy(xpath = "//span[text()='Billing Information']")
	WebElement billingInformation_Hdr;

	@FindBy(xpath = "//input[@name='confirmationThreshold']")
	WebElement confirmationThershold_TxtBx;

	@FindBy(xpath = "//input[@name='creditLimit']")
	WebElement paymentThreshold_TxtBx;
	
	@FindBy(xpath = "//input[@id='fx-gn-customer-profile-search-companyName']")
	public WebElement txtBx_CustomerProfileCompanyName;
	
	@FindBy(xpath = "//select[@name='aliasFlg']")
	public WebElement dpdn_alias;
	
	@FindBy(xpath="//li[@class='selected-role ng-star-inserted']//label")
	public WebElement default_displayed_field;
	
	@FindBy(xpath="//button[@id='alias_linked_profiles_icon']")
	WebElement aliasIcon;
	
	@FindBy(xpath="//a[@class='delete_rule delete_linked-profile-alias']") 
	public WebElement deleteAliasIcon;

	@FindBy(css = "div.toast-message.ng-star-inserted")
	WebElement toaster_Message;

	@FindBy(xpath = "//div[contains(text(),'Please wait while your data is loading')]")
	WebElement txt_WaitForDataLoading;

	@FindBy(xpath = "//div[@class='visible']")
	public WebElement tbl_GridData;

	// ==================== ACTION METHODS ===================//
	public void select_Role(String role) {
		selectUsingVisibleText(role_Dpdn, role);
	}

	public void click_CreateNewImporter_Button() {
		clickElementUsingJavaScript(createNewImporter_Btn);
	}

	public void click_Consignee_Icon() {
		clickElement(consignee_Icn);
	}

	public void set_CompanyName(String value) {
		enterValueIntoTextField(companyName_TxtBx, value);
		companyName_TxtBx.sendKeys(Keys.TAB);
	}

	public void set_AddressLine(String value) {
		enterValueIntoTextField(addressLine_TxtBx, value);
	}

	public void set_City(String value) {
		enterValueIntoTextField(city_TxtBx, value);
	}

	public void set_PostalCode(String value) {
		enterValueIntoTextField(postalCode_TxtBx, value);
	}

	public void select_Country(String value) {
		country_Dpdn.click();
		selectUsingVisibleText(country_Dpdn, value);
		country_Dpdn.sendKeys(Keys.TAB);
	}
	
	public void select_LanguagePref(String value) {
		selectUsingVisibleText(languagePref_Dpdn, value);
	}

	public void click_Save_Button() {
		clickElement(save_Btn);
	}

	public void click_AddLinkedProfiles_Icon() {
		clickElement(addLinkedProfiles_Icn);
	}

	public void select_LinkedProfiles_Role(String linkedProfilesRole) {
		selectUsingVisibleText(linkedProfilesRole_Dpdn, linkedProfilesRole);
	}

	public void click_AddLinkedProfiles_Link() {
		clickElement(addLinkedProfiles_Lnk);
	}

	public void set_SearchProfile_CompanyName(String value) {
		enterValueIntoTextField(searchProfileCompanyName_TxtBx, value);
	}

	public void click_Go_Button() {
		clickElement(Go_Btn);
		waitTillElementInVisible(spinner_Icn, 150);
	}

	public void select_First_Card() {
		clickElement(selectFirstCard);
	}

	public void click_Save_LinkedProfiles_Button() {
		clickElementUsingJavaScript(saveLinkedProfiles_Btn);
	}

	public void click_Save_CustomerProfile_Button() {
		scrollIntoViewUsingJavaScript(saveCustomerProfile_Btn);
		clickElementUsingJavaScript(saveCustomerProfile_Btn);
	}

	public void enter_CompanyName(String value) {
		enterValueIntoTextField(CompanyName_TxtBx, value);
	}

	public void click_Search_Button() {
		clickElement(search_Btn);
		waitTillElementInVisible(txt_WaitForDataLoading, 150);
	}

	public void click_CustomerProfile_Edit_Button() {
		clickElement(edit_CustomerProfile_Btn);
//		waitTillElementVisible(billingInformation_Hdr, 150);
	}

	public void set_ConfirmationThershold(String value) {
		enterValueIntoTextField(confirmationThershold_TxtBx, value);
	}

	public void set_PaymentThreshold(String value) {
		enterValueIntoTextField(paymentThreshold_TxtBx, value);
	}
	
	public void setCustomerProfileCompanyName(String companyName) {
		try {
		txtBx_CustomerProfileCompanyName.sendKeys(companyName);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectAnyRow() {
		try {
		first_Row.click();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void selectAlias(String alias) {
		try {
		selectUsingVisibleText(dpdn_alias, alias);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void validateDefaultDisplayedField(String fieldName) throws AWTException {
		zoomOutUsingRobotClass();
		try {
			Thread.sleep(2000);
			if(default_displayed_field.getText().trim().equalsIgnoreCase(fieldName)) {
				System.out.println(default_displayed_field.getText().trim());
			}
			else {
				Assert.fail();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickAliasIcon() {
		try {
			aliasIcon.click();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteAlias() {
		try {
			deleteAliasIcon.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
