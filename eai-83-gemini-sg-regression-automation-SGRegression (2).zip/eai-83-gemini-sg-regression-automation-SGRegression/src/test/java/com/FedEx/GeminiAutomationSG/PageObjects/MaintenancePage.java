package com.FedEx.GeminiAutomationSG.PageObjects;

import java.awt.AWTException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;
import org.testng.*;

public class MaintenancePage extends BaseClass {

	// ==================== CONSTRUCTOR ==================== //
	public MaintenancePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	// Sanity Rules Maintenance
	@FindBy(id = "create_rule")
	public WebElement create_Btn;

	@FindBy(xpath = "//div[@class='ui-multiselect-label-container']/span")
	public WebElement clearanceScheme_Dpdn;

	@FindBy(xpath = "//div[@class='ui-dropdown-label-container']//input")
	public WebElement sanityGroup_Dpdn;

	@FindBy(xpath = "(//button[@class='btn btn-outline-secondary calendar'])[1]")
	public WebElement validFrom_Dt;

	@FindBy(xpath = "(//button[@class='btn btn-outline-secondary calendar'])[2]")
	public WebElement validTo_Dt;

	@FindBy(xpath = "//select[@aria-label='Select month']")
	public WebElement month_Dpdn;

	@FindBy(xpath = "//select[@aria-label='Select year']")
	public WebElement year_Dpdn;

	@FindBy(xpath = "//select[@id='fx-gn-sanity-rule-create-status']")
	public WebElement status_Dpdn;

	@FindBy(name = "ruleName")
	public WebElement sanity_RuleName_TxtBx;

	@FindBy(name = "ruleDescription")
	public WebElement sanity_RuleDescription_TxtBx;

	@FindBy(xpath = "//select[@name='booleanRelation']")
	public WebElement ruleCondition_Dpdn;

	@FindBy(xpath = "//select[@name='parameter']")
	public WebElement parameter_Dpdn;

	@FindBy(xpath = "//select[@name='operator']")
	public WebElement condition_Dpdn;

	@FindBy(name = "expectValue")
	public WebElement expect_Value;

	@FindBy(id = "add-sibling-node")
	public WebElement addSiblingCondition_Icn;

	@FindBy(id = "btnSubmit")
	public WebElement submit_Btn;

	@FindBy(id = "cancel")
	public WebElement cancel_Btn;

	@FindBy(id = "edit_rule")
	public WebElement edit_Btn;

	@FindBy(id = "delete_rule")
	public WebElement delete_Btn;

	@FindBy(id = "Rule-Name-0")
	public WebElement first_Record_SanityRule;

	// Team Rules Maintenance
	@FindBy(name = "teamName")
	public WebElement team_RuleName_TxtBx;

	@FindBy(name = "teamDesc")
	public WebElement team_RuleDescription_TxtBx;

	@FindBy(id = "Team-Name-0")
	public WebElement first_Record_TeamRule;

	// User Roles
	@FindBy(id = "fx-gn-user-role-search-userId")
	public WebElement userID_TxtBx;

	@FindBy(id = "fx-gn-create-user__select-team-toggle-")
	public WebElement selectAllTeams_ChkBx;

	@FindBy(id = "fx-gn-user-maintenance")
	public WebElement assign_Btn;

	@FindBy(xpath = "//div[contains(text(),'BSO')]")
	public WebElement BSO_Txt;

	@FindBy(xpath = "//div[contains(text(),'BSO')]//a")
	public WebElement BSO_Close_Icn;

	@FindBy(id = "fx-gn-user-maintenance-save")
	public WebElement save_Btn;

	// ==================== ACTION METHODS ===================//
	public void click_Create_Button() throws AWTException, InterruptedException {
		Thread.sleep(30000);
		clickElementUsingJavaScript(create_Btn);
		zoomOutUsingRobotClass();
	}

	public void set_ClearanceScheme(String clearanceScheme) {
		waitTillElementVisible(clearanceScheme_Dpdn);
		clearanceScheme_Dpdn.click();
		driver.findElement(By.xpath("//li[@aria-label='LV']")).click();
		clearanceScheme_Dpdn.click();
	}

	public void set_SanityGroup(String sanityGroup) {
		waitTillElementVisible(sanityGroup_Dpdn);
		sanityGroup_Dpdn.sendKeys(sanityGroup);
	}

	public void set_SanityRule_ValidFrom_Date() {
		waitTillElementVisible(validFrom_Dt);
		validFrom_Dt.click();
	}

	public void set_SanityRule_ValidTo_Date() {
		waitTillElementVisible(validTo_Dt);
		validTo_Dt.click();
	}

	public void select_Status(String status) {
		waitTillElementVisible(status_Dpdn);
		selectUsingVisibleText(status_Dpdn, status);
	}

	public void set_SanityRuleName(String ruleName) {
		waitTillElementVisible(sanity_RuleName_TxtBx);
		sanity_RuleName_TxtBx.sendKeys(ruleName);
	}

	public String get_SanityRuleName() {
		waitTillElementVisible(sanity_RuleName_TxtBx);
		return sanity_RuleName_TxtBx.getText();
	}

	public void set_SanityRuleDescription(String ruleDescription) {
		waitTillElementVisible(sanity_RuleDescription_TxtBx);
		sanity_RuleDescription_TxtBx.clear();
		sanity_RuleDescription_TxtBx.sendKeys(ruleDescription);
	}

	public void select_RuleCondition(String ruleCondition) {
		waitTillElementVisible(ruleCondition_Dpdn);
		selectUsingVisibleText(ruleCondition_Dpdn, ruleCondition);
	}

	public void select_Parameter(String parameter) {
		waitTillElementVisible(parameter_Dpdn);
		selectUsingVisibleText(parameter_Dpdn, parameter);
	}

	public void select_Condition(String condition) {
		waitTillElementVisible(condition_Dpdn);
		selectUsingVisibleText(condition_Dpdn, condition);
	}

	public void set_Value(String value) {
		waitTillElementVisible(expect_Value);
		expect_Value.sendKeys(value);
	}

	public void click_AddSiblingCondition_Icon() {
		waitTillElementVisible(addSiblingCondition_Icn);
		addSiblingCondition_Icn.click();
	}

	public void click_Submit_Button() {
		waitTillElementVisible(submit_Btn);
		submit_Btn.click();
	}

	public void click_Cancel_Button() {
		waitTillElementVisible(cancel_Btn);
		cancel_Btn.click();
	}

	// Team Rules
	public void set_TeamRule_ValidFrom_Date() {
		waitTillElementVisible(validFrom_Dt);
		validFrom_Dt.click();
	}

	public void set_TeamRule_ValidTo_Date() {
		waitTillElementVisible(validTo_Dt);
		validTo_Dt.click();
	}

	public void set_Team_RuleName(String ruleName) {
		waitTillElementVisible(team_RuleName_TxtBx);
		team_RuleName_TxtBx.sendKeys(ruleName);
	}

	public String get_Team_RuleName() {
		waitTillElementVisible(team_RuleName_TxtBx);
		return team_RuleName_TxtBx.getText();
	}

	public void set_Team_RuleDescription(String ruleDescription) {
		waitTillElementVisible(team_RuleDescription_TxtBx);
		team_RuleDescription_TxtBx.clear();
		team_RuleDescription_TxtBx.sendKeys(ruleDescription);
	}

	public String get_Team_RuleDescription() {
		waitTillElementVisible(team_RuleDescription_TxtBx);
		return team_RuleDescription_TxtBx.getText();
	}

	public void click_Edit_Button() {
		waitTillElementVisible(edit_Btn);
		edit_Btn.click();
	}

	public void click_Delete_Button() {
		waitTillElementVisible(delete_Btn);
		delete_Btn.click();
	}

	public String get_FirstRecordSanityRule() {
		waitTillElementVisible(first_Record_SanityRule);
		return first_Record_SanityRule.getText();
	}

	public String get_FirstRecordTeamRule() {
		waitTillElementVisible(first_Record_TeamRule);
		return first_Record_TeamRule.getText();
	}

	// User Maintenance Actions
	public void set_UserID(String userID) throws InterruptedException, AWTException {
		waitTillElementVisible(userID_TxtBx);
		userID_TxtBx.sendKeys(userID);
		userID_TxtBx.sendKeys(Keys.RETURN);
		zoomOutUsingRobotClass();
	}

	public void select_All_Teams_Toggle() throws InterruptedException {
		Thread.sleep(10000);
		clickElementUsingJavaScript(selectAllTeams_ChkBx);
	}

	public void click_Assign_Button() {
		waitTillElementVisible(assign_Btn);
		clickElementUsingJavaScript(assign_Btn);
	}

	public boolean isSelected_BSO() {
		waitTillElementVisible(selectAllTeams_ChkBx);
		return selectAllTeams_ChkBx.isSelected();
	}

	public String get_BSO() {
		waitTillElementVisible(BSO_Txt);
		return BSO_Txt.getText();
	}

	public void close_BSO() {
		BSO_Close_Icn.click();
	}

	public void click_Save_Button() {
		scrollIntoViewUsingJavaScript(save_Btn);
		clickElementUsingJavaScript(save_Btn);
	}
	public void verify_Parameter_Value_present(String value) throws InterruptedException {
		boolean ValPresent;
		waitTillElementVisible(parameter_Dpdn);
		ValPresent = value_In_Dropdown(parameter_Dpdn,value);
		Assert.assertTrue(ValPresent,value+" is not present in parameter List");
		
	}
	public void click_Create() throws AWTException, InterruptedException {
		Thread.sleep(30000);
		clickElementUsingJavaScript(create_Btn);
		//zoomOutUsingRobotClass();
	}
	public void verifyColumnValue_listGrid(String ColumnName, String Value) {
		try {
			String modifiedColumnName="";
			boolean assigned = true;
			modifiedColumnName = ColumnName.trim().replace(" ","-");
			 String byName = "//span[starts-with(@id,'"+modifiedColumnName+"')]";
			 List<WebElement> lstAssignedto = driver.findElements(By.xpath(byName));
			 if(lstAssignedto.size()==0)
			 {
				 Assert.fail("No Records displayed for search");
			 }
			for(WebElement eleAssigned: lstAssignedto)
			{
				scrollIntoViewUsingJavaScript(eleAssigned);
				if(!eleAssigned.getText().trim().equals(Value)) {
					assigned = false;
				}
			}
			Assert.assertTrue(assigned,"Few Columns not displayed with value"+ Value);
		}
		catch (Exception e) {
			 e.printStackTrace();
		}
	}


}
