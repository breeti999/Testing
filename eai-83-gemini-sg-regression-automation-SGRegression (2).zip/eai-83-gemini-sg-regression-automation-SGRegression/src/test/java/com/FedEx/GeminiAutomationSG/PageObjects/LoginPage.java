package com.FedEx.GeminiAutomationSG.PageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class LoginPage extends BaseClass {

	// ==================== CONSTRUCTOR ==================== //
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //

	@CacheLookup
	@FindBy(id = "okta-signin-username")
	public WebElement userName_TxtBx;

	@FindBy(id = "okta-signin-password")
	public WebElement password_TxtBx;

	@FindBy(id = "okta-signin-submit")
	public WebElement signIn_Btn;

	@FindBy(xpath = "//input[@value='Send Push']")
	public WebElement push_Btn;

	@FindBy(xpath = "//select[@id='fx-gn-role-dropdown-SG']")
	public static WebElement country_Dpdn;
	
	@FindBy(xpath = "//*[@class='ui-carousel-items-container']")
	public static WebElement countryType_Btn;
	
	@FindBy(xpath = "//*[@class='ui-carousel-next-icon pi pi-chevron-right']")
	public static WebElement swipeRightCountry_Btn;

	@FindBy(xpath = "//button[@id='btnContextSelection']")
	public WebElement continue_Btn;

	@FindBy(xpath = "//span[@class='btn btn-outline-primary dropdown-toggle tools-icon_tools']")
	public WebElement settings_Btn;

	@FindBy(id = "clear-all")
	public WebElement context_Lnk;

	@FindBy(id = "fx-gn-context-selection_location")
	public WebElement location_Dpdn;

	// ==================== ACTION METHODS ===================//

	public void set_Username(String username) {
		enterValueIntoTextField1(userName_TxtBx, username);
	}

	public void set_Password(String password) {
		enterValueIntoTextField1(password_TxtBx, password);
	}

	public void click_Submit() {
		clickElement(signIn_Btn);
	}

	public void click_Push() {
		push_Btn.click();
	}
	
	public void swipeRight_Country() throws InterruptedException {
		if(!country_Dpdn.isDisplayed()) {
			mouseHover(countryType_Btn);
			waitTillElementVisible(swipeRightCountry_Btn);
			swipeRightCountry_Btn.click();
		}
		else {
			log.info("Singapore Country is displayed");
		}
	}

	public void select_Country() throws InterruptedException {
		Thread.sleep(3000);
		waitTillElementVisible(country_Dpdn);
		WebElement drop = country_Dpdn;
		drop.click();
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.DOWN);
		drop.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		scrollByUsingJavaScript();
		Thread.sleep(3000);
	}

	public void click_Continue() {
		try {
			Thread.sleep(1000);
			checkElementIsVisible(continue_Btn);
			scrollIntoViewUsingJavaScript(continue_Btn);
			continue_Btn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_Settings() {
		try {
			settings_Btn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}