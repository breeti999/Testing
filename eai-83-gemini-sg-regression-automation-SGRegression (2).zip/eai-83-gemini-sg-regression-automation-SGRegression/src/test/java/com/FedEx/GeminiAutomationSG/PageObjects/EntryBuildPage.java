package com.FedEx.GeminiAutomationSG.PageObjects;

import static org.testng.Assert.assertEquals;

import java.awt.AWTException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;
import com.FedEx.GeminiAutomationSG.Utilities.ApplicationFunctions;
import com.FedEx.GeminiAutomationSG.Utilities.ScenarioContext;
import com.FedEx.GeminiAutomationSG.Utilities.ScenarioContext.Context;

public class EntryBuildPage extends BaseClass {

	CustomerMatchingPage customerMatchPage;
	ApplicationFunctions applicationFunctions = new ApplicationFunctions(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver;

	public EntryBuildPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	ManifestCheckPage manifest;
	String ConsigneeComp;
	String ClearanceScheme;
	String ClearanceMode;
	String SelectionCode;
	String CommodityCategory;
	String ClearanceStatus;
	String ClearanceLocation;
	String commodity;
	static String firstAWB;
	static String SecondAWB;
	static String ThirdAWB;
	public String awbNumberSplitted;
	String PrevGSTPaid;
	String AutoEDIFlag;
	String clrModeDI;
	String HSCodeText;
	String HSCodeCmbTbl;
	public String CycleDate;
	public String CycleNo;
	boolean hsCodeTblDisplayed;
	boolean blnHsCode;
	boolean UserlistVisible;
	boolean predTblVisible;
	boolean blnRecurringRuleicon;
	boolean blnCreteRuleicon;
	boolean blnListSortCode;
	boolean blncreateRuleCancleVisible;
	public String memberIdtoAssign;

	@CacheLookup

	// EntryBuild
	@FindBy(xpath = "//li[@id='ENTRY_BUILD']")
	public WebElement txtEntryBuild;

	// Entry Build Text
	@FindBy(xpath = "//*[text()='Entry Build']")
	public WebElement txtCompEntryBuild;

	// ACSS Shipments Entry Build
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'ACCS Shipments')][1]")
	public WebElement acssShipmentstoggleentrybuild;

	// Reassign Search
	@FindBy(xpath = "//*[contains(text(),'member(s) to reassign')]//following::input")
	public WebElement txtReassignSearch;

	// filterClearanceStatus
	@FindBy(id = "filter-icon-0")
	public WebElement filterClearanceStatus;

	// filterAWBNumber
	@FindBy(id = "filter-icon-1")
	public WebElement filterAWBNumber;

	@FindBy(id = "clear-all")
	public WebElement lnkContext;

	@FindBy(id = "column-preference-icon")
	public WebElement columnConfiguration;

	// filterAWBNumber Customer Competency
	@FindBy(id = "filter-icon-2")
	public WebElement filterAWBNumberCusCom;

	// filter Consignee Company
	@FindBy(id = "filter-icon-4")
	public WebElement filterConsigneeCompany;

	// Auto EDI Flag
	@FindBy(id = "Auto-EDI-Flag-0")
	public WebElement autoEDIFlag;

	@FindBy(id = "Description-1")
	public WebElement HSCodeDescription;

	@FindBy(id = "Regional-1")
	public WebElement HSCodeRegional;

	// filterTextBox
	@FindBy(xpath = "//*[@name='filterTxtBox']")
	public WebElement filterTextBox;

	@FindBy(id = "Consignee Company-MDE")
	public WebElement consigneeCompanyMDE;

	@FindBy(id = "IOR")
	public WebElement columnIOR;

	// closeIcon
	@FindBy(xpath = "//*[@class='close-icon'][1]")
	public WebElement closeIcon;

	// first Sort Message Field
	@FindBy(xpath = "//tr//genius-toggle-switch")
	public static WebElement firstsortMessageToggle;

	// first Sort Message
	@FindBy(xpath = "(//*[@id='fx-gn-sort-msg-toggle-0'])[2]")
	public static WebElement firstsortMessage;

	@FindBy(xpath = "(//li[@id='sort-communication-icon'])[2]")
	public WebElement SortMessage;

	// first Sort Message
	@FindBy(xpath = "(//*[@id='fx-gn-sort-msg-toggle-0'])[1]")
	public static WebElement firstsortMessage_btn;

	// first Sort Message mutiple selction
	@FindBy(xpath = "(//*[@id='fx-gn-sort-msg-toggle-0'])[1]")
	public static WebElement MultiplefirstsortMessage_btn;

	// AWB Number Entry Build
	@FindBy(xpath = "(//*[text()='AWB Number']//following::span[@class='ng-star-inserted'])[1]")
	public WebElement AWBNumberEntryBuild;

	@FindBy(id = "activityLog")
	public WebElement clickActivityLog;

	@FindBy(xpath = "(//*[@id='btnSort'])[1]")
	public static WebElement sort_sortDescription;

	// clearance Mode GF
	@FindBy(xpath = "//*[@name='clearanceMode']/option[@value='GF']")
	public WebElement clearanceModeG7;

	// Validate button
	@FindBy(id = "btnValidate")
	public WebElement validateButton;

	// LV Truck G7 Overridable Alert
	@FindBy(xpath = "//*[contains(text(),'LV Truck G7')]")
	public WebElement LVTruckG7OverridableAlert;

	// Clearance Status filter
	@FindBy(id = "filter-icon-0")
	public WebElement clearanceStatusfilter;

	@FindBy(xpath = "//*[text()='WCO Tariff']")
	public WebElement WCOTariff;

	@FindBy(xpath = "//*[text()='Regional']")
	public WebElement Regional;

	@FindBy(xpath = "//*[text()='UOM']")
	public WebElement UOM;

	@FindBy(xpath = "//*[text()='Description']")
	public WebElement DescriptionHSCode;

	// Clearance Status
	@FindBy(xpath = "//*[@ng-reflect-klass='clearance-status']")
	public WebElement clearanceStatus;

	// Clearance Status In Progress
	@FindBy(xpath = "//*[contains(text(),'IN PROGRESS')]")
	public WebElement clearanceStatusInProgress;

	// Clearance Status Customs Rejected
	@FindBy(xpath = "//*[contains(text(),'CUSTOMS REJECTED')]")
	public WebElement clearanceStatusCustomsRejected;

	// Clearance Status GST Check
	@FindBy(xpath = "//*[contains(text(),'GST CHECK')]")
	public WebElement clearanceStatusGSTCheck;

	// Clearance Status HVU Ready
	@FindBy(xpath = "//*[contains(text(),'HVU READY')]")
	public WebElement clearanceStatusHVUReady;

	// Clearance Status Audit Check
	@FindBy(xpath = "//*[contains(text(),'COMPANY AUDIT CHECK')]")
	public WebElement clearanceStatusAuditCheck;

	// Clearance Status EDI Ready
	@FindBy(xpath = "//*[contains(text(),'Clearance Status')]/following::span[contains(text(),'EDI Ready')]")
	public WebElement clearanceStatusEDIReady;

	// Consignee Company header
	@FindBy(xpath = "//*[text()='Consignee Company']")
	public WebElement consigneeCompanyheader;

	// Consignee Company
	@FindBy(id = "Consignee-Company-0")
	public WebElement consigneeCompany;

	// Clearance Scheme header
	@FindBy(xpath = "//*[text()='Clearance Scheme']")
	public WebElement clearanceSchemeheader;

	// Clearance Scheme
	@FindBy(id = "Clearance-Scheme-0")
	public WebElement clearanceScheme;

	// Clearance Mode header
	@FindBy(xpath = "//*[text()='Clearance Mode']")
	public WebElement clearanceModeheader;

	// Clearance Mode
	@FindBy(id = "Clearance-Mode-0")
	public WebElement clearanceMode;

	// Clearance Location
	@FindBy(id = "Clearance-Location-0")
	public WebElement clearanceLocation;

	// Commodity Category header
	@FindBy(xpath = "//*[text()='Commodity Category']")
	public WebElement commodityCategoryheader;

	// Commodity Category
	@FindBy(id = "Commodity-Category-0")
	public WebElement commodityCategory;

	// Commodity slno
	@FindBy(id = "commodity_slno_td")
	public WebElement commoditySlno;

	// High CIF Alert
	@FindBy(xpath = "//*[contains(text(),'High CIF')]")
	public WebElement highCIFAlert;

	// High GIF Alert
	@FindBy(xpath = "//*[contains(text(),'High GST')]")
	public WebElement highGIFAlert;

	// CIF Value
	@FindBy(id = "commodity_cif_td")
	public WebElement cifValue;

	// GIF Value
	@FindBy(id = "commodity_gst_td")
	public WebElement gifValue;

	// ATFC Select Customers
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'ATFC Select Customers')]")
	public WebElement atfcSelectCustomers;

	// Default Toggle
	@FindBy(xpath = "//*[@for='fx-gn-user-team-toggle-0']")
	public WebElement defaultToggle;

	// ATFC Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'ATFC')][2]")
	public WebElement atfcToggle;

	// CDN Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'CDN')][1]")
	public WebElement cdnToggle;

	// EDI Ready Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'EDI Ready')]")
	public WebElement ediReadytoggle;

	// EDI Reject Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'EDI Reject')]")
	public WebElement ediRejecttoggle;

	// EDI Complete Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'EDI Complete')][1]")
	public WebElement ediCompletetoggle;

	// HVU Ready
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'HVU')][1]")
	public WebElement HVUReady;

	// High GST Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'High GST')][1]")
	public WebElement highGSTtoggle;

	// SG Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'SG')][1]")
	public WebElement SGtoggle;

	// Company Audit Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'Company Audit')][1]")
	public WebElement CompanyAudittoggle;

	// TN Cage Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'TN Cage')][1]")
	public WebElement TNCagetoggle;

	// SG Select Customers Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'SG Select Customers')][1]")
	public WebElement SGSelectCustomerstoggle;

	@FindBy(xpath = "//*[@id='nullify_assignment']")
	public WebElement UnassignShipment;

	// Unassign Shipment
	@FindBy(id = "rework-shipment")
	public WebElement reworkShipment;

	// filter Consignee Company
	@FindBy(xpath = "//*[text()='Consignee Company-MDE']")
	public WebElement ConsigneeCompanyMDEShipmentResults;

	// filter IOR
	@FindBy(xpath = "//*[text()='IOR']")
	public WebElement IORShipmentResults;

	// Cancel Declaration
	@FindBy(xpath = "(//*[@id='cancel'])[1]")
	public WebElement cancelDeclaration;

	// Manage filter Option In
	@FindBy(xpath = "//*[@class='manageSelectfilter']/option[2]")
	public WebElement ManageFilterIn;

	// Select All AWB's in Entry Build
	@FindBy(xpath = "//*[@for='fx-gn-data-grid-select-all-toggle']")
	public WebElement SelectAllToggle;

	// Commodity table row
	@FindBy(xpath = "//td[@class='commodity-sl-no']//parent::tr")
	public WebElement tblCommodityRow;

	// GST paid
	@FindBy(id = "fx-gn-commodity-gstPaid-0")
	public WebElement selGSTPaid;

	// all alert
	@FindBy(xpath = "//li[@class='fx-gn-cp-arrow-step ng-star-inserted'][1]")
	public WebElement lstAlert;

	@FindBy(xpath = "//div[@class='consignee-row result-grid']//p")
	public WebElement getConsigneeCompanyName;

	@FindBy(xpath = "//div[@class='importer-row result-grid']//p")
	public WebElement getImporterCompanyName;

	// Clearance Mode
	@FindBy(id = "fx-gn-eb-declaration-clearanceMode")
	public WebElement clearanceModeDropdown;

	@FindBy(name = "clearanceMode")
	public WebElement clearanceModeSelect;

	@FindBy(xpath = "//div[contains(text(),'Transport')]/following-sibling::div/a[@id='fx-gn-duty-bill-code']")
	public WebElement transport;

	@FindBy(xpath = "(//label[contains(text(),'Transport Bill To account Number')]/parent::div/following-sibling::div)[1]/label")
	public WebElement transportBillToAmountNumber;

	@FindBy(xpath = "(//label[contains(text(),'Transport Bill To Account Location')]/parent::div/following-sibling::div)[1]/label")
	public WebElement transportBillToAmountLocation;

	@FindBy(xpath = "//*[contains(text(),'CPMatch')]")
	public WebElement highCPMatchAlert;

	@FindBy(id = "consignee-grid__search-icon")
	public WebElement consigneeSearchIcon;

	@FindBy(xpath = "//input[@name='pieceQty']")
	public WebElement packageValue;

	@FindBy(xpath = "//input[@name='weight']")
	public WebElement weight;

	@FindBy(xpath = "//input[@name='branded']")
	public WebElement branded;

	@FindBy(xpath = "//*[text()=' CLEAR ']")
	public WebElement ClearButton;

	@FindBy(xpath = "//div[@class='result-grid-importer__body']")
	public WebElement importerBody;

	@FindBy(xpath = "//*[@name='companyName']")
	public WebElement companyName;

	// Go Button
	@FindBy(xpath = "//*[text()=' GO ']")
	public WebElement GoButton;

	// Link Consignee
	@FindBy(xpath = "(//*[@title=' Link CONSIGNEE'])")
	public WebElement linkConsignee;

	@FindBy(id = "importer-grid__search-icon")
	public WebElement importerSearchIcon;

	@FindBy(xpath = "(//*[@title=' Link Importer'])")
	public WebElement linkImporter;

	// commodity Description textarea
	@FindBy(xpath = "//textarea[@name='commodityDesc']")
	public WebElement commodityDescriptionTextArea;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr")
	public WebElement commodityFirstRow;

	@FindBy(xpath = "//input[@name='invoiceValue']")
	public WebElement commodityDec;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr[2]")
	public WebElement commoditySecondRow;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr/td[4]")
	public WebElement commodityDeclValue;

	// High HS Code Alert
	@FindBy(xpath = "//*[contains(text(),'HSCode')]")
	public WebElement highHSCodeAlert;

	// Commodity Description
	@FindBy(xpath = "//*[contains(text(),'Commodity Description Required')]")
	public WebElement commodityDescriptionAlert;

	@FindBy(id = "fx-gn-commodity-hs-code-0")
	public WebElement txtHSCode;

	@FindBy(xpath = "//*[contains(text(),'Packages')]")
	public WebElement PackagesAlert;

	// High Weight Match Alert
	@FindBy(xpath = "//*[contains(text(),'Weight')]")
	public WebElement weightAlert;

	// High Branded Match Alert
	@FindBy(xpath = "//*[contains(text(),'branded')]")
	public WebElement brandedAlert;

	@FindBy(xpath = "//select[@name='clnSchmCd']")
	public WebElement clearanceSchemeDropdown;

	// Domin LV
	@FindBy(xpath = "//*[contains(text(),'DEMIN LV Required')]")
	public WebElement deminLVAlert;

	// ClearanceScheme
	@FindBy(xpath = "//*[contains(text(),'Check Clearance Scheme')]")
	public WebElement checkClearanceSchemeAlert;

	@FindBy(xpath = "//*[contains(text(),'UEN Failed')]")
	public WebElement uenFailedAlert;

	@FindBy(xpath = "//*[contains(text(),'Cage Code Required')]")
	public WebElement cageCodeRequiredAlert;

	@FindBy(xpath = "//*[contains(text(),'Caged Mode Required')]")
	public WebElement cagedModeRequiredAlert;

	// Check LV ROAD Clearance Mode
	@FindBy(xpath = "//*[contains(text(),'Check LV ROAD Clearance Mode')]")
	public WebElement LVRoadClearanceModelert;

	@FindBy(xpath = "//input[@name='cif']")
	public WebElement cif;

	@FindBy(xpath = "//input[@name='gst']")
	public WebElement gst;

	@FindBy(id = "pst-check")
	public WebElement PSTCheck;

	@FindBy(xpath = "//input[@name='sortMessages']")
	public WebElement selectionCode;

	@FindBy(xpath = "(//span[contains(@id,'Selection-Codes')])[1]")
	public WebElement selectionCodeValue;

	@FindBy(xpath = "(//datatable-row-wrapper[@class='datatable-row-wrapper ng-star-inserted'])[1]")
	public WebElement selctFirstRowInGlobalSearch;

	// ---------------Declaration Information Screen------------------------------

	@FindBy(xpath = "//*[text()='Declaration Information']")
	public WebElement DeclarationInformation;

	@FindBy(xpath = "//*[text()='Importer Instructions']")
	public WebElement ImporterInstructions;

	@FindBy(name = "importerInstruction")
	public WebElement ImporterInstructionText;

	@FindBy(xpath = "//*[text()='Shipment Description']")
	public WebElement ShipmentDescription;

	@FindBy(name = "desc")
	public WebElement ShipmentDescriptionTextField;

	@FindBy(name = "clnSchmCd")
	public WebElement ClearanceSchemeDI;

	@FindBy(name = "weight")
	public WebElement Weight;

	@FindBy(name = "pieceQty")
	public WebElement Package;

	@FindBy(xpath = "//*[contains(text(),'Bill duty to Code')]")
	public WebElement BillDutyToCode;

	@FindBy(xpath = "//*[contains(text(),'Account Number')]")
	public WebElement AccountNumber;

	@FindBy(xpath = "//*[contains(text(),'Company Name')]")
	public WebElement CompanyName;

	@FindBy(xpath = "//*[contains(text(),'Bill Duty to Account Location')]")
	public WebElement BillDutyToAccountLocation;

	// Total Value
	@FindBy(id = "fx-gn-declaration-totalvalue")
	public WebElement totalValue;

	@FindBy(xpath = "//*[contains(text(),'Trasposrt Bill To Code')]")
	public WebElement totalValueheader;

	// *[text()='Total Value']

	@FindBy(name = "currency")
	public WebElement Currency;

	@FindBy(xpath = "(//*[@id='fx-gn-duty-bill-code'])[1]")
	public WebElement DTBill;

	@FindBy(xpath = "(//*[@id='fx-gn-duty-bill-code'])[2]")
	public WebElement Transport;

	@FindBy(xpath = "//*[contains(text(),'Trasposrt Bill To Code')]")
	public WebElement TransportBillToCode;

	@FindBy(xpath = "//*[contains(text(),'Transport Bill To account Number')]")
	public WebElement TransportBillToAccountNumber;

	@FindBy(xpath = "//*[contains(text(),'Transport Bill To Account Location')]")
	public WebElement TransportBillToAccountLocation;

	@FindBy(xpath = "//*[text()=' Others ']")
	public WebElement BillDutyToCodeValue;

	@FindBy(name = "incoterm")
	public WebElement Incoterm;

	@FindBy(name = "gst")
	public WebElement DIGst;

	@FindBy(name = "cif")
	public WebElement DICif;

	@FindBy(id = "fx-gn-declaration-xrate")
	public WebElement ExchangeRate;

	@FindBy(name = "sortMessages")
	public WebElement SelectionCodeDI;

	@FindBy(xpath = "//*[text()='Location Information']")
	public WebElement LocationInformation;

	@FindBy(id = "location_information_flightNo")
	public WebElement FlightNo;

	@FindBy(id = "location_information_modeOfTransport")
	public WebElement ModeOfTransport;

	@FindBy(xpath = "//*[@id='declaration_information_fRate']/genius-textbox/div/input")
	public WebElement DeclarationInformationRate;

	@FindBy(xpath = "//*[@id='declaration_information_insurance']/genius-textbox/div/input")
	public WebElement Insurance;

	@FindBy(xpath = "//*[@class='fx-gn-img-multipleMatch']")
	public WebElement yellowMultimatchIcon;

	@FindBy(id = "fx-gn-img-hs-code-icon")
	public WebElement HSCodeSearchbox;

	@FindBy(id = "fx-gn-commodity-hs-code-0")
	public WebElement HSCodeInput;

	@FindBy(id = "WCO-Tariff-1")
	public WebElement HSCodeInputWCOTariff;

	@FindBy(id = "fx-gn-commodity-select")
	public WebElement SubmitHSCode;

	@FindBy(xpath = "//*[@class='fx-gn-img-matched']")
	public WebElement GreenMatchIcon;

	@FindBy(xpath = "//*[text()=' SG']")
	public WebElement AccountLocationSG;

	@FindBy(xpath = "//*[text()=' MY']")
	public WebElement AccountLocationMY;

	@FindBy(xpath = "//*[contains(text(),'Bill Duty to Account Location')]/following-sibling::span")
	public WebElement AccountLocationValue;

	@FindBy(name = "clearanceMode")
	public WebElement clrMode;

	@FindBy(xpath = "//*[starts-with(text(),' AWB')]")
	public WebElement AWBNumberDeclarationScreen;

	@FindBy(id = "next-shipment")
	public WebElement nextShipment;

	@FindBy(name = "commodityDesc")
	public WebElement CommodityDescription;

	@FindBy(id = "commodity_desc_td")
	public WebElement Description;

	@FindBy(name = "manufacturCountryCode")
	public WebElement COMfield;

	// Clearance Mode in Declaration Screen
	@FindBy(name = "clearanceMode")
	public WebElement selClearanceModeInDeclaration;

	// datagrid
	@FindBy(name = "//datatable-body[@class='datatable-body']")
	public WebElement tblShipment;

	// Mode of Transport in declaration
	@FindBy(id = "location_information_modeOfTransport")
	public WebElement spnModeOfTransport;

	// OVR Registration No
	@FindBy(id = "fx-gn-eb-declaration-information-registrationNo")
	public WebElement txtOVRRegistration;

	// Importer

	@FindBy(xpath = "//*[text()=' Importer ']")
	public WebElement ImporterIcon;

	@FindBy(id = "importer-grid__search-icon")
	public WebElement SearchImporter;

	@FindBy(id = "fx-gn-importer-search-companyName")
	public WebElement SearchCompanyName;

	@FindBy(id = "fx-gn-is-link-icon")
	public WebElement LinkImporterDC;

	@FindBy(xpath = "(//*[@id='fx-gn-is-importer-body'])[1]")
	public WebElement ImporterDetails;

	@FindBy(xpath = "//span[@id='customer_information_importer_details_apac']/span[3]")
	public WebElement defermentType;

	// Consignee

	@FindBy(xpath = "//*[text()=' Consignee ']")
	public WebElement ConsigneeIcon;

	@FindBy(id = "consignee-grid__search-icon")
	public WebElement SearchConsigneeDC;

	@FindBy(id = "fx-gn-shipper-search-companyName")
	public WebElement SearchCompanyNameConsignee;

	@FindBy(xpath = "(//*[contains(@title,'Link CONSIGNEE')])[1]")
	public WebElement LinkConsigneeDC;

	@FindBy(xpath = "(//*[contains(text(),'TEST')])[1]")
	public WebElement ConsigneeDetails;

	/*@FindBy(id = "AWB-Number-0")
	public static WebElement firstRecordAWB;

	@FindBy(id = "AWB-Number-1")
	public static WebElement SecondRecordAWB;*/

	@FindBy(xpath = "//*[@id='AWB-Number-0']/parent::span")
	public static WebElement firstRecordAWB;

	@FindBy(xpath = "//*[@id='AWB-Number-1']/parent::span")
	public static WebElement SecondRecordAWB;

	@FindBy(id = "AWB-Number-2")
	public static WebElement ThirdRecordAWB;

	@FindBy(id = "Selection-Codes-0")
	public WebElement firstRecordSelCode;

	@FindBy(id = "CI-Flag-0")
	public WebElement firstRecordCIFlag;

	@FindBy(id = "filter-icon-1")
	public WebElement btnFilterAWB;

	@FindBy(id = "filter-icon-2")
	public WebElement btnFilterAWBMC;

	@FindBy(id = "filter-icon-8")
	public WebElement btnFilterCI;

	@FindBy(xpath = "//input[@name='filterTxtBox']")
	public WebElement txtFilter;

	@FindBy(xpath = "//span//button[@class='close-icon']")
	public WebElement btnFilterClose;

	@FindBy(xpath = "//div[@class='document-details ng-star-inserted']//span")
	public List<WebElement> lblDocDetails;

	@FindBy(xpath = "//*[@class='sort-message-sl-no']/following-sibling::td[1]/div")
	public WebElement SuggestionSortDescription;

	@FindBy(xpath = "//*[@class='sort-message-sl-no']/following-sibling::td[2]/div")
	public WebElement SuggestionSelectionCode;

	@FindBy(id = "add-assigntome")
	public WebElement btnAssignToMe;

	@FindBy(id = "userlist")
	public WebElement btnUserList;

	@FindBy(id = "sort-communication-icon")
	public WebElement btnFloatSortMessage;

	@FindBy(xpath = "//genius-floating-icons[@ng-reflect-show-sort-message-icon='true']//li[@id='sort-communication-icon']")
	public WebElement btnFloatSortMessageNew;

	@FindBy(id = "ancilary-icon")
	public WebElement btnFloatAncilary;

	@FindBy(id = "activityLog-icon")
	public WebElement btnFloatActivityLog;

	@FindBy(xpath = "//li[@id='notification-icon']/div/div")
	public WebElement btnFloatNotification;

	@FindBy(xpath = "//div[@class='document-upload-conatiner']")
	public WebElement btnFloatUpload;

	@FindBy(name = "location")
	public Select selFloatUploadLocation;

	@FindBy(name = "documentType")
	public Select selFloatUploadDocumentType;

	@FindBy(xpath = "//form//input[@type='file']")
	public WebElement btnFloatUploadBrowseFiles;

	@FindBy(xpath = "(//*[@id='btnSave'])[2]")
	public static WebElement btnFloatUploadSave;
	
	@FindBy(xpath = "//button[@id='btnSave']")
	public static WebElement btnFloatUploadSaveNew;

	@FindBy(id = "btnCancel")
	public WebElement btnFloatUploadCancel;

	@FindBy(xpath = "(//*[contains(text(),'Selection Code')]/following-sibling::span/button[@id='btnFilter'])[2]")
	public static WebElement btnFloatSortFilter;

	@FindBy(xpath = "//*[contains(text(),'Selection Code')]/following-sibling::span/button[@id='btnFilter']")
	public static WebElement btnFloatSortFilterNew;

	@FindBy(xpath = "(//*[contains(text(),'Selection Code')]/following-sibling::span/button[@id='btnFilter'])[1]")
	public static WebElement SortFilter;

	@FindBy(id = "sortCd")
	public static WebElement txtFloatSortFilter;

	@FindBy(id = "fx-gn-sort-msg-toggle-all")
	public WebElement chkFloatSortToggle;

	@FindBy(xpath = "//div[@id='declaration_information_sortMessages']//div/input")
	public WebElement txtSortMessages;

	@FindBy(xpath = "//form[@id='fx-gn-entry-view-header-form']/div/div")
	public WebElement lblAWB;

	@FindBy(xpath = "//div[@id='toast-container']/div")
	public WebElement lblPopup;

	@FindBy(xpath = "//button[@title='Add Notification']")
	public WebElement btnAddNotification;

	@FindBy(xpath = "(//textarea[@name='comments'])[1]")
	public WebElement txtComments;

	@FindBy(xpath = "(//textarea[@name='comments'])[2]")
	public WebElement fp_txtComments;

	@FindBy(xpath = "//p[@id='notification-comment-0']")
	public WebElement lblLastComment;

	@FindBy(xpath = "(//button[@title='Save'])")
	public WebElement btnSave;

	@FindBy(xpath = "(//button[@title='Save'])")
	public WebElement submit_upload;

	@FindBy(xpath = "(//div[@role='dialog'])[2]//following::div[contains(@class,'sort-message-footer')]//following-sibling::button/../button[1]")
	public WebElement sortModel_save;

	@FindBy(xpath = "(//button[@id='btnSave'])[1]|(//button[@title='Save'])[2]")
	public WebElement fp_btnSave;

	@FindBy(xpath = "(//button[@id='btnCancel'])[2]")
	public WebElement icon_bt_entrybuild_cancel;

	@FindBy(xpath = "//button[@title='Close']|//button[@id='cancel' and contains(@class,'action-buttons')]")
	public WebElement btnClose;

	@FindBy(xpath = "//*[@title='Close']")
	public WebElement GlobalSearchClose;

	@FindBy(xpath = "(//button[@title='Cancel'])[1]")
	public WebElement decln_screenClose;

	@FindBy(id = "cancel")
	public WebElement btnCancel;

	@FindBy(xpath = "//*[@class='row-index-value ng-star-inserted']")
	public WebElement NoOfRows;

	@FindBy(xpath = "//input[@name ='quantity']")
	public WebElement commodityQuantity;

	@FindBy(xpath = "//tr[@class='ng-star-inserted']")
	public WebElement commodityRow;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr[3]")
	public WebElement eleNewCommodityRow;
	
	@FindBy(xpath = "//*[@id='add_commodity_details_icon']")
	public WebElement click_NewCommodityRow;

	// SelectionCodeInDeclaration
	@FindBy(id = "fx-gn-eb-declaration-information-sortMsgs")
	public WebElement SelCodeInDeclaration;

	@FindBy(id = "fx-gn-declaration-gst")
	public WebElement GSTInDeclaration;

	@FindBy(xpath = "//span[@title='Click to Override']//a[@class='fx-gn-declaration-requirement-icon']")
	public List<WebElement> lstOverridableAlertLinks;

	@FindBy(xpath = "//span[@title='Click to Override']//a[@class='fx-gn-declaration-requirement-icon']")
	public WebElement lstOverridableAlertLink;

	@FindBy(id = "btnSubmit")
	public WebElement btnSubmitDecalartion;

	// Column Config icon in grid
	@FindBy(id = "column-preference-icon")
	public WebElement btnColumnConfig;

	@FindBy(xpath = "//div[@class='modal-content']//genius-toggle-switch")
	public WebElement columnConfigWindow;

	// save column config
	@FindBy(id = "btn-save-toggle-column-preferecne")
	public WebElement btnSaveColumn;

	// cancel Column Config
	@FindBy(id = "btn-cancel-toggle-column-preferecne")
	public WebElement btnCancelColumn;

	@FindBy(xpath = "//span[contains(@id,'Cycle-Date')]")
	public List<WebElement> spnCycleDate;

	@FindBy(xpath = "//form[@id='fx-gn-edi-Submission-pop-form']//span[@id='Cycle-Date-0']")
	public WebElement spnCycleDateConsoleSubmission;

	@FindBy(id = "Cycle-No-0")
	public WebElement spnCycleNumberConsoleSubmission;

	@FindBy(xpath = "//span[contains(@id,'Cycle-Number')]")
	public List<WebElement> spnCycleNumber;

	@FindBy(id = "HAWB-Count-0")
	public WebElement eleHAWB;

	// All Commodity table row
	@FindBy(xpath = "//td[@class='commodity-sl-no']//parent::tr")
	public List<WebElement> tblCommodityRows;

	// selected Sorts
	@FindBy(xpath = "(//table[@class='sort-message-table']//genius-toggle-switch[@ng-reflect-is-toggle-switched = 'true']//input)")
	public List<WebElement> inpSortCodes;

	// HSCode of selected commidity
	@FindBy(xpath = "//input[contains(@id,'fx-gn-commodity-hs-code')]")
	public WebElement txtHSCodeClicked;

	// HSCode
	@FindBy(xpath = "//input[contains(@id,'fx-gn-commodity-qty')]")
	public WebElement txtQuantityClicked;

	// Green HSCode icon
	@FindBy(xpath = "//a[@class='fx-gn-img-matched']")
	public WebElement lnkGreenIcon;

	// HSCode alert
	@FindBy(xpath = "//span[contains(text(),'HSCode Required') or contains(text(),'UOM Required')]")
	public WebElement spnHSCodeAlert;

	// CAGE alert
	@FindBy(xpath = "//span[contains(text(),'Caged Mode Required')]")
	public WebElement eleCAGEModeAlert;

	// Clrstatus in declaration
	@FindBy(id = "fx-gn-clearance-status-clearance-status")
	public WebElement txtClrStatusInDeclaration;

	// Consignee search
	@FindBy(id = "consignee-grid__search-icon")
	public WebElement btnConsigneeSearch;

	// imported search
	@FindBy(id = "importer-grid__search-icon")
	public WebElement btnImporter;

	// Consignee Name
	@FindBy(id = "fx-gn-shipper-search-companyName")
	public WebElement txtConsigneeName;

	// Importer Name
	@FindBy(id = "fx-gn-importer-search-companyName")
	public WebElement inpImporterName;

	// Consignee search
	@FindBy(xpath = "//button[@type='submit']")
	public WebElement btnGoConsigneeSearch;

	// Consignee link
	@FindBy(xpath = "(//a[@title=' Link CONSIGNEE'])[1]")
	public WebElement btnLinkConsignee;

	// Consignee HVU Submit
	@FindBy(xpath = "//button[@title='Submit HVU Shipment']")
	public WebElement btnHVUSubmit;

	// Activity log
	@FindBy(xpath = "//div[starts-with(@class,'fx-gn-activity-log__group-container')]")
	public List<WebElement> lstActivityLogList;

	// Activity log selection code
	@FindBy(xpath = "(//*[text()='Selection code'])[1]/following-sibling::span")
	public WebElement ActLog_SelectionCode;

	@FindBy(id = "AWB-0")
	public static WebElement GlobalSearchFirstAWB;

	@FindBy(id = "AWB-1")
	public static WebElement GlobalSearchSecondAWB;

	// Close activity log
	@FindBy(xpath = "//a[@title='Close']")
	public WebElement lnkCloseFloatingPanel;

	// All toggle select
	@FindBy(id = "fx-gn-data-grid-select-all-toggle")
	public WebElement inpAllToggle;

	// Cycle changes button
	@FindBy(id = "cycle-date-cycle-number")
	public WebElement btnCycleChanges;

	// Cycle changes button floating panel diabled
	@FindBy(xpath = "//li[@id='cycleChanges-icon'][@ng-reflect-ng-class='list-group-item-disabled']")
	public WebElement eleCycleChangeFloatingPanelDisabled;

	// Cycle changes button floating panel enabled
	@FindBy(xpath = "//li[@id='cycleChanges-icon']")
	public WebElement eleCycleChangeFloatingPanelEnabled;

	// calender in cycle changes
	@FindBy(xpath = "//button[@class='btn btn-outline-secondary calendar']")
	public WebElement btnCalender;

	@FindBy(xpath = "//select[@aria-label='Select month']")
	public WebElement selMonth;

	@FindBy(xpath = "//select[@aria-label='Select year']")
	public WebElement selYear;

	// Edi ready in team leader
	@FindBy(xpath = "//*[starts-with(text(),' EDI Ready')]")
	public static WebElement eleEDIReadytoggleTeamLeader;

	// CycleNumber Selection
	@FindBy(id = "fx-gn-cycle-change-cycle-number")
	public static WebElement selCycleNumber;

	@FindBy(id = "edi-submission-verification")
	public static WebElement btnConsoleSubmission;

	@FindBy(xpath = "//span[@title= 'Search']")
	public static WebElement eleSearch;

	// Cycle Number Filter- Console Submission
	@FindBy(xpath = "//span[text()='Cycle No']//ancestor::tr//a[@id='filter-icon-1']")
	public static WebElement eleCycleNumFilter;

	@FindBy(xpath = "//form[@id='fx-gn-edi-Submission-pop-form']//button[@id = 'cancel']")
	public static WebElement btnCancelConsoleSubmission;

	// sortFilter desc
	@FindBy(xpath = "//button[@class='fx-gn-eb-sort-message-title filter']")
	public static WebElement btnSortDescFilter;

	@FindBy(id = "sortCdDesc")
	public static WebElement txtSortDescFilter;

	@FindBy(xpath = "//span[contains(@id, 'AWB-Number')]")
	public static List<WebElement> lstAWBs;

	// Orange HSCODE icon
	@FindBy(xpath = "//a[@class='fx-gn-img-multipleMatch']")
	public WebElement lnkOrangeIcon;
	// red icon
	@FindBy(xpath = "//a[@class='fx-gn-img-noMatch']")
	public WebElement lnkRedIcon;
	// Alert
	@FindBy(xpath = "//div[@role = 'alertdialog']")
	public WebElement eleAlertMsg;

	@FindBy(id = "fx-gn-declaration-totalvalue")
	public WebElement inpTotalValue;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr[2]/td[4]")
	public WebElement eleCommNewDecl;
			
	@FindBy(xpath = "(//*[@id='commodity_desc_td'])[2]")
	public WebElement Second_CommDecl;
	
	@FindBy(id = "delete_commodity_details_icon")
	public WebElement delete_commodity;

	@FindBy(id = "fx-gn-declaration-cif")
	public WebElement inpCIF;

	@FindBy(id = "fx-gn-declaration-gst")
	public WebElement inpGST;

	@FindBy(id = "fx-gn-declaration-xrate")
	public WebElement inpXrate;

	@FindBy(id = "fx-gn-eb-declaration-information-fRate")
	public WebElement inpFrate;

	@FindBy(id = "fx-gn-eb-declaration-information-insurance")
	public WebElement inpInsurance;

	@FindBy(xpath = "//input[contains(@id,'fx-gn-commodity-cif')]")
	public WebElement inpCommCIF;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr[2]/td[8]")
	public WebElement eleNewCommCIF;

	@FindBy(xpath = "//table[@class='commodity-table table-responsive']/tbody/tr/td[8]")
	public WebElement eleCommCIF;

	@FindBy(xpath = "//input[contains(@id,'fx-gn-commodity-local-gst')]")
	public WebElement inpCommGST;

	@FindBy(xpath = "//Select[contains(@id,'fx-gn-commodity-mfg-ctry')]")
	public WebElement selCommCountry;

	@FindBy(xpath = "//textarea[contains(@id,'fx-gn-commodity-desc')]")
	public WebElement txtCommDesc;
	@FindBy(xpath = "//input[contains(@id,'fx-gn-commodity-code1')]")
	public WebElement inpCommBranded;

	@FindBy(xpath = "//select[contains(@id,'fx-gn-commodity-product')]")
	public WebElement selCommProduct;

	@FindBy(id = "fx-gn-eb-declaration-clearancescheme")
	public WebElement selClrScheme;

	@FindBy(id = "fx-gn-eb-declaration-currency")
	public WebElement selCurrency;

	@FindBy(id = "fx-gn-eb-declaration-information-grossweight")
	public WebElement inpGrossWeight;

	@FindBy(id = "fx-gn-eb-declaration-incoterm")
	public WebElement selIncoTerm;

	@FindBy(id = "fx-gn-declaration-declaration-desc")
	public WebElement inpShipmentDesc;

	@FindBy(xpath = "//*[contains(text(),'COM Invalid')]")
	public WebElement comInvalid;

	@FindBy(xpath = "//*[contains(text(),'COM Required')]")
	public WebElement comRequired;

	@FindBy(xpath = "//input[@id='undefined-ACCS Shipments']/parent::label")
	WebElement entryBuild_ACCSShipmentTeam;

	@FindBy(xpath = "//input[@id='fx-gn-user-role-search-memberName']")
	public WebElement memberTextBox;

	@FindBy(xpath = "//a[@class='upload-icon']")
	WebElement btn_Upload;

	@FindBy(xpath = "//a[@class='download-icon']")
	WebElement btn_Download;

	@FindBy(xpath = "//select[@name='location']")
	public WebElement dpdn_Location;

	@FindBy(xpath = "//*[@id='cancel']")
	public WebElement btnCancelAssign;

	@FindBy(xpath = "//*[@id='userListBody']")
	public WebElement userListBody;

	// Columns of Prediction table

	@FindBy(xpath = "//span[text()='WCO Tariff']")
	public WebElement spanWCOTariff;

	@FindBy(xpath = "//span[text()='UOM']")
	public WebElement spanUOM;

	@FindBy(xpath = "//span[text()='Description']")
	public WebElement spanDescription;

	@FindBy(xpath = "//span[text()='Source']")
	public WebElement spanSource;

	@FindBy(xpath = "(//table)/tr/th")
	public WebElement gridTable;

	@FindBy(xpath = "(//li[@id='sort-communication-icon'])[1]")
	public WebElement icon_fp_sortMsg1;

	@FindBy(xpath = "(//li[@id='sort-communication-icon'])[2]")
	public WebElement icon_fp_sortMsg2;

	@FindBy(xpath = "(//li[@id='sort-communication-icon']//following::span[text()='Sort Message'])[1]")
	public WebElement icon_fp_click_sortMsg1;

	@FindBy(xpath = "(//li[@id='sort-communication-icon']//following::span[text()='Sort Message'])[2]")
	public WebElement icon_fp_click_sortMsg2;

	@FindBy(xpath = "((//div[@id='notification'])[2]/div)[1]")
	public WebElement icon_fp_notification;

	@FindBy(xpath = "((//div[@id='notification'])[2]/div)[1]/div")
	public static WebElement icon_fp_click_notification;

	@FindBy(xpath = "(//div[@class='document-upload-conatiner']/div)[1]")
	public WebElement icon_fp_upload;

	@FindBy(xpath = "(//div[@class='document-upload-conatiner']/div)[1]/div")
	public static WebElement icon_fp_click_upload;

	@FindBy(xpath = "((//table[@class='sort-message-table'])/tbody)//following::tr")
	public List<WebElement> sortCodeValues;

	@FindBy(xpath = "((//datatable-header-cell/div/div)/table)")
	public List<WebElement> tblHeaderlabels;
	
	@FindBy(xpath = "//div[@title='Close']")
	public WebElement close_globalSearch;	

	@FindBy(xpath = "(//*[contains(@class,'img-panel')])[3]/div/span[2]")
	public WebElement invoice_label;

	@FindBy(xpath = "//select[@class='manageSelectfilter']")
	public WebElement selectText;

	@FindBy(xpath = "(//div[contains(@class,'drop-zone')])[2]/input")
	public WebElement browseFile;

	@FindBy(xpath = "//select[@name='documentType']")
	public WebElement docType;

	@FindBy(xpath = "//select[@name='location']")
	public WebElement location;

	@FindBy(xpath = "//input[@name='memberId']")
	public WebElement memberId;

	@FindBy(xpath = "(//div[contains(@id,'team-leader-user-result')])//p")
	public WebElement selectUser;	
	
	@FindBy(xpath = "(//div[contains(@id,'team-leader-user-result')])//p")
	public List<WebElement> multipleUser;

	@FindBy(xpath = "(//div[contains(@id,'team-leader-user-result')])//p")
	public List<WebElement> selectUsers;

	@FindBy(xpath = "//span[@class='user-name']")
	public WebElement userName;

	@FindBy(xpath = "//div[@id='column-preference-icon']")
	public WebElement tripple_dot;

	@FindBy(xpath = "//button[@title='Save']")
	public WebElement save_modal_window;

	@FindBy(xpath = "((//div[@class='modal-content']//following::div[contains(@class,'drag-and-drop-list')]//following::genius-toggle-switch)[@ng-reflect-is-toggle-switched='true'])")
	public List<WebElement> modal_window_disabled;

	@FindBy(xpath = "((//div[@class='modal-content']//following::div[contains(@class,'drag-and-drop-list')]//following::genius-toggle-switch)[@ng-reflect-is-toggle-switched='false'])")
	public List<WebElement> modal_window_enabled;

	@FindBy(xpath = "//button[@id='retrieve-route-info-shipment']")
	public WebElement routeRefreshInformation;

	@FindBy(xpath = "(//div[contains(@id,'team-leader-user-result')])//div[@class = 'fx-gn-team-leader-user-result__sublabel']")
	public WebElement userIdToAssign;

	@FindBy(xpath = "//input[@id='fx-gn-data-grid-select-all-toggle']/ancestor::genius-toggle-switch[@ng-reflect-disable-toggle-switch = 'false']")
	public WebElement toggleAllAWBinList;

	public void entryBuild_module() throws InterruptedException {
		try {
			waitTillElementVisible(txtEntryBuild);
			txtEntryBuild.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void default_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(defaultToggle);
			defaultToggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void unassign_shipment() throws InterruptedException {
		try {
			scrollIntoViewUsingJavaScript(userListBody);
			Thread.sleep(2000);
			waitTillElementVisible(userListBody);
			userListBody.click();
			clickElementUsingJavaScript(UnassignShipment);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cancel_declaration() throws InterruptedException {
		try {
			Thread.sleep(1000);
			waitTillElementVisible(cancelDeclaration);
			clickElementUsingJavaScript(cancelDeclaration);
			// cancelDeclaration.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ATFCSelectCustomers_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(atfcSelectCustomers);
			atfcSelectCustomers.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void TNCage_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(TNCagetoggle);
			TNCagetoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void CompanyAudit_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(CompanyAudittoggle);
			CompanyAudittoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ACCSShipments_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(acssShipmentstoggleentrybuild);
			acssShipmentstoggleentrybuild.click();
			Thread.sleep(4000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void icon_fp() throws InterruptedException {
		try {
			Thread.sleep(3000);
			try {
				waitTillElementVisible(icon_fp_sortMsg1);
				mouseHover(icon_fp_sortMsg1);
				icon_fp_click_sortMsg1.click();
			} catch (NoSuchElementException | TimeoutException | ElementNotInteractableException e) {
				waitTillElementVisible(icon_fp_sortMsg2);
				mouseHover(icon_fp_sortMsg2);
				icon_fp_click_sortMsg2.click();
			} catch (Exception e) {
				e.printStackTrace();
			}
			log.info("Click sort message from the floating panel");
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void icon_fp_notification() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(icon_fp_notification);
			mouseHover(icon_fp_notification);
			waitTillElementVisible(EntryBuildPage.icon_fp_click_notification);
			icon_fp_click_notification.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void icon_fp_upload() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(icon_fp_upload);
			mouseHover(icon_fp_upload);
			waitTillElementVisible(EntryBuildPage.icon_fp_click_upload);
			icon_fp_click_upload.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void icon_selectSelectionCode(String data1, String data2) throws InterruptedException {
		String attrValue;
		WebElement codeSelection2;
		try {

			Thread.sleep(5000);
			System.out.println("Total SortCodeSize:" + sortCodeValues.size());
			try {
				for (int i = 1; i < sortCodeValues.size(); i++) {
					String selCode = driver
							.findElement(By.xpath("((//table[@class='sort-message-table'])//following::tbody)[1]/tr["
									+ i + "]//following-sibling::td[2]/div"))
							.getAttribute("innerHTML");
					System.out.println("Fetched Sort Code is : " + i + "=" + selCode);
					if (selCode.equalsIgnoreCase(data1) || selCode.equalsIgnoreCase(data2)) {
						// WebElement codeSelection1 =
						// driver.findElement(By.xpath("(((//table[@class='sort-message-table'])//following::tbody)[1]/tr["+i+"-1"+"]//following::genius-toggle-switch)[1]/div/input"));
						try {
							attrValue = driver.findElement(By.xpath(
									"((//table[@class='sort-message-table'])[2]//following::genius-toggle-switch)[" + i
											+ "]"))
									.getAttribute("ng-reflect-is-toggle-switched");
							codeSelection2 = driver.findElement(By.xpath(
									"((//table[@class='sort-message-table'])[2]//following::genius-toggle-switch)[" + i
											+ "]/div/input"));
						} catch (NoSuchElementException | ElementNotInteractableException | TimeoutException e) {
							attrValue = driver.findElement(By.xpath(
									"((//table[@class='sort-message-table'])[1]//following::genius-toggle-switch)[" + i
											+ "]"))
									.getAttribute("ng-reflect-is-toggle-switched");
							codeSelection2 = driver.findElement(By.xpath(
									"((//table[@class='sort-message-table'])[1]//following::genius-toggle-switch)[" + i
											+ "]/div/input"));
						}
						// scrollIntoViewUsingJavaScript(codeSelection1);
						scrollIntoViewUsingJavaScript(codeSelection2);
						Thread.sleep(2000);
						// EntryBuildPage.clickElementUsingJavaScript(codeSelection1);
						boolean condition = Boolean.parseBoolean(attrValue);
						if (!condition) {
							EntryBuildPage.clickElementUsingJavaScript(codeSelection2);
						}
						System.out.println("Sort Code fetched and Matched : " + selCode);
						log.info("Sort code is selected:" + selCode);
					}
				}
			} catch (NoSuchElementException | TimeoutException | ElementNotInteractableException e) {
				System.err.println("Failed in method: (EntryBuildPage.java)_icon_selectSelectionCode");
			}
			Thread.sleep(2000);
			// scrollIntoViewUsingJavaScript(btnSave);
			// waitTillElementVisible(btnSave);
			// EntryBuildPage.clickElementUsingJavaScript(btnSave);
			scrollIntoViewUsingJavaScript(sortModel_save);
			waitTillElementVisible(sortModel_save);
			EntryBuildPage.clickElementUsingJavaScript(sortModel_save);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ATFC_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(atfcToggle);
			atfcToggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cdn_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(cdnToggle);
			cdnToggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ediReady_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(ediReadytoggle);
			ediReadytoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ediReject_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(ediRejecttoggle);
			ediRejecttoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ediComplete_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(ediCompletetoggle);
			ediCompletetoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void HVUReady_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(HVUReady);
			HVUReady.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void highGST_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(highGSTtoggle);
			highGSTtoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SG_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(SGtoggle);
			SGtoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SGSelectCustomers_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(SGSelectCustomerstoggle);
			SGSelectCustomerstoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_FilterHUAWEI() throws InterruptedException {
		try {
			Thread.sleep(5000);
			waitTillElementVisible(filterConsigneeCompany);
			filterConsigneeCompany.click();
			filterTextBox.click();
			filterTextBox.sendKeys("HUAWEI");
			closeIcon.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_FilterEDIReady() throws InterruptedException {

		try {
			Thread.sleep(5000);
			waitTillElementVisible(filterClearanceStatus);
			filterClearanceStatus.click();
			filterTextBox.click();
			filterTextBox.sendKeys("EDI Ready");
			closeIcon.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_FilterEDIReady(String ClearanceStatusUserList) throws InterruptedException {

		try {
			Thread.sleep(5000);
			waitTillElementVisible(filterClearanceStatus);
			filterClearanceStatus.click();
			filterTextBox.click();
			filterTextBox.sendKeys(ClearanceStatusUserList);
			closeIcon.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void rework_Shipment() throws InterruptedException {

		try {
			Thread.sleep(3000);
			waitTillElementVisible(reworkShipment);
			clickElementUsingJavaScript(reworkShipment);
			log.info("Rework shipment clicked");
		} catch (Exception e) {
			log.error("Rework shipment not clicked", e);
		}
	}

	public void verify_DeclarationInformationText() throws InterruptedException {

		try {
			Thread.sleep(3000);
			waitTillElementVisible(DeclarationInformation);
			String buttonColor = DeclarationInformation.getCssValue("background-color");
			String buttonTextColor = DeclarationInformation.getCssValue("color");
			log.info("Button color: " + buttonColor);
			log.info("Text color " + buttonTextColor);
			String fontWeight = DeclarationInformation.getCssValue("font-weight");
			log.info(fontWeight);
			Assert.assertTrue(Integer.parseInt(fontWeight) >= 700);
		} catch (Exception e) {
			log.error("Declaration information not verified", e);
		}
	}

	public void verify_ImporterInstructionsTextField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(ImporterInstructions);
			verifyElementPresent(ImporterInstructions);
			NonEditable(ImporterInstructions);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ShipmentDescriptionTextField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(ShipmentDescription);
			verifyElementPresent(ShipmentDescription);
			Enabled(ShipmentDescription);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModeDropdown() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(clrMode);
			@SuppressWarnings("serial")
			List<String> expectedDropDownValues = new ArrayList<String>() {
				{
					add("Select");
					add("DEMIN");
					add("G7");
					add("GF");
					add("AISS");
					add("MES");
					add("CAGED");
					add("ERROR");
				}
			};
			Select entriesDropDown = new Select(clrMode);
			List<WebElement> actualDropDownValues = entriesDropDown.getOptions();
			for (int i = 0; i < actualDropDownValues.size(); i++) {
				if (actualDropDownValues.get(i).getText().equals(expectedDropDownValues.get(i).toString())) {
					log.info("Value Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				} else {
					log.info("Value Not Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceSchemeDropdown() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(ClearanceSchemeDI);
			List<String> expectedDropDownValues = new ArrayList<String>();
			expectedDropDownValues.addAll(Arrays.asList("Select", "BSO", "HV", "LV", "TRANSSHIP", "X-HIGH"));
			Select entriesDropDown = new Select(ClearanceSchemeDI);
			List<WebElement> actualDropDownValues = entriesDropDown.getOptions();
			for (int i = 0; i < actualDropDownValues.size(); i++) {
				if (actualDropDownValues.get(i).getText().contains(expectedDropDownValues.get(i).toString())) {
					log.info("Value Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				} else {
					log.info("Value Not Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				}
			}

			String value = totalValue.getAttribute("value");
			log.info(value);
			double d = Double.parseDouble(value);
			int val = (int) d;
			log.info(val);
			if (val < 400) {
				log.info("LV Shipment");
			} else if (val > 400 && val < 20000) {
				log.info("HV Shipment");
			} else {
				log.info("X-HIGH Shipment");
			}
		} catch (Exception e) {
			log.error(e);
		}
	}

	public void verify_IncotermDropdown() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Incoterm);
			List<String> expectedDropDownValues = new ArrayList<String>();
			expectedDropDownValues.addAll(Arrays.asList("Select", "C&I", "CFR", "CIF", "CIP", "CPT", "DAF", "DAP",
					"DAT", "DDP", "DDU", "DEQ", "DES", "EXW", "FAS", "FCA", "FOB"));
			Select entriesDropDown = new Select(Incoterm);
			List<WebElement> actualDropDownValues = entriesDropDown.getOptions();
			for (int i = 0; i < actualDropDownValues.size(); i++) {
				if (actualDropDownValues.get(i).getText().contains(expectedDropDownValues.get(i).toString())) {
					log.info("Value Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				} else {
					log.info("Value Not Matching :" + "Actual List Value=" + actualDropDownValues.get(i).getText()
							+ " And Expected Value=" + expectedDropDownValues.get(i));
				}
			}
		} catch (Exception e) {
			log.error(e);
		}
	}

	public void verify_TotalValue() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(totalValue);
			Enabled(totalValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_CurrencyDropDown() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Currency);
			Enabled(Currency);
			getOptions(Currency);
			log.info("Clicked on currency dropdown");

		} catch (Exception e) {
			log.error("Clicked on currency dropdown", e);
		}
	}

	public void verify_WeightTextField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Weight);
			Enabled(Weight);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_BillDutyToCode() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(DTBill);
			String ele = DTBill.getAttribute("class");
			System.out.println(ele);
			if (ele.contains("C")) {
				System.out.println("It is Consignee");
			} else if (ele.contains("S")) {
				System.out.println("It is Shipper");
			} else if (ele.contains("O")) {
				System.out.println("It is Others");
			} else {
				System.out.println("Not anything mentioned");
				Assert.fail();
			}
			mouseHover(DTBill);
			verifyElementPresent(BillDutyToCode);
			verifyElementPresent(AccountNumber);
			verifyElementPresent(CompanyName);
			verifyElementPresent(BillDutyToAccountLocation);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_Transport() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Transport);
			String ele = Transport.getAttribute("class");
			System.out.println(ele);
			if (ele.contains("C")) {
				System.out.println("It is Consignee");
			} else if (ele.contains("S")) {
				System.out.println("It is Shipper");
			} else if (ele.contains("O")) {
				System.out.println("It is Others");
			} else {
				System.out.println("Not anything mentioned");
				Assert.fail();
			}
			mouseHover(Transport);
			verifyElementPresent(TransportBillToCode);
			verifyElementPresent(TransportBillToAccountNumber);
			verifyElementPresent(TransportBillToAccountLocation);
			verifyElementPresent(CompanyName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_XRateField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(ExchangeRate);
			verifyElementPresent(ExchangeRate);
			NonEditable(ExchangeRate);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_CIFField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(DICif);
			verifyElementPresent(DICif);
			NonEditable(DICif);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_GSTField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(DIGst);
			verifyElementPresent(DIGst);
			NonEditable(DIGst);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_pkgField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Package);
			verifyElementPresent(Package);
			Enabled(Package);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_InsuranceField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(Insurance);
			verifyElementPresent(Insurance);
			NonEditable(Insurance);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_SelectionCodeField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(SelectionCodeDI);
			verifyElementPresent(SelectionCodeDI);
			NonEditable(SelectionCodeDI);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_LocationInformation() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(LocationInformation);
			verifyElementPresent(LocationInformation);
			verifyElementPresent(FlightNo);
			verifyElementPresent(ModeOfTransport);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_TotalValueField() throws InterruptedException {

		try {
			Thread.sleep(1000);
			waitTillElementVisible(totalValue);
			verifyElementPresent(totalValue);
			String buttonColor = totalValue.getCssValue("background-color");
			String c = Color.fromString(buttonColor).asHex();
			String[] arrColor = c.split("#");
			String buttonTextColor = totalValueheader.getCssValue("background-color");
			String c1 = Color.fromString(buttonTextColor).asHex();
			String[] arrColor1 = c1.split("#");
			System.out.println("Button color: " + c);
			System.out.println("Text color " + c1);
			Assert.assertNotEquals(arrColor[1], arrColor1[1], "Colors are matching");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceStatus(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceStatus);
			Thread.sleep(2000);
			ClearanceStatus = clearanceStatus.getText();
			System.out.println(ClearanceStatus);
			if (ClearanceStatus.contains(value)) {
				Assert.assertTrue(true, ClearanceStatus + "<>" + value + " is displayed");
			} else {
				Assert.assertTrue(false, ClearanceStatus + "<>" + value + " is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_sortCodesInTeamList() throws InterruptedException {
		try {
			Thread.sleep(2000);
			scrollIntoViewUsingJavaScript(firstRecordSelCode);
			// firstRecordSelCode.click();
			String selcode = firstRecordSelCode.getText();
			String[] arrSplit = selcode.split(",");
			for (int i = 0; i < arrSplit.length; i++) {
				System.out.println(arrSplit[i]);
				if (arrSplit[i].contains("SEC")) {
					log.info("Selection code INVIC present in Team List");
				}
			}
			// String firstSC = arrSplit[0];
			// log.info(firstSC);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Selection codes are not present in Team List");
		}
	}

	public void save_AWB() throws InterruptedException {
		try {
			Thread.sleep(1000);
			String firstAWBGBS = GlobalSearchFirstAWB.getText();
			log.info("AWB number is:" + firstAWBGBS);
			String fstAWBGBS = GlobalSearchFirstAWB.getAttribute("value");
			log.info("AWB number is:" + fstAWBGBS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_Autosuggestion(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceStatus);
			Thread.sleep(2000);
			String SortDesc = SuggestionSortDescription.getText();
			String SelCode = SuggestionSelectionCode.getText();
			System.out.println(SortDesc);
			System.out.println(SelCode);
			if (SortDesc.contains(value) && SelCode.contains(value)) {
				System.out.println("" + value + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SearchImporter_LinkImporter(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			verifyElementPresent(ImporterIcon);
			SearchImporter.click();
			Thread.sleep(3000);
			waitTillElementVisible(SearchCompanyName);
			SearchCompanyName.sendKeys(value);
			Thread.sleep(1000);
			CustomerMatchingPage.GoButton.click();
			Thread.sleep(5000);
			mouseHover(ImporterDetails);
			clickElementUsingJavaScript(LinkImporterDC);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SearchConsignee_LinkImporter() throws InterruptedException {
		try {
			Thread.sleep(1000);
			verifyElementPresent(ConsigneeIcon);
			SearchConsigneeDC.click();
			Thread.sleep(3000);
			waitTillElementVisible(SearchCompanyNameConsignee);
			SearchCompanyNameConsignee.sendKeys("a");
			Thread.sleep(1000);
			CustomerMatchingPage.GoButton.click();
			Thread.sleep(5000);
			clickElementUsingJavaScript(LinkConsigneeDC);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_HSCodeMultimatchIcon() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollDownUsingJavaScript();
			waitTillElementVisible(yellowMultimatchIcon);
			yellowMultimatchIcon.isDisplayed();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void zoom() {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("document.body.style.zoom = '0.75'");
	}

	public void InputHSCode_SearchHSCode() throws InterruptedException {
		try {
			Thread.sleep(1000);
			HSCodeInput.sendKeys("100");
			waitTillElementVisible(HSCodeSearchbox);
			HSCodeSearchbox.click();
			Thread.sleep(5000);
			waitTillElementVisible(HSCodeInputWCOTariff);
			HSCodeInputWCOTariff.click();
			ApplicationFunctions.zoomOutUsingRobotClass();
			Thread.sleep(2000);
			SubmitHSCode.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_HSCodeMatchIcon() throws InterruptedException {
		try {
			waitTillElementVisible(GreenMatchIcon);
			GreenMatchIcon.isDisplayed();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_BillDuty(String value) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(DTBill);
			mouseHover(DTBill);
			Thread.sleep(2000);
			verifyElementPresent(AccountLocationValue);
			String actualTooltip = AccountLocationValue.getText();
			System.out.println("Actual Title of Tool Tip:" + actualTooltip);
			if (actualTooltip.equals(value)) {
				System.out.println("" + actualTooltip + " is displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_NotBillDuty(String value) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(DTBill);
			mouseHover(DTBill);
			Thread.sleep(2000);
			verifyElementPresent(AccountLocationValue);
			String actualTooltip = AccountLocationValue.getText();
			System.out.println("Actual Title of Tool Tip:" + actualTooltip);
			if (!actualTooltip.equals(value)) {
				System.out.println("" + actualTooltip + " is displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_IncoTerm(String Value) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(Incoterm);
			String str = getFirstSelectedOption(Incoterm);
			if (str.equals(Value)) {
				System.out.println("Displayed dropdown option is" + Value);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Read_AWBNumbers() throws InterruptedException {
		try {
			Thread.sleep(2000);
			firstAWB = firstRecordAWB.getText().trim();
			SecondAWB = SecondRecordAWB.getText().trim();
			ThirdAWB = ThirdRecordAWB.getText().trim();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_next() throws InterruptedException {
		try {
			clickElementUsingJavaScript(nextShipment);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Verify_AWBNumbers() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(AWBNumberDeclarationScreen);
			String[] strMode = AWBNumberDeclarationScreen.getText().split(" ");
			awbNumberSplitted = strMode[1].trim();
			System.out.println(firstAWB);
			System.out.println(awbNumberSplitted);
			Assert.assertEquals(firstAWB, awbNumberSplitted);

			scrollDownUsingJavaScript();
			clickElementUsingJavaScript(nextShipment);
			Thread.sleep(2000);
			waitTillElementVisible(AWBNumberDeclarationScreen);
			System.out.println(SecondAWB);
			System.out.println(awbNumberSplitted);
			Assert.assertEquals(SecondAWB, awbNumberSplitted);

			scrollDownUsingJavaScript();
			clickElementUsingJavaScript(nextShipment);
			Thread.sleep(2000);
			waitTillElementVisible(AWBNumberDeclarationScreen);
			System.out.println(ThirdAWB);
			System.out.println(awbNumberSplitted);
			Assert.assertEquals(ThirdAWB, awbNumberSplitted);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void COM_dropdownvalues() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			Description.click();
			Thread.sleep(2000);
			Select s = new Select(COMfield);
			List<WebElement> op = s.getOptions();
			int size = op.size();
			for (int i = 0; i < size; i++) {
				String[] options = op.get(i).getText().split(":");
				String trimmedvalue = options[0].trim();
				if (trimmedvalue.matches("BQ|GL|LI|MC|PR|TJ|TV|WF") && !trimmedvalue.equals("AN")
						&& !trimmedvalue.equals("BU")) {
					System.out.println("Conditions are met");
				} else {
					System.out.println("Conditions are not met");
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Read_ClearanceModeDD(String Value) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			getFirstSelectedOption(clrMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModeDD(String Value) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			String str = getFirstSelectedOption(clrMode);
			if (str.equals(Value)) {
				System.out.println("Displayed dropdown option is" + Value);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModeafterChange() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			String clearanceMode = getFirstSelectedOption(clrMode);
			String defermentTypeStr = defermentType.getText().split(":")[1].trim();
			Assert.assertEquals(clearanceMode, defermentTypeStr, "Clearance Mode Not Equal");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Read_ClearanceMode() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			clrModeDI = getFirstSelectedOption(clrMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModeUnchanged() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			String str = getFirstSelectedOption(clrMode);
			if (str.equals(clrModeDI)) {
				System.out.println("Displayed dropdown option remains unchanged");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModechanged() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(clrMode);
			String str = getFirstSelectedOption(clrMode);
			Assert.assertNotEquals(clrModeDI, str, "Clearance Mode Not Equal");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cpMatch_OverridableAlert(String alertvalue) throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			// verifyElementPresent(highCPMatchAlert);
			verifyElementPresent(driver.findElement(By.xpath("//*[contains(text(),'" + alertvalue + "')]")));
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clear_commodityDescription() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			commodityDescriptionTextArea.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.BACK_SPACE));
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_sort_message_code(String value1, String value2) throws InterruptedException {
		// click_floatSortMessage();
		Thread.sleep(2000);
		clickElementUsingJavaScript(SortMessage);
		Thread.sleep(1000);
		// btnFloatSortFilter.click();
		clickElementUsingJavaScript(btnFloatSortFilter);
		Thread.sleep(1000);
		scrollIntoViewUsingJavaScript(txtFloatSortFilter);
		Thread.sleep(1000);
		txtFloatSortFilter.sendKeys(value1);
		Thread.sleep(1000);
		clickElementUsingJavaScript(firstsortMessage);
		Thread.sleep(1000);
		txtFloatSortFilter.clear();
		Thread.sleep(1000);
		txtFloatSortFilter.sendKeys(value2);
		Thread.sleep(1000);
		clickElementUsingJavaScript(firstsortMessage);
		Thread.sleep(1000);
		scrollDownUsingJavaScript();
		clickElementUsingJavaScript(btnFloatUploadSave);

	}

	public void Enter_CommodityDescription(String commodity) throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(CommodityDescription);
			CommodityDescription.clear();
			Thread.sleep(1000);
			CommodityDescription.sendKeys(commodity);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Verify_CommodityDescription() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(Description);
			System.out.println(Description.getText());
			Assert.assertNotEquals(commodity, Description.getText());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceSchemeNot(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceScheme);
			Thread.sleep(2000);
			ClearanceScheme = clearanceScheme.getText();
			if (!ClearanceScheme.contains(value)) {
				System.out.println("" + value + " is not displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceModeNot(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceMode);
			Thread.sleep(2000);
			ClearanceMode = clearanceMode.getText();
			if (!ClearanceMode.contains(value)) {
				System.out.println("" + value + " is not displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceMode(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceMode);
			Thread.sleep(2000);
			ClearanceMode = clearanceMode.getText();
			if (ClearanceMode.contains(value)) {
				System.out.println("" + value + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ConsigneeCompany_MDE() throws InterruptedException {
		try {
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(consigneeCompanyMDE);
			List<WebElement> Toggle = driver.findElements(By.xpath("//*[@id='Consignee Company-MDE']"));
			if (Toggle.size() != 0) {
				Thread.sleep(1000);
				clickElementUsingJavaScript(consigneeCompanyMDE);
				Thread.sleep(1000);

			} else
				System.out.println("Toggle is already off");

			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Column_IOR() throws InterruptedException {
		try {
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(columnIOR);
			clickElementUsingJavaScript(columnIOR);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_SelectionCode(String value) throws InterruptedException {
		try {
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(ManifestCheckPage.selectionCode);
			Thread.sleep(3000);
			SelectionCode = ManifestCheckPage.selectionCode.getText();
			if (SelectionCode.contains(value)) {
				Assert.assertTrue(true, SelectionCode + "<>" + value + " is displayed");
			} else {
				Assert.assertTrue(false, SelectionCode + "<>" + value + " is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_AutoEDIFlag(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(autoEDIFlag);
			Thread.sleep(3000);
			AutoEDIFlag = autoEDIFlag.getText();
			if (SelectionCode.contains(value)) {
				System.out.println("" + value + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_SelectionCodeNot(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(ManifestCheckPage.selectionCode);
			Thread.sleep(2000);
			SelectionCode = ManifestCheckPage.selectionCode.getText();
			if (!SelectionCode.contains(value)) {
				System.out.println("" + value + " is not displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_CommodityGroup(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(commodityCategory);
			Thread.sleep(2000);
			CommodityCategory = commodityCategory.getText();
			if (CommodityCategory.contains(value)) {
				System.out.println("" + value + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ColumnConfiguration_threeDots() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(columnConfiguration);
			clickElementUsingJavaScript(columnConfiguration);
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ContextMenu_dropdown() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(lnkContext);
			clickElement(lnkContext);
			waitTillElementVisible(LoginPage.country_Dpdn);
			WebElement drop = LoginPage.country_Dpdn;
			Select objSelect = new Select(drop);
			List<WebElement> options = objSelect.getOptions();
			System.out.print(objSelect.getOptions());
			for (int i = 1; i <= options.size(); i++) {
				String ele = options.get(i).getText();
				if (ele.contains("-dev")) {
					System.out.println("User could able to view the -dev prefix for SG roles successfully");
				} else {
					System.out.println("User could not able to view the -dev prefix for SG roles successfully");
				}
			}
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ConsigneeCompany(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(consigneeCompany);
			Thread.sleep(2000);
			ConsigneeComp = consigneeCompany.getText();
			if (ConsigneeComp.contains(value)) {
				System.out.println("" + value + " company is displayed");

			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ConsigneeCompanySG() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(consigneeCompany);
			Thread.sleep(2000);
			ConsigneeComp = consigneeCompany.getText();
			if (ConsigneeComp.startsWith("MEDTRONIC") || ConsigneeComp.startsWith("IBM")
					|| ConsigneeComp.startsWith("HITACHI V") || ConsigneeComp.startsWith("COVIDIEN")
					|| ConsigneeComp.startsWith("ABBOTT LAB")) {
				System.out.println("" + ConsigneeComp + " company is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ConsigneeCompanyNot(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(consigneeCompany);
			Thread.sleep(2000);
			ConsigneeComp = consigneeCompany.getText();
			if (!ConsigneeComp.contains(value)) {
				System.out.println("" + value + " company is not displayed");

			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearanceLocation(String value) throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceLocation);
			Thread.sleep(2000);
			ClearanceLocation = clearanceLocation.getText();
			if (ClearanceLocation.contains(value)) {
				System.out.println("" + value + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_unworked() throws InterruptedException {
		try {
			waitTillElementVisible(clearanceStatusfilter);
			clearanceStatusfilter.click();
			filterTextBox.click();
			filterTextBox.sendKeys("UNWORKED");
			closeIcon.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void scroll_up() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(txtEntryBuild);
			scrollUpUsingJavaScript();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void Shipment_details() throws InterruptedException {
		try {
			Thread.sleep(2000);
			String gst = DIGst.getAttribute("disabled");
			System.out.println(gst);
			DIGst.getAttribute("disabled").equalsIgnoreCase("true");
			DICif.getAttribute("disabled").equalsIgnoreCase("true");
			ExchangeRate.isDisplayed();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void selectioncodeNotExist(String data1, String data2) throws InterruptedException {
		int i;
		boolean flag = false;
		try {
			Thread.sleep(2000);
			String stringEle = "return document.getElementById('fx-gn-eb-declaration-information-sortMsgs').value;";
			Thread.sleep(2000);
			String selectionCode = (String) js.executeScript(stringEle);
			String[] arrsplit = selectionCode.split(",");
			for (i = 0; i < arrsplit.length; i++) {
				if (!((arrsplit[i]).trim().equalsIgnoreCase(data1) || (arrsplit[i]).trim().equalsIgnoreCase(data2))) {
					flag = true;
					System.out.println("Selection Codes not found in entry build  declaration page:" + arrsplit[i]);

				} else {
					flag = false;
					System.out.println("Selection Codes found in entry build declaration page :" + arrsplit[i]);
				}
			}
			if (i == arrsplit.length - 1) {
				System.out.println("Value of flag is:" + flag);
				assertEquals(flag, true);
				log.atInfo().log("Selection code not found :" + data1);
				log.atInfo().log("Selection code not found :" + data2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void verify_sortCodeExistance(String data1, String data2) throws InterruptedException {
		int i, j;
		boolean flag = false;
		String stringEle = "return document.getElementById('fx-gn-eb-declaration-information-sortMsgs').value;";
		Thread.sleep(2000);

		String selectionCode = (String) js.executeScript(stringEle);
		Thread.sleep(2000);
		System.out.println("Available selection Codes on floating panel :" + selectionCode);
		String[] arrsplit = selectionCode.split(",");
		try {
			Thread.sleep(2000);
			for (i = 0; i < arrsplit.length; i++) {
				if ((arrsplit[i]).trim().equalsIgnoreCase(data1)) {
					flag = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (flag) {
			log.info("Selection code " + data1 + " successfully added");
		} else {
			System.err.println("Selection code " + data1 + " not added to declaration screen");
			log.info("Selection code " + data1 + " not added to declaration screen");
			Assert.fail("Sort Code not found in the declaration screen");
		}
		try {
			for (j = 0; j < arrsplit.length; j++) {
				if ((arrsplit[j]).trim().equalsIgnoreCase(data2)) {
					flag = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (flag) {
			log.info("Selection code " + data2 + " successfully added");
		} else {
			System.err.println("Selection code " + data2 + " not added to declaration screen");
			log.info("Selection code " + data2 + " not added to declaration screen");
			Assert.fail("Sort Code not found in the declaration screen");
		}
	}

	public void update_totalValue() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(totalValue);
			totalValue.clear();
			totalValue.sendKeys("80000");
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DoubleClick_commodityDetails() throws InterruptedException {
		try {
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(commoditySlno);
			Thread.sleep(3000);
			commoditySlno.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_GIFCIFValue() throws InterruptedException {
		try {
			Thread.sleep(10000);
			String ciftext = cifValue.getText();
			String giftext = gifValue.getText();
			System.out.println(ciftext);
			System.out.println(giftext);
			Thread.sleep(1000);
			int cif = (int) Double.parseDouble(ciftext);
			int gif = (int) Double.parseDouble(giftext);
			int value = 7000;
			Thread.sleep(1000);
			if (cif > value && gif > value) {
				System.out.println("cif and gif values are greater than 7000");
			} else {
				System.out.println("values are not greater");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void cifgif_OverridableAlert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(highCIFAlert);
			verifyElementPresent(highGIFAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void modify_ClearanceSchemeGf() throws InterruptedException {
		try {
			waitTillElementVisible(clearanceModeG7);
			clearanceModeG7.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void validate_Button() throws InterruptedException {
		try {
			Thread.sleep(5000);
			scrollDownUsingJavaScript();
			Thread.sleep(3000);
			waitTillElementVisible(validateButton);
			validateButton.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void lvTruckG7_OverridableAlert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(LVTruckG7OverridableAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_entry_Build() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(2000);
			waitTillElementVisible(txtEntryBuild);
			txtEntryBuild.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_acssShipmentsEB() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			waitTillElementVisible(acssShipmentstoggleentrybuild);
			acssShipmentstoggleentrybuild.click();
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_acssShipmentsEntryBuild() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(acssShipmentstoggleentrybuild);
			acssShipmentstoggleentrybuild.click();
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ConsigneeCompanyMDE_ShipmentResults() {
		try {
			scrollByUsingJavaScript();
			Thread.sleep(2000);
			scrollIntoViewUsingJavaScript(ConsigneeCompanyMDEShipmentResults);
			Thread.sleep(2000);
			ConsigneeCompanyMDEShipmentResults.isDisplayed();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void IOR_ShipmentResults() {
		try {
			scrollByUsingJavaScript();
			Thread.sleep(2000);
			scrollIntoViewUsingJavaScript(IORShipmentResults);
			Thread.sleep(2000);
			IORShipmentResults.isDisplayed();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void click_filterEntryBuildCustomerCompetency() throws InterruptedException {
		try {
			Thread.sleep(10000);
			waitTillElementVisible(filterAWBNumber);
			filterAWBNumber.click();
			filterTextBox.click();
			filterTextBox.sendKeys(ManifestCheckPage.AWBno);
			closeIcon.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_filterEntryBuild() throws InterruptedException {
		try {
			Thread.sleep(10000);
			waitTillElementVisible(filterAWBNumberCusCom);
			filterAWBNumberCusCom.click();
			filterTextBox.click();
			filterTextBox.sendKeys(ManifestCheckPage.AWBno);
			closeIcon.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_filterCustomerCompetency() throws InterruptedException {
		try {
			Thread.sleep(5000);
			ManifestCheckPage.userList.click();
			Thread.sleep(2000);
			ManifestCheckPage.teamList.click();
			Thread.sleep(5000);
			waitTillElementVisible(ManifestCheckPage.acssShipmentstoggle);
			ManifestCheckPage.acssShipmentstoggle.click();
			Thread.sleep(10000);
			waitTillElementVisible(filterAWBNumberCusCom);
			filterAWBNumberCusCom.click();
			filterTextBox.click();
			filterTextBox.sendKeys(ManifestCheckPage.AWBno);
			closeIcon.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_shipmentInEntryBuild() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumberEntryBuild);
			String AWBNoEntryBuild = AWBNumberEntryBuild.getText().trim();
			System.out.println("AWB Number: " + AWBNoEntryBuild);
			Assert.assertEquals(AWBNoEntryBuild, ManifestCheckPage.AWBNumber.getText());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void close_driver() throws InterruptedException {
		try {
			driver.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//---------------------------PRITHVI methods----------------------------------------------------------

	public void click_entryBuild() throws InterruptedException {
		try {
			checkElementIsVisible(txtEntryBuild);
			txtEntryBuild.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_firstRecordAWB() throws InterruptedException {
		try {
			checkElementIsVisible(firstRecordAWB);
			firstRecordAWB.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String get_firstRecordAWB() throws InterruptedException {
		try {
			checkElementIsVisible(firstRecordAWB);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return firstRecordAWB.getText();
	}

	public String get_firstRecordSelCode() throws InterruptedException {
		return firstRecordSelCode.getText();

	}

	public String get_firstRecordCIFlag() throws InterruptedException {
		return firstRecordCIFlag.getText();

	}

	public void click_filterAWB() throws InterruptedException {
		try {
			Thread.sleep(2000);
			btnFilterAWB.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_filterIn() throws InterruptedException {
		try {
			Thread.sleep(2000);
			ManageFilterIn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Select_AllToggle() throws InterruptedException {
		try {
			Thread.sleep(2000);
			SelectAllToggle.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_filterAWBMC() throws InterruptedException {
		try {
			Thread.sleep(2000);
			btnFilterAWBMC.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_filterCI() throws InterruptedException {
		try {
			btnFilterCI.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void set_filter(String value) {
		try {
			txtFilter.clear();
			txtFilter.sendKeys(value);
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void click_filterClose() throws InterruptedException {

		try {
			btnFilterClose.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void click_assignToMe() throws InterruptedException {
		try {
			btnAssignToMe.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatSortMessage() throws InterruptedException {
		try {
			btnFloatSortMessage.click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void click_floatSortMessageNew() throws InterruptedException {
		try {
			btnFloatSortMessageNew.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatAncilary() throws InterruptedException {
		try {
			btnFloatAncilary.click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_floatActivityLog() throws InterruptedException {
		try {
			Thread.sleep(1000);
			btnFloatActivityLog.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_ActivityLog() throws InterruptedException {
		try {
			// btnFloatActivityLog.click();
			Thread.sleep(2000);
			waitTillElementVisible(btnFloatActivityLog);
			clickElementUsingJavaScript(btnFloatActivityLog);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void activityLog(String ActivityName) {
		try {

			// waitTillElementVisible(lnkCloseFloatingPanel);
			Thread.sleep(1000);
			if (ActLog_SelectionCode.getText().equalsIgnoreCase(ActivityName)) {
				log.info("Selection Code is found");
			} else {
				log.error("Selection Code is found");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Selection Code is found");
		}
	}

	public void click_floatNotification() throws InterruptedException {
		try {
			btnFloatNotification.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void click_floatUpload() throws InterruptedException {
		try {
			btnFloatUpload.click();
			btnFilterClose.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_floatUploadLocation(String location) throws InterruptedException {
		try {
			selFloatUploadLocation.selectByVisibleText(location);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_floatUploadDocumentType(String docType) throws InterruptedException {
		try {
			selFloatUploadDocumentType.selectByVisibleText(docType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatUploadBrowseFile() throws InterruptedException {
		// btnFloatUploadBrowseFiles

	}

	public void click_floatUploadSave() throws InterruptedException {
		try {
			btnFloatUploadSave.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_floatUploadSaveNew() throws InterruptedException {
		try {
			btnFloatUploadSaveNew.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatUploadCancel() {
		try {
			clickElementUsingJavaScript(btnFloatUploadCancel);
			//btnFloatUploadCancel.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatSortFilter() {
		try {
			btnFloatSortFilter.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatSortFilterNew() {
		try {
			btnFloatSortFilterNew.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void set_floatSortFilter(String value) {
		try {
			txtFloatSortFilter.clear();
			txtFloatSortFilter.sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_floatSortToggle() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", chkFloatSortToggle);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void click_firstSortToggle() {
		try {
			firstsortMessage.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String get_sortMessages() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return (String) js.executeScript("return arguments[0].value", txtSortMessages);
	}

	public List<String> get_docDetails() {

		List<String> docNames = new ArrayList<String>();
		try {
			for (WebElement doc : lblDocDetails) {
				docNames.add(doc.getText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return docNames;
	}

	public String get_lblAWB() {
		return lblAWB.getText();

	}

	public String get_lblPopup() {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return lblPopup.getText();
	}

	public void click_addNotification() {
		try {
			scrollIntoViewUsingJavaScript(btnAddNotification);
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
			wait.until(ExpectedConditions.elementToBeClickable(btnAddNotification));
			clickElementUsingJavaScript(btnAddNotification);
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void set_comments(String value) {
		try {
			txtComments.sendKeys(value);
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void set_fp_comments(String value) {
		try {
			fp_txtComments.sendKeys(value);
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public String get_lastComment() {
		return lblLastComment.getText();

	}

	public void click_save() {

		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnSave);
			btnSave.click();
			Thread.sleep(500);
		} catch (ElementNotInteractableException e) {
			fp_btnSave.click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void click_close() throws InterruptedException {
		try {

			scrollIntoViewUsingJavaScript(btnClose);
			waitTillElementVisible(btnClose);
			Thread.sleep(2000);
			btnClose.click();
		} catch (NoSuchElementException e) {
			Thread.sleep(2000);
			e.printStackTrace();
		}
	}

	public void globalSearch_close() {
		try {
			Thread.sleep(1000);
			clickElementUsingJavaScript(GlobalSearchClose);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_userList() {
		try {
			checkElementIsVisible(btnUserList);
			btnUserList.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_teamList() {
		try {
			scrollIntoViewUsingJavaScript(ManifestCheckPage.teamList);
			checkElementIsVisible(ManifestCheckPage.teamList);
			ManifestCheckPage.teamList.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_cancel() {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnCancel);
			btnCancel.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clearanceMode_validate() throws InterruptedException {
		try {
			waitTillElementVisible(selClearanceModeInDeclaration);
			Assert.assertFalse(verify_dropdownValue_Present(selClearanceModeInDeclaration, "ROAD"),
					"ROAD option is present in ClearanceMode- Declaration Screen");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verify_dropdownValue_Present(WebElement ele, String Value) throws InterruptedException {
		boolean blnPass = false;
		waitTillElementVisible(ele);
		Select objSelect = new Select(ele);
		List<WebElement> lstvaluesInSelect = objSelect.getOptions();
		for (WebElement option : lstvaluesInSelect) {
			if (option.getText().equals(Value)) {
				blnPass = true;
			}
		}
		if (blnPass) {
			return true;
		} else {
			return false;
		}

	}

	public void select_ClearanceMode(String selValue) throws InterruptedException {

		try {
			waitTillElementVisible(selClearanceModeInDeclaration);
			selectUsingVisibleText(selClearanceModeInDeclaration, selValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void mode_of_transport(String selValue) throws InterruptedException {

		try {
			waitTillElementVisible(spnModeOfTransport);
			String[] strMode = spnModeOfTransport.getText().split(":");
			String strModeSplitted = strMode[1].trim();
			Assert.assertEquals(strModeSplitted, selValue,
					"The mode of transport diaplyed in declaration is incorrect");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void OVR_enabled(String enabledYesNO) throws InterruptedException {

		try {
			Thread.sleep(3000);
			waitTillElementVisible(txtOVRRegistration);
			Check_Enabled(enabledYesNO, txtOVRRegistration, "OVR Registration No.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void GSTPaid_enabled(String enabledYesNO) throws InterruptedException {

		try {
			waitTillElementVisible(tblCommodityRow);
			if (tblCommodityRow.getAttribute("class").equals("ng-star-inserted")) {
				DoubleClick_commodityDetails();
			}

			Check_Enabled(enabledYesNO, selGSTPaid, "GST Paid");
			Select eleGSTPaid = new Select(selGSTPaid);
			PrevGSTPaid = eleGSTPaid.getFirstSelectedOption().getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Check_Enabled(String enabledYesNO, WebElement eleObject, String ElementName)
			throws InterruptedException {
		if (enabledYesNO.equalsIgnoreCase("yes")) {
			Assert.assertTrue(eleObject.isEnabled(), ElementName + " is disabled");
		} else if (enabledYesNO.equalsIgnoreCase("no")) {
			Assert.assertFalse(eleObject.isEnabled(), ElementName + " is enabled");
		}
	}

	public void GSTPaid_previousValue() throws InterruptedException {
		try {
			Select eleGSTPaid = new Select(selGSTPaid);
			String CurrentValue = eleGSTPaid.getFirstSelectedOption().getText();
			Assert.assertEquals(PrevGSTPaid, CurrentValue, "Previous value of GST Paid not retained");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void no_alert_validation() throws InterruptedException {
		scrollUpUsingJavaScript();
		Thread.sleep(10000);
		// waitTillElementVisible(lstAlert);
		boolean blnDisplay = true;
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		try {
			lstAlert.isDisplayed();
			blnDisplay = true;
		} catch (NoSuchElementException e) {
			blnDisplay = false;
		} finally {
			Assert.assertFalse(blnDisplay, "Alerts displayed in Declaration screen");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public void OVRRegsitation_length(String value) throws InterruptedException {
		try {
			waitTillElementVisible(txtOVRRegistration);
			Assert.assertEquals(value, txtOVRRegistration.getAttribute("maxlength"),
					"Max length of OVR Registration is not" + value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/******* Gomathi *******/
	public Boolean verifyConsigneeAndImporterInEntryBuild() throws InterruptedException {
		boolean flag = false;
		try {
			if (getConsigneeCompanyName.getText().trim().equalsIgnoreCase(customerMatchPage.randomConsigneeCompanyName)
					&& getImporterCompanyName.getText().trim()
							.equalsIgnoreCase(customerMatchPage.strImporterCompanyName)) {
				flag = true;
			}
		} catch (Exception e) {

		}
		return flag;

	}

	public void verifyOrginCountry(String originValue) {
		try {
			String targeteOriginName = "";
			List<WebElement> totalTableCols = driver.findElements(By.xpath(
					"//datatable-header-cell[@class='datatable-header-cell sortable resizeable ng-star-inserted']//table//span[@class='datatable-header-cell-label draggable']"));
			List<WebElement> totalTableRowCells = driver.findElements(By.xpath(
					"//div[@class='datatable-row-center datatable-row-group ng-star-inserted']/datatable-body-cell/div/span"));
			int colSize = totalTableCols.size();
			int rowCellSize = totalTableRowCells.size();
			System.out.println("originValue : " + originValue);
			System.out.println("colSize : " + colSize);
			System.out.println("rowCellSize : " + rowCellSize);
			for (int i = 1; i < colSize; i++) {
				WebElement colHeader = driver.findElement(By.xpath(
						"(//datatable-header-cell[@class='datatable-header-cell sortable resizeable ng-star-inserted']//table//span[@class='datatable-header-cell-label draggable'])["
								+ i + "]"));
				scrollIntoViewUsingJavaScript(colHeader);
				System.out.println(
						"(//datatable-header-cell[@class='datatable-header-cell sortable resizeable ng-star-inserted']//table//span[@class='datatable-header-cell-label draggable'])["
								+ i + "]");
				String colName = driver.findElement(By.xpath(
						"(//datatable-header-cell[@class='datatable-header-cell sortable resizeable ng-star-inserted']//table//span[@class='datatable-header-cell-label draggable'])["
								+ i + "]"))
						.getText().trim();
				System.out.println("colName : " + colName);
				if (colName.equalsIgnoreCase("Origin Country")) {
					WebElement rowCell = driver.findElement(By.xpath(
							"(//div[@class='datatable-row-center datatable-row-group ng-star-inserted']/datatable-body-cell/div/span)["
									+ i + "]"));
					scrollIntoViewUsingJavaScript(rowCell);
					System.out.println(
							"(//div[@class='datatable-row-center datatable-row-group ng-star-inserted']/datatable-body-cell/div/span)["
									+ i + "]");
					targeteOriginName = driver.findElement(By.xpath(
							"(//div[@class='datatable-row-center datatable-row-group ng-star-inserted']/datatable-body-cell/div/span)["
									+ i + "]"))
							.getText().trim();
					break;
				}
			}
			System.out.println("targeteOriginName : " + targeteOriginName);
			if (targeteOriginName.equalsIgnoreCase(originValue)) {
				System.out.println("Origin Country is : " + originValue);
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateClearanceModeValueShouldNotBe(String clearanceModeVal) {
		try {
			WebElement option = ((Select) clearanceModeDropdown).getFirstSelectedOption();
			String defaultItem = option.getText().trim();
			System.out.println(defaultItem);
			if (clearanceModeVal.equalsIgnoreCase(defaultItem)) {
				System.out.println("Clearance Mode Value is : " + clearanceModeVal);
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateTransportBillAccountNumber() {
		try {
			waitTillElementVisible(transport);
			clickElement(transport);
			if ((!transportBillToAmountNumber.getText().trim().isEmpty())
					&& (!transportBillToAmountLocation.getText().trim().isEmpty())) {
				System.out.println(transportBillToAmountNumber.getText().trim());
				System.out.println(transportBillToAmountLocation.getText().trim());
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cpMatch_OverridableAlert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(highCPMatchAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void LinkSearch_consignee() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			Thread.sleep(10000);
			if (consigneeSearchIcon.isEnabled()) {
				checkElementIsVisible(consigneeSearchIcon);
				consigneeSearchIcon.click();
				ClearButton.click();
				companyName.sendKeys("a");
				GoButton.click();
				Thread.sleep(10000);
				scrollDownUsingJavaScript();
				importerBody.click();
				linkConsignee.click();
				Thread.sleep(2000);
			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void LinkSearch_importer() throws InterruptedException {
		try {
			if (importerSearchIcon.isEnabled()) {
				checkElementIsVisible(importerSearchIcon);
				importerSearchIcon.click();
				ClearButton.click();
				companyName.sendKeys("ABCELL");
				GoButton.click();
				Thread.sleep(10000);
				scrollDownUsingJavaScript();
				importerBody.click();
				linkImporter.click();
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void hsCode_OverridableAlert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(highHSCodeAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void commodity_DescriptionAlert() {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(commodityDescriptionAlert);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enter_Description(String enterVal) throws InterruptedException {
		try {
			waitTillElementVisible(txtHSCode);
			commodityDescriptionTextArea.sendKeys(enterVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Gomathi
	public void clearWeightPackageBranded() throws InterruptedException {
		try {
			Thread.sleep(5000);
			clickElementUsingJavaScript(packageValue);
			packageValue.sendKeys(Keys.CONTROL, "a");
			packageValue.sendKeys(Keys.DELETE);
			clickElementUsingJavaScript(weight);
			weight.sendKeys(Keys.CONTROL, "a");
			weight.sendKeys(Keys.DELETE);

			scrollDownUsingJavaScript();
			String rowClassAttributeValue = commodityFirstRow.getAttribute("class");
			System.out.println(rowClassAttributeValue);
			if (!rowClassAttributeValue.equals("ng-star-inserted selectedTableRow")) {
				commodityRow.click();
			}
			Thread.sleep(2000);
			branded.sendKeys(Keys.CONTROL, "a");
			branded.sendKeys(Keys.DELETE);

			System.out.println("Package : " + packageValue.getText());
			System.out.println("Weight : " + weight.getText());
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void package_alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(PackagesAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void weight_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(weightAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void branded_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(brandedAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void update_clearance_Scheme(String clearanceScheme) throws InterruptedException {
		try {
			waitTillElementVisible(clearanceSchemeDropdown);
			selectUsingVisibleText(clearanceSchemeDropdown, clearanceScheme);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deminLVClearanceScheme_OverridableAlert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(deminLVAlert);
			verifyElementPresent(checkClearanceSchemeAlert);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void update_clearance_Mode(String clearanceMode) throws InterruptedException {
		try {
			waitTillElementVisible(clearanceModeDropdown);
			selectUsingVisibleText(clearanceModeDropdown, clearanceMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void CheckLVRoadClearanceMode_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(LVRoadClearanceModelert);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void uenFailed_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(uenFailedAlert);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void select_sort_message_code(String selectionCodeVal) throws InterruptedException {
		click_floatSortMessage();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", chkFloatSortToggle);
		js.executeScript("arguments[0].click();", chkFloatSortToggle);

		btnFloatSortFilter.click();
		txtFloatSortFilter.sendKeys(selectionCodeVal);
		scrollDownUsingJavaScript();
		btnFloatUploadSave.click();

	}

	public void cageCode_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(cageCodeRequiredAlert);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void cagedMode_Alert() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			verifyElementPresent(cagedModeRequiredAlert);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void validateCIFAndGST() throws InterruptedException {
		try {
			String cifValue = cif.getAttribute("value");
			String gstValue = gst.getAttribute("value");
			if (cifValue != "" && gstValue != "") {
				System.out.println(cifValue + " " + gstValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void submitDeclaraion() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollDownUsingJavaScript();
			btnSubmitDecalartion.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_PSTCheck() {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", PSTCheck);
			PSTCheck.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public Boolean verifySelectionCode() throws InterruptedException {
		Boolean flag = false;
		try {
			String sortCode = selectionCode.getAttribute("value");
			String[] arrOfStr = sortCode.split(",");
			for (int i = 0; i <= arrOfStr.length; i++) {
				if (arrOfStr[i].equalsIgnoreCase("ADT")) {
					flag = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}

	public void verifyTeam_InEntryBuild(String teamName) throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(3000);
			WebElement teamWebElement = driver.findElement(By.xpath("//span[contains(text(),'" + teamName + "')]"));
			verifyElementPresent(teamWebElement);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void closetheActivityLogPopup() {
		try {
			Actions action = new Actions(driver);
			action.sendKeys(Keys.ESCAPE).build().perform();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doubleClick_shipmentInGlobalSearch() throws InterruptedException {
		try {
			Actions act = new Actions(driver);
			act.doubleClick(selctFirstRowInGlobalSearch).perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyTheSelectionCodeInEntryBuildDeclaration() {
		try {
			String sortCode = selectionCode.getAttribute("value");
			System.out.println("sortCode : " + sortCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean add_sortCode_declaration(String sortCode, String addRemove) throws InterruptedException {
		try {
			Thread.sleep(2000);
			Boolean blnToggled = false;
			click_floatSortMessage();
			for (String selCode : sortCode.split(",")) {
				if (addRemove.equalsIgnoreCase("add")) {
					click_floatSortFilterNew();
					set_floatSortFilter(selCode);
					Thread.sleep(1000);
					//firstsortMessage_btn.click();
					//clickElementUsingJavaScript(firstsortMessage_btn);
					//Thread.sleep(1000);
					//blnToggled = true;
					String toggleStatus = firstsortMessageToggle.getAttribute("ng-reflect-is-toggle-switched");
					if (!toggleStatus.equalsIgnoreCase("true")) {
						clickElementUsingJavaScript(firstsortMessage_btn);
						Thread.sleep(1000);
						blnToggled = true;
					}
				}
				if (addRemove.equalsIgnoreCase("remove")) {
					click_floatSortFilterNew();
					set_floatSortFilter(selCode);
					Thread.sleep(1000);
					//clickElementUsingJavaScript(firstsortMessage_btn);
					//Thread.sleep(1000);
					//blnToggled = true;
					String toggleStatus = firstsortMessageToggle.getAttribute("ng-reflect-is-toggle-switched");
					if (toggleStatus.equalsIgnoreCase("true")) {
						clickElementUsingJavaScript(firstsortMessage_btn);
						Thread.sleep(1000);
						blnToggled = true;
					}
				}
				if (addRemove.equalsIgnoreCase("No")) {
					click_floatSortFilter();
					set_floatSortFilter(selCode);
					blnToggled = true;
				}
			}
			if (blnToggled) {
				Thread.sleep(500);
				click_floatUploadSaveNew();
				return blnToggled;
			} else {
				Thread.sleep(500);
				click_floatUploadCancel();
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public void check_GST_declaraion(String greaterLesserEqual, String GSTValue) throws InterruptedException {
		try {
			waitTillElementVisible(GSTInDeclaration);
			String strGST = GSTInDeclaration.getAttribute("value");
			float fltActualGST = Float.parseFloat(strGST);
			float fltPassedGST = Float.parseFloat(GSTValue);
			if (greaterLesserEqual.equals(">")) {
				Assert.assertTrue((fltActualGST > fltPassedGST), "GST is not geater than " + GSTValue);
			} else if (greaterLesserEqual.equals("<")) {
				Assert.assertTrue((fltActualGST < fltPassedGST), "GST is not lesser than " + GSTValue);
			} else if (greaterLesserEqual.equals("<")) {
				Assert.assertTrue((fltActualGST == fltPassedGST), "GST is not equal to  " + GSTValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clearOverideAlerts() throws InterruptedException {
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
			if (lstOverridableAlertLink.isDisplayed()) {
				for (WebElement eleAlertLink : lstOverridableAlertLinks) {
					clickElementUsingJavaScript(eleAlertLink);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public void submitDeclaration() throws InterruptedException {

		try {
			waitTillElementVisible(btnSubmitDecalartion);
			clickElementUsingJavaScript(btnSubmitDecalartion);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void checkToggleofTeam(String teamName, String toggleONOFF) {

		try {
			String strToggleOfTeamName = "//label[@class='custom-control-label']/span[text()='" + teamName
					+ "']//ancestor::genius-toggle-switch";
			WebElement eleToggle = driver.findElement(By.xpath(strToggleOfTeamName));
			String toggleONOFFActual = eleToggle.getAttribute("ng-reflect-is-toggle-switched");
			if (toggleONOFF.equalsIgnoreCase("ON")) {
				Assert.assertEquals("true", toggleONOFFActual, teamName + " Team Toggle is not ON");
			} else if (toggleONOFF.equalsIgnoreCase("OFF")) {
				Assert.assertEquals("false", toggleONOFFActual, teamName + " Team Toggle is not OFF");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean addColumn_InCC(String columnNames) {
		try {
			String byColumnNames;
			WebElement eleColumnToggle;
			Boolean blnToggled = false;
			waitTillElementVisible(btnColumnConfig);
			clickElementUsingJavaScript(btnColumnConfig);
			for (String selCol : columnNames.split(",")) {
				byColumnNames = "//input[@id='" + selCol + "']/ancestor::genius-toggle-switch";
				eleColumnToggle = driver.findElement(By.xpath(byColumnNames));
				new Actions(driver).moveToElement(columnConfigWindow).perform();
				scrollIntoViewUsingJavaScript(eleColumnToggle);
				if (eleColumnToggle.getAttribute("ng-reflect-is-toggle-switched").equals("false")) {
					clickElementUsingJavaScript(eleColumnToggle.findElement(By.name("columnToggle")));
					blnToggled = true;
				}
			}
			if (blnToggled) {
				clickElement(btnSaveColumn);
				return true;
			} else {
				clickElement(btnCancelColumn);
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	public void cycleDataPresent() throws InterruptedException {
		try {

			boolean blnDate = true;
			boolean blnNumber = true;
			for (WebElement eleCycleDate : spnCycleDate) {
				if (eleCycleDate.getText().trim().isEmpty()) {
					blnDate = false;
				}
			}
			for (WebElement eleCycleNumber : spnCycleNumber) {
				if (eleCycleNumber.getText().trim().isEmpty()) {
					blnNumber = false;
				}
			}
			Assert.assertTrue(blnDate, "Cycle Date is not Generated");
			Assert.assertTrue(blnNumber, "Cycle Number is not Generated");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clearHSCodeAlert() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		try {

			if (spnHSCodeAlert.isDisplayed()) {
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				waitTillElementVisible(tblCommodityRow);
				for (WebElement eleCommodityRow : tblCommodityRows) {
					if (eleCommodityRow.getAttribute("class").equals("ng-star-inserted")) {
						clickElementUsingJavaScript(eleCommodityRow);

					}
					waitTillElementVisible(txtHSCodeClicked);
					if (txtHSCodeClicked.getAttribute("value").trim() == "") {
						txtHSCodeClicked.sendKeys("52030000");
						Thread.sleep(2000);
						txtHSCodeClicked.sendKeys(Keys.TAB);
						waitTillElementVisible(lnkGreenIcon);
						if (txtQuantityClicked.getAttribute("value") == ""
								|| txtQuantityClicked.getAttribute("value").equals("0")) {
							txtQuantityClicked.sendKeys("1");
						}
					}
				}
			}

		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}

		finally {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public boolean clearCAGEModelert() throws InterruptedException {
		click_floatSortMessageNew();
		boolean blnToggled = false;
		click_floatSortFilterNew();
		set_floatSortFilter("GEM");
		Thread.sleep(1000);
		String toggleStatus = firstsortMessageToggle.getAttribute("ng-reflect-is-toggle-switched");
		if (toggleStatus.equalsIgnoreCase("true")) {
			firstsortMessage.click();
			Thread.sleep(1000);
			blnToggled = true;
		}
		if (blnToggled) {
			Thread.sleep(500);
			click_floatUploadSave();
			return blnToggled;
		} else {
			Thread.sleep(500);
			click_floatUploadCancel();
			return false;
		}
	}

	public void clearanceStatusInDeclaraion(String strValue) {
		try {
			waitTillElementVisible(txtClrStatusInDeclaration);
			Assert.assertEquals(txtClrStatusInDeclaration.getAttribute("value").trim(), strValue,
					"Clearance status is not set as " + strValue);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void addConsigneeInDeclaration(String name) {
		try {
			waitTillElementVisible(btnConsigneeSearch);
			clickElement(btnConsigneeSearch);
			txtConsigneeName.sendKeys(name);
			clickElement(btnGoConsigneeSearch);
			waitTillElementVisible(btnLinkConsignee);
			clickElement(btnLinkConsignee);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}
	
	public void addImporterInDeclaration(String name) {
		try {
			waitTillElementVisible(btnImporter);
			clickElement(btnImporter);
			inpImporterName.sendKeys(name);
			clickElement(GoButton);
			Thread.sleep(3000);
			mouseHover(ImporterDetails);
			clickElementUsingJavaScript(LinkImporterDC);
			Thread.sleep(2000);
			
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void clickHVUSubmit() {
		try {
			waitTillElementVisible(btnHVUSubmit);
			clickElement(btnHVUSubmit);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void activityLogCheck(String ActivityName) {
		try {

			waitTillElementVisible(lnkCloseFloatingPanel);
			boolean blnActFound = true;
			String ExpActivityName = ActivityName.replace(":", "").trim();
			for (WebElement eleActivity : lstActivityLogList) {
				if (eleActivity.getText().equals(ExpActivityName)) {
					log.info(eleActivity.getText());
					blnActFound = true;
					break;
				}
			}
			log.info(ExpActivityName);
			Assert.assertTrue(blnActFound, "Activity log not displayed as " + ActivityName);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void closefloatActivityLog() throws InterruptedException, AWTException {
		zoomOutUsingRobotClass();
		waitTillElementVisible(lnkCloseFloatingPanel);
		Thread.sleep(7000);
		clickElement(lnkCloseFloatingPanel);
		Thread.sleep(3000);

	}

	public boolean unassignAllShipment() throws InterruptedException {
		boolean blnflg = false;
		waitTillElementVisible(toggleAllAWBinList);
		// handling for global list
		if (toggleAllAWBinList.getAttribute("ng-reflect-is-toggle-switched").equals("false")) {
			clickElementUsingJavaScript(inpAllToggle);
			unassign_shipment();
			blnflg = true;

		}
		return blnflg;
	}

	public void clickCycleChanges() {
		waitTillElementVisible(btnCycleChanges);
		clickElement(btnCycleChanges);
	}

	public void setCycleDate(int daysofIncreamantCycleDate) throws InterruptedException {
		try {
			clickElement(btnCalender);

			Calendar cal = Calendar.getInstance();
			SimpleDateFormat dtformatter = new SimpleDateFormat("d-MMM-yyyy");
			Date date = new Date();
			cal.setTime(date);
			cal.add(Calendar.DATE, daysofIncreamantCycleDate); // minus number would decrement the days
			String strDate = dtformatter.format(cal.getTime());
			String[] strdateSplit = strDate.split("-");

			selectUsingVisibleText(selMonth, strdateSplit[1]);
			Thread.sleep(1000);
			selectUsingVisibleText(selYear, strdateSplit[2]);
			Thread.sleep(1000);
			WebElement eleDate = driver.findElement(
					By.xpath("//div[text()='" + strdateSplit[0] + "'][@class='btn-light ng-star-inserted']"));
			clickElement(eleDate);

			Thread.sleep(1000);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
			if (eleSearch.isDisplayed()) {
				//eleSearch.click();
				clickElementUsingJavaScript(eleSearch);
			}
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public void selectCycleNumber(String CycleNumber) {

		try {
			selectUsingVisibleText(selCycleNumber, CycleNumber);
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void CycleChangeDisabled() {
		try {
			Assert.assertTrue(eleCycleChangeFloatingPanelDisabled.isDisplayed(), "Cycle Changes button disabled");
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void click_EDIReadyTeamleader() {
		try {
			waitTillElementVisible(eleEDIReadytoggleTeamLeader);
			clickElement(eleEDIReadytoggleTeamLeader);
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void clickCycleChangesFloatingPanel() {

		try {
			waitTillElementVisible(eleCycleChangeFloatingPanelEnabled);
			clickElement(eleCycleChangeFloatingPanelEnabled);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void selectShipmentTeamLeaderList() {
		try {
			waitTillElementVisible(AWBNumberEntryBuild);
			clickElement(AWBNumberEntryBuild);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void clickConsoleSubmission() {
		waitTillElementVisible(btnConsoleSubmission);
		clickElementUsingJavaScript(btnConsoleSubmission);

	}

	public void selectRecConsoleSubmissionwithCycleNumber(String Number) throws InterruptedException {
		try {
			clickElement(eleCycleNumFilter);
			set_filter(Number);
			click_filterClose();
			Thread.sleep(2000);
			clickElementUsingJavaScript(spnCycleNumberConsoleSubmission);
			CycleDate = spnCycleDateConsoleSubmission.getText();
			String[] strSplitCycle = CycleDate.split("/");
			if (strSplitCycle[1].substring(0, 1).equals("0")) {
				CycleDate = CycleDate.replace(strSplitCycle[1], strSplitCycle[1].substring(1));
			}
			CycleNo = spnCycleNumberConsoleSubmission.getText();
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public void verifyHAWBCount(int count) {
		try {
			int intHAWBCount = Integer.parseInt(eleHAWB.getText());
			Assert.assertTrue(intHAWBCount > count, "HAWB count in console submission is not greater than " + count);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void cancelConsoleSubmission() {
		try {
			waitTillElementVisible(btnCancelConsoleSubmission);
			clickElement(btnCancelConsoleSubmission);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public void selectMultipleShipments() {
		clickElementUsingJavaScript(inpAllToggle);

	}

	public void HSCode_noMatch() throws InterruptedException {
		try {
			waitTillElementVisible(txtHSCodeClicked);
			String strHSCodeValue = txtHSCodeClicked.getAttribute("class");
			Assert.assertTrue(strHSCodeValue.contains("hasNoValue"), "HS Code is not blank");
			Assert.assertTrue(lnkOrangeIcon.isDisplayed(), "Orange Harmonized Code Match Icon is not present");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enter_HSCode(String enterVal) throws InterruptedException {

		try {
			waitTillElementVisible(txtHSCodeClicked);
			txtHSCodeClicked.clear();
			txtHSCodeClicked.sendKeys(enterVal);
			txtHSCodeClicked.click();
			txtHSCodeClicked.sendKeys(Keys.TAB);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void HSCode_Match() throws InterruptedException {
		try {
			waitTillElementVisible(txtHSCodeClicked);
			String strHSCodeValue = txtHSCodeClicked.getAttribute("class");
			Assert.assertTrue(strHSCodeValue.contains("hasValue"), "HS Code is blank");
			Assert.assertTrue(lnkGreenIcon.isDisplayed(), "Green Harmonized Code Match Icon is not present");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickCommodity() throws InterruptedException {
		try {
			waitTillElementVisible(tblCommodityRow);

			if (tblCommodityRow.getAttribute("class").equals("ng-star-inserted")) {
				DoubleClick_commodityDetails();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void enterQuantityCommodity(String strQuantity) {
		try {
			waitTillElementVisible(txtQuantityClicked);
			txtQuantityClicked.sendKeys(Keys.CONTROL, "a");
			txtQuantityClicked.sendKeys(Keys.DELETE);
			txtQuantityClicked.sendKeys(strQuantity);
			txtQuantityClicked.click();
			Thread.sleep(1000);
			txtQuantityClicked.sendKeys(Keys.TAB);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alertMessageVerification(String strMsg) {
		try {
			Assert.assertEquals(eleAlertMsg.getText().trim(), strMsg.trim(),
					"Alert message is not displayed as " + strMsg);
			waitForInvisibility(eleAlertMsg, 10);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void waitForInvisibility(WebElement webElement, int maxSeconds) {
		Long startTime = System.currentTimeMillis();
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
			while (System.currentTimeMillis() - startTime < maxSeconds * 1000 && webElement.isDisplayed()) {
			}
		} catch (NoSuchElementException e) {
			return;
		} catch (StaleElementReferenceException e) {
			return;
		} finally {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public void enterTotalValue(String strTotVal) {
		try {
			Thread.sleep(1000);
			inpTotalValue.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.BACK_SPACE));
			inpTotalValue.sendKeys(strTotVal);
			inpTotalValue.click();
			Thread.sleep(1000);
			inpTotalValue.sendKeys(Keys.TAB);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verfiyNewCommodityDeclVal() {
		try {
			//commoditySecondRow.click();
			//clickElementUsingJavaScript(commoditySecondRow);
			waitTillElementVisible(eleCommNewDecl);
			Double totalVal = Double.parseDouble(inpTotalValue.getAttribute("value"));
			Double declVal = Double.parseDouble(commodityDeclValue.getText().replace(",", ""));
			String NewCommVal = eleCommNewDecl.getText();

			Double expectedNewComm = (Double) (Math.round((totalVal - declVal) * 100.00) / 100.00);
			String expectedNewComm1 = (String.valueOf(expectedNewComm));
			String expectedNewComm2 = expectedNewComm1.substring((expectedNewComm1.length()) - 2);
			if (expectedNewComm2.equals(".0") | expectedNewComm2.equals(".1") | expectedNewComm2.equals(".2")
					| expectedNewComm2.equals(".3") | expectedNewComm2.equals(".4") | expectedNewComm2.equals(".5")
					| expectedNewComm2.equals(".6") | expectedNewComm2.equals(".7") | expectedNewComm2.equals(".8")
					| expectedNewComm2.equals(".9")) {
				expectedNewComm1 = expectedNewComm1.toString() + "0";
			}
			Assert.assertEquals(expectedNewComm1, NewCommVal, "New Commodity Decl Val is not " + expectedNewComm1);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void CIFEditable() {
		waitTillElementVisible(inpCommCIF);
		Assert.assertFalse(inpCommCIF.isEnabled(), "Commodity CIF is enabled");

	}

	public void verfiyNewCommodityCIF() {
		try {
			waitTillElementVisible(eleNewCommCIF);
			Double totalCIF = Double.parseDouble(inpCIF.getAttribute("value"));
			Double declCIF = Double.parseDouble(eleCommCIF.getText().replace(",", ""));
			String NewCommCIF = eleNewCommCIF.getText();
			Double expectedNewComm = (Double) (Math.round((totalCIF - declCIF) * 100.00) / 100.00);
			String expectedNewComm1 = (String.valueOf(expectedNewComm));
			String expectedNewComm2 = expectedNewComm1.substring((expectedNewComm1.length()) - 2);
			if (expectedNewComm2.equals(".0") | expectedNewComm2.equals(".1") | expectedNewComm2.equals(".2")
					| expectedNewComm2.equals(".3") | expectedNewComm2.equals(".4") | expectedNewComm2.equals(".5")
					| expectedNewComm2.equals(".6") | expectedNewComm2.equals(".7") | expectedNewComm2.equals(".8")
					| expectedNewComm2.equals(".9")) {
				expectedNewComm1 = expectedNewComm1.toString() + "0";
			}
			Assert.assertEquals(expectedNewComm1, NewCommCIF, "New Commodity CIF is not " + expectedNewComm1);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void verfiyNewCommodityGST(String strVal) {

		try {
			waitTillElementVisible(inpCommCIF);
			Double CommCIF = Double.parseDouble(inpCommCIF.getAttribute("value"));
			Double result = CommCIF * (Double.parseDouble(strVal));
			Double actGST = (double) Math.round(result * 100.00) / 100.00;
			String expectedNewComm1 = (String.valueOf(actGST));
			String expectedNewComm2 = expectedNewComm1.substring((expectedNewComm1.length()) - 2);
			if (expectedNewComm2.equals(".0") | expectedNewComm2.equals(".1") | expectedNewComm2.equals(".2")
					| expectedNewComm2.equals(".3") | expectedNewComm2.equals(".4") | expectedNewComm2.equals(".5")
					| expectedNewComm2.equals(".6") | expectedNewComm2.equals(".7") | expectedNewComm2.equals(".8")
					| expectedNewComm2.equals(".9")) {
				expectedNewComm1 = expectedNewComm1.toString() + "0";
			}
			Assert.assertEquals(expectedNewComm1, inpCommGST.getAttribute("value"),
					"New Commodity CIF is not " + expectedNewComm1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String selSelectedValue(WebElement selectElement) {

		try {
			Select eleSelect = new Select(selectElement);
			return eleSelect.getFirstSelectedOption().getText();
		}

		catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	public void verfiyNewCommodityCountry() {
		try {
			waitTillElementVisible(selCommCountry);
			String currentCountry = selSelectedValue(selCommCountry);
			Assert.assertFalse(currentCountry.equals("Select") | currentCountry.equals(""),
					"Commodity country is not selected by default");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verfiyNewCommodityDesc() {
		try {
			waitTillElementVisible(txtCommDesc);
			Assert.assertFalse(txtCommDesc.getAttribute("value").isEmpty(), "Commodity description is not populated");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void verfiyNewCommodityBranded(String val) {
		try {
			waitTillElementVisible(inpCommBranded);
			Assert.assertTrue(inpCommBranded.getAttribute("value").equals(val),
					"Commodity Branded field is not populated as " + val);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verfiyNewCommodityProduct(String val) {
		try {
			waitTillElementVisible(inpCommBranded);
			String currentCountry = selSelectedValue(selCommProduct);
			Assert.assertTrue(currentCountry.trim().equals(val), "Commodity Product field is populated");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyShipmentFields() {
		try {
			waitTillElementVisible(inpCIF);
			Thread.sleep(1000);
			Assert.assertFalse(inpCIF.getAttribute("value").isEmpty(), "Shipment CIF field is not populated");
			Assert.assertFalse(inpGST.getAttribute("value").isEmpty(), "Shipment GST field is not populated");
			Assert.assertFalse(inpXrate.getAttribute("value").isEmpty(),
					"Shipment Exchange rate field is not populated");
			Assert.assertFalse(inpFrate.getAttribute("value").isEmpty(), "Shipment F-rate field is not populated");
			Assert.assertFalse(inpInsurance.getAttribute("value").isEmpty(),
					"Shipment Insurance field is not populated");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterClearanceScheme(String val) {

		try {
			waitTillElementVisible(selClrScheme);
			selectUsingVisibleText(selClrScheme, val);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterCurrency(String val) {
		try {
			waitTillElementVisible(selCurrency);
			selectUsingVisibleText(selCurrency, val);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterGrossWeight(String val) {
		try {
			waitTillElementVisible(inpGrossWeight);
			inpGrossWeight.sendKeys(Keys.CONTROL, "a");
			inpGrossWeight.sendKeys(Keys.DELETE);
			inpGrossWeight.sendKeys(val);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enterIncoterm(String val) {
		try {
			waitTillElementVisible(selIncoTerm);
			selectUsingVisibleText(selIncoTerm, val);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void enterShipmentDescription(String val) {
		try {
			waitTillElementVisible(inpShipmentDesc);
			inpShipmentDesc.sendKeys(Keys.CONTROL, "a");
			inpShipmentDesc.sendKeys(Keys.DELETE);
			inpShipmentDesc.sendKeys(val);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void HSCode_noMatch_Red() {
		String strHSCodeValue = txtHSCodeClicked.getAttribute("class");
		Assert.assertTrue(strHSCodeValue.contains("hasNoValue"), "HS Code is not blank");
		Assert.assertTrue(lnkRedIcon.isDisplayed(), "Orange Harmonized Code Match Icon is not present");

	}

	public void clickNewCommodity() throws InterruptedException {
		Thread.sleep(2000);
		//clickElementUsingJavaScript(eleNewCommodityRow);
		clickElementUsingJavaScript(Second_CommDecl);
		Thread.sleep(1000);
		clickElementUsingJavaScript(delete_commodity);
		
		
	}

	public void create_and_modify_new_Commodity_details() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			String rowClassAttributeValue = commodityFirstRow.getAttribute("class");
			System.out.println(rowClassAttributeValue);
			if (!rowClassAttributeValue.equals("ng-star-inserted selectedTableRow")) {
				commodityRow.click();
			}
			String commodityDeclVal = commodityDeclValue.getText();
			System.out.println("commodityDeclVal : " + commodityDeclVal);
			Float floatVal = Float.parseFloat(commodityDeclVal) - 1;
			System.out.println("floatVal : " + floatVal);
			commodityDec.clear();
			commodityDec.sendKeys(Float.toString(floatVal));
			Thread.sleep(1000);
			commodityQuantity.click();
			commoditySecondRow.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateCOMalerts() throws InterruptedException {
		Thread.sleep(3000);
		Boolean comInvalidAlert = true;
		Boolean comRequiredAlert = true;
		try {
			comInvalidAlert = comInvalid.isDisplayed();
			comRequiredAlert = comRequired.isDisplayed();
			System.out.println("comInvalidAlert : " + comInvalidAlert);
			System.out.println("comRequiredAlert : " + comRequiredAlert);
			if ((comInvalidAlert == true) && (comRequiredAlert == true)) {
				System.out.println("COM Alerts are present");
				Assert.fail();
			} else {
				System.out.println("COM Alerts are not present");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ACCSShipments_InEntryBuildTeamLeaderList() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(entryBuild_ACCSShipmentTeam);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", entryBuild_ACCSShipmentTeam);
			Thread.sleep(4000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void assignShipmentFromEntryBuildTeamLeaderList() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		scrollIntoViewUsingJavaScript(memberTextBox);
		String userName = resourceBundle.getString("username");
		System.out.println("userName  :  " + userName);
		memberTextBox.sendKeys(userName);
		WebElement selectMember = driver.findElement(By.xpath("//div[contains(text(),'" + userName + "')]"));
		scrollIntoViewUsingJavaScript(selectMember);
		js.executeScript("arguments[0].click();", selectMember);
		scrollIntoViewUsingJavaScript(btnSave);
		js.executeScript("arguments[0].click();", btnSave);
	}

	public void clickUploadButton() {
		try {
			Thread.sleep(3000);
			btn_Upload.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectLocation(String location) throws InterruptedException, AWTException {
		try {
			zoomOutUsingRobotClass();
			waitTillElementVisible(dpdn_Location, 10);
			selectUsingVisibleText(dpdn_Location, location);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickDownloadButton() {
		try {
			Thread.sleep(3000);
			btn_Download.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// HSCode for multiple match - Orange color
	@FindBy(xpath = "//a[@class='fx-gn-img-multipleMatch']")
	public WebElement cmdMultiMatchEdit;

	// HSCode for Matched - green color
	@FindBy(xpath = "//a[@class='fx-gn-img-matched']")
	public WebElement cmdMatchedEdit;

	// HSCode for NoMatch - Red color
	@FindBy(xpath = "//a[@class='fx-gn-img-noMatch']")
	public WebElement cmdNoMatchEdit;

	@FindBy(xpath = "(//datatable-row-wrapper[@class='datatable-row-wrapper ng-star-inserted'])[1]")
	public WebElement hsCodeRow;

	@FindBy(id = "fx-gn-commodity-select")
	public WebElement cmdSelect;

	@FindBy(id = "fx-gn-commodity-cancel-icon-enabled")
	public WebElement cmdCancel;

	@FindBy(xpath = "//button[@id='btnSubmit']")
	public WebElement btnSubmit;

	@FindBy(xpath = "//input[@id='fx-gn-commodity-hs-code-0']")
	public WebElement hscodeEdit;

	@FindBy(xpath = "//*[@id='shipment-commodity-deatils_panel']/div[2]/table/tbody/tr[1]/td[2]")
	public WebElement hsCodeInCmdTbl;

	@FindBy(xpath = "//*[@id='commodity_desc_td']")
	public WebElement tdCmdDetails;

	@FindBy(xpath = "//*[@id=\"geniusDataGridTable\"]/div/datatable-header")
	public WebElement hdcodePredictTbl;

	@FindBy(xpath = "//input[@id='fx-gn-user-team-toggle-2']")
	public WebElement accsShipmentToggle;

	@FindBy(xpath = "//a[@id='filter-icon-0']")
	public WebElement awbUserlistSearchFilter;

	@FindBy(xpath = "//span[@id='AWB-Number-0']")
	public WebElement awbNumTeamlist;

	@FindBy(xpath = "//*[@id='AWB-Number-0']")
	public WebElement awbNumUserlist;

	@FindBy(xpath = "//input[@id='fx-gn-commodity-hs-code-0']")
	public WebElement hSCodeCmdDetails;

	// Prediction table cancel button
	@FindBy(xpath = "//button[@id='fx-gn-commodity-cancel-icon-enabled']")
	public WebElement btnPredicationTblCancel;

	// Recurring Rule Maintenance icon
	@FindBy(xpath = "//*[@id='tools']")
	public WebElement iconRecurringRule;

	// Recurring Rule Maintenance Option in the dropdown options list

	@FindBy(xpath = "//*[@id=\"SORTCODE_RULE_MAINTENANCE\"]/span[1]")
	public WebElement optionRecurringRuleMaintain;

	// REcurring Rule Maintenance page title
	@FindBy(xpath = "//*[@id='selected-competencies-header']")
	public WebElement ruleMaintTitle;

	// Create Rule icon
	@FindBy(xpath = "//*[@id='create_rule']")
	public WebElement iconCreateRule;

	// Create Rule text in the popup
	@FindBy(xpath = "//*[@id=\"fx-gn-create-team-rule-form\"]/div/div[1]/div/div/h3")
	public WebElement txtCreateRule;

	@FindBy(xpath = "//*[@id='cancel']")
	public WebElement btnCancelCreateRule;

	@FindBy(xpath = "//select[@id='fx-gn-sanity-rule-create-ruleName']")
	public WebElement ddSortCodeList;

	@FindBy(xpath = "//button[@id='fx-gn-img-hs-code-icon']")
	public WebElement btnHSCodeSearch;

	@FindBy(xpath = "//input[@id='fx-gn-commodity-hs-code-0']")
	public WebElement inputHSCode;

	@FindBy(xpath = "//*[@id='commodityDetailsGrid']")
	public WebElement HSTblGrid;

	/*----------------------------------------------------------------------------------------------------------------------------------------*/
	/*-----------------------------------------------Srikanth's code---------------------------------------------*/
	/*----------------------------------------------------------------------------------------------------------------------------------------*/

	// Commodity details - HSCode multiple match

	public void click_commodity_MultiMatch_Edit() {
		try {

			waitTillElementVisible(cmdMultiMatchEdit);
			scrollDownUsingJavaScript();
			log.info("Click on Orange icon " + cmdMultiMatchEdit);
			blnHsCode = verifyHScodeinCmdDetail();

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cmdMultiMatchEdit);

			((JavascriptExecutor) driver).executeScript("arguments[0].click()", cmdMultiMatchEdit);
			log.info("HSCode multi match, Orange color icon, displayed");
			Thread.sleep(3000);

			// hsCodeRow.click();
			clickElementUsingJavaScript(hsCodeRow);

			if (hsCodeRow.isEnabled()) {
				log.info(hsCodeRow.getAttribute("id") + " " + "row is selected");
			} else {
				log.info(hsCodeRow.getAttribute("id") + " " + "row is not selected");
			}
			Thread.sleep(500);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("HSCode multi match, Orange color icon is not displayed", e);
		}
	}

	// ================================================================================================
	public void verify_scrollupdown() throws InterruptedException {
		try {
			clickElementUsingJavaScript(HSCodeDescription);
			Thread.sleep(1000);
			Actions actions = new Actions(driver);
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
			Thread.sleep(2000);
			actions.keyDown(Keys.CONTROL).sendKeys(Keys.HOME).perform();
			// clickElementUsingJavaScript(regionalscrolldown);
			Thread.sleep(2000);
			// clickElementUsingJavaScript(regionalscrollup);
		} catch (Exception e) {
			log.error("Filters are not working inside prediction table", e);
		}
	}

	// ================================================================================================
	public void enter_ValidHSCode() throws InterruptedException {
		try {
			txtHSCode.clear();
			Thread.sleep(1000);
			txtHSCode.sendKeys("90261090");
			HSCodeSearchbox.click();
			Thread.sleep(1000);
			String commoditydesc = commodityDescriptionTextArea.getAttribute("value");
			log.info(commoditydesc);
			log.info("Commodity details are updated");
		} catch (Exception e) {
			log.error("Valid HS code is not entered", e);
		}
	}

	// =============================================================================================================================
	// Click on icon with exact match icon - green color
	public void click_commodity_Matched_Edit() {
		try {

			waitTillElementVisible(cmdMatchedEdit);
			scrollDownUsingJavaScript();
			log.info("Click on Green icon " + cmdMatchedEdit);
			blnHsCode = verifyHScodeinCmdDetail();

			if (checkElementIsVisible(cmdMatchedEdit)) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cmdMatchedEdit);
				log.info("HSCode Exact match, Green color icon, displayed");
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", cmdMatchedEdit);
			} else {
				log.info("HSCode Exact match, Green color icon, not displayed");
			}
		} catch (Exception e) {
			log.error("HSCode multi match, Green color icon is not displayed", e);
		}
	}

	// =============================================================================================================================
	// Click on icon with no match icon - Red color
	public void click_commodity_NoMatch_Edit() {
		try {

			waitTillElementVisible(cmdNoMatchEdit);
			scrollDownUsingJavaScript();
			log.info("Click on Red icon " + cmdNoMatchEdit);

			if (checkElementIsVisible(cmdNoMatchEdit)) {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cmdNoMatchEdit);
				log.info("HSCode No match, Red color icon, displayed");
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", cmdNoMatchEdit);
			} else {
				log.info("HSCode No match, Red color icon, not displayed");
			}

		} catch (Exception e) {
			log.error("HSCode multi match, Red color icon is not displayed", e);

		}
	}

	public void click_cmdSelect() {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cmdSelect);
			cmdSelect.click();
			Thread.sleep(1000);
			log.info("commodity is selected");
		} catch (InterruptedException e) {
			log.error("commodity not selected", e);
		}
	}

	public void click_btnSubmit() {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnSubmit);
			btnSubmit.click();
			Thread.sleep(1000);
			log.info("Button clicked");
		} catch (InterruptedException e) {
			log.error("Button is not clicked", e);
		}
	}

	public void click_btnCancel() {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", cmdCancel);
			cmdCancel.click();
			Thread.sleep(1000);
			log.info("Cancel button clicked");
		} catch (InterruptedException e) {
			log.error("Cancel Button is not clicked", e);
		}
	}

	// Cancel the HSCode assignment in Commodity details
	public void click_btnCancelAssign() {
		try {
			Thread.sleep(3000);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnCancelAssign);
			waitTillElementVisible(btnCancelAssign);
			btnCancelAssign.click();
			Thread.sleep(3000);
			log.info("Assigned HS Code is canceled");
		} catch (InterruptedException e) {
			log.info("Cancelation of HS Code is not done", e);
		}
	}

	// Verify HScode in commodity table
	public String verifyHScodeinCmdTbl(String value) throws InterruptedException {
		try {
			hsCodeRow.click();
			HSCodeCmbTbl = hsCodeInCmdTbl.getText();
			System.out.println(HSCodeCmbTbl);

			hsCodeRow.click();
			Thread.sleep(500);

			if (HSCodeCmbTbl.contains(value)) {
				log.info("" + value + " is displayed");
			} else {
				log.info("" + value + " is not displayed");
			}
			return HSCodeCmbTbl;
		} catch (Exception e) {
			log.error("" + value + " is not displayed", e);
		}
		return value;
	}

	// Verify text in HScode editbox
	public String verifyHScodeText(String value) throws InterruptedException {
		try {
			hscodeEdit.click();
			HSCodeText = hscodeEdit.getText();
			System.out.println(HSCodeText);

			Thread.sleep(500);
			hsCodeRow.click();
			Thread.sleep(500);
			if (HSCodeText.contains(value)) {
				log.info("" + value + " is displayed");
			} else {
				log.info("" + value + " is not displayed");
			}

		} catch (Exception e) {
			log.error("" + value + " is not displayed", e);
		}
		return value;
	}

	// Verify, Under Commodity Details, HScode editbox has value or null
	public Boolean verifyHScodeinCmdDetail() throws InterruptedException {
		boolean booleannHsCode = false;
		try {

			hscodeEdit.click();
			HSCodeText = hscodeEdit.getText();
			log.info("HSCode is " + HSCodeText);

			Thread.sleep(500);

			if (HSCodeText.isEmpty()) {
				log.info("HSCode is empty");
				booleannHsCode = true;
			} else {
				booleannHsCode = false;
				log.info("HSCode is not empty");
			}

		} catch (Exception e) {
			log.error("HSCode is not empty", e);
		}
		return booleannHsCode;
	}

	public void click_commodityDetails() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(hsCodeInCmdTbl);
			hsCodeInCmdTbl.click();
			Thread.sleep(1000);
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			log.info("Commodity details displayed");
		} catch (Exception e) {
			log.error("Commodity details not displayed", e);
		}
	}

	public void click_commodityDetailsMultiMatch() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(tdCmdDetails);
			((JavascriptExecutor) driver).executeScript("arguments[0].click()", tdCmdDetails);
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			waitTillElementVisible(cmdMultiMatchEdit);
			log.info("Multimatch icon is displayed");
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.error("Multimatch icon is not displayed", e);
		}
	}

	public void click_commodityDetailsNoMatch() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(tdCmdDetails);
			((JavascriptExecutor) driver).executeScript("arguments[0].click()", tdCmdDetails);
			Thread.sleep(1000);
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			waitTillElementVisible(cmdNoMatchEdit);
			log.info("Nomatch icon is displayed");
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.error("Nomatch icon is not displayed", e);
		}
	}

	public Boolean verifyHdCodeTblExists() throws InterruptedException {
		try {

			hsCodeTblDisplayed = hdcodePredictTbl.isDisplayed();
			Thread.sleep(3000);
			if (hsCodeTblDisplayed = true) {
				log.info("HS Code table is displayed");
				// cancel_PrdictionTbl();
			} else {
				log.info("HS Code table is not displayed");
				hsCodeTblDisplayed = false;
			}
			Thread.sleep(1000);
		} catch (Exception e) {
			log.error("HS Code table is not displayed", e);
			hsCodeTblDisplayed = false;
		}
		return hsCodeTblDisplayed;
	}

	// Verify for HSCode Predictable table is displayed
	public Boolean verifyHdCodeTblforConfidenceColumn() throws InterruptedException {
		try {

			hsCodeTblDisplayed = hdcodePredictTbl.isDisplayed();
			Thread.sleep(3000);
			if (hsCodeTblDisplayed = true) {
				log.info("HS Code table is displayed");
			} else {
				log.info("HS Code table is not displayed");
				hsCodeTblDisplayed = false;
			}
			Thread.sleep(1000);
		} catch (Exception e) {
			log.error("HS Code table is not displayed", e);
			hsCodeTblDisplayed = false;
		}
		return hsCodeTblDisplayed;
	}

	// Verify for Confidence column in HSCode Predictable table
	public void ConfidenceColExists() throws InterruptedException {
		List<WebElement> colHead = driver
				.findElements(By.xpath("//th//span[@class='datatable-header-cell-label draggable']"));

		int Head_Count = colHead.size();
		for (int column = 0; column < Head_Count; column++) {
			String strColHead = colHead.get(column).getText();

			if (strColHead.contains("Confidence")) {
				log.info("Confidence Column is not removed");
				break;
			}
			log.info("Column is " + strColHead + " exists");
		}

		log.info("Confidence Column is removed");
		cancel_PrdictionTbl();
	}

	// predictPopupColumnsExists()
	public void predictPopupColumnsExists() throws InterruptedException {

		List<WebElement> colHead = driver
				.findElements(By.xpath("//th//span[@class='datatable-header-cell-label draggable']"));

		List<String> strings = new ArrayList<String>();
		for (WebElement e : colHead) {
			strings.add(e.getText());
		}

		if (strings.contains("spanWCOTariff") && strings.contains("spanUOM") && strings.contains("spanDescription")
				&& strings.contains("spanSource")) {
			log.info("Columns Exists");
			System.out.print("Columns Exists");

		} else {
			log.info("Columns doesn't Exist");
			System.out.print("Columns doesn't Exists");

		}

		cancel_PrdictionTbl();
	}

	public void click_filterAWBUserlist() throws InterruptedException {
		try {
			awbUserlistSearchFilter.click();
		} catch (Exception e) {
			log.error("search filter not displayed", e);
		}
	}

	public void click_teamListTable() {
		try {
			Thread.sleep(1000);
			checkElementIsVisible(awbNumTeamlist);
			awbNumTeamlist.click();
		} catch (Exception e) {
			log.error("Unableto click on Teamlist", e);
		}
	}

	public void doubleClick_userlistShipment() throws InterruptedException {
		try {

			waitTillElementVisible(awbNumUserlist);

			awbNumUserlist.click();
			UserlistVisible = awbNumUserlist.isDisplayed();

			if (UserlistVisible = true) {
				WebElement element = driver.findElement(By.xpath("awbNumUserlist"));
				Actions act = new Actions(driver);
				act.doubleClick(element).perform();
				log.info("AWBNumber element is displayed" + awbNumUserlist);
			}
		} catch (Exception e) {
			log.info("AWBNumber element is no displayed", e);
		}
	}

	public void verify_hscode() throws InterruptedException {
		try {
			Actions act = new Actions(driver);
			checkElementIsVisible(awbNumUserlist);
			WebElement element = driver.findElement(By.id("awbNumUserlist"));
			act.doubleClick(element).perform();
			log.info("Double clicked on userlist");
		} catch (Exception e) {
			log.error("Cannot double clicked on userlist", e);
		}
	}

	// Click "Cancel" button in the HSCode Prediction table
	public void cancel_PrdictionTbl() throws InterruptedException {
		try {
			Thread.sleep(3000);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnPredicationTblCancel);
			scrollDownUsingJavaScript();
			predTblVisible = btnPredicationTblCancel.isDisplayed();
			if (predTblVisible = true) {
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnPredicationTblCancel);
				log.info("Closing of Prediction table");

			} else {
				log.info("Prediction table could not be closed");
			}

		} catch (Exception e) {
			log.error("Prediction table could not be closed", e);
		}
	}

	// Navigating to Recurring Rule Maintenance by clicking on the icon
	public void recurring_RuleMaintenance_Navigate() throws InterruptedException {
		try {

			waitTillElementVisible(iconRecurringRule);
			blnRecurringRuleicon = iconRecurringRule.isDisplayed();

			if (blnRecurringRuleicon = true) {

				log.info("Recurring Rule Maintenance icon is visible");
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", iconRecurringRule);

				waitTillElementVisible(optionRecurringRuleMaintain);
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", optionRecurringRuleMaintain);

				waitTillElementVisible(ruleMaintTitle);
				String ruleMaintTitlevalue = ruleMaintTitle.getText();
				if (ruleMaintTitlevalue.contains("Recurring Rules Maintenance")) {
					log.info("Recurring Rules Maintenance page is displayed");
				} else {
					log.info("Recurring Rules Maintenance page is not displayed");
				}
			} else {
				log.info("Prediction table not closed");
			}

		} catch (Exception e) {
			log.error("Prediction table not closed", e);
		}
	}

	// Navigating to "Create Rule" popup by clicking on the "Create" icon
	public void navigateToCreateRulePopup() throws InterruptedException {
		try {

			waitTillElementVisible(iconCreateRule);
			blnCreteRuleicon = iconCreateRule.isDisplayed();

			if (blnCreteRuleicon = true) {

				log.info("Create Rule icon is visible");
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", iconCreateRule);

				waitTillElementVisible(txtCreateRule);
				String ruleMaintTitlevalue = txtCreateRule.getText();

				if (ruleMaintTitlevalue.contains("Create Rule")) {
					log.info("Create Rule page is displayed");
				} else {
					log.info("Create Rule page is not displayed");
				}
			} else {
				log.info("Create Rule icon is not visible");
			}

		} catch (Exception e) {
			log.error("Create Rule icon is not visible", e);
		}
	}

	// Verify "UGN" option is available in Sort Codes list
	public void verifyListforsortCode() throws InterruptedException {

		Select listBox = new Select(ddSortCodeList);

		List<WebElement> dd = listBox.getOptions();

		int listsize = dd.size();

		System.out.println("Size is " + listsize);

		boolean status = true;

		for (int i = 0; i < listsize; i++) {
			if (dd.get(i).getText().equals("URG")) {

				status = true;
				log.info("sort code URG is found");
				break;
			} else {
				status = false;
			}
		}

		if (status == false) {
			log.info("sort code URG is not found");
		}

	}

	public String fetchAWB() throws InterruptedException {
		String data = "";
		try {
			waitTillElementVisible(gridTable);
			List<WebElement> ele = driver.findElements(By.xpath("(//table)/tr/th"));
			for (int i = 1; i < ele.size();) {
				if ((driver.findElement(By.xpath("((//table)/tr/th)[" + i + "]/span")).getText().trim())
						.equalsIgnoreCase("AWB Number")) {
					data = driver.findElement(By.xpath("(((//datatable-row-wrapper)[" + i
							+ "]/datatable-body-row/div)[2]/datatable-body-cell/div/span)[2]")).getText();
					break;
				} else
					i = i + 3;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}

	// Close the Create Rule popup
	public void cancel_CreateRulePopup() throws InterruptedException {
		try {

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnCancelCreateRule);
			scrollDownUsingJavaScript();

			blncreateRuleCancleVisible = btnCancelCreateRule.isDisplayed();

			if (blncreateRuleCancleVisible = true) {
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnCancelCreateRule);
				log.info("Closing of Create Rule popup");

			} else {
				log.info("Create Rule popup Cancel button not found");
			}

		} catch (Exception e) {
			log.error("Create Rule popup Cancel button not found", e);
		}
	}

	// =============================================================================================================================
	public void searchHScode() throws InterruptedException {
		try {
			Thread.sleep(2000);

			txtHSCode.sendKeys("euiwt02");
			String text = txtHSCode.getAttribute("value");
			log.info(text);
			int isNumeric = Integer.parseInt(text);
			log.info(isNumeric);
			@SuppressWarnings("unused")
			boolean value = Character.isDigit(isNumeric);
			if (value = true) {
				log.info("Accepting only numbers");
			} else {
				log.error("Accepting all the characters");
			}
			HSCodeSearchbox.click();
			Thread.sleep(3000);
			HSCodeDescription.click();
			;
			String Actdescription = HSCodeDescription.getText();
			String ActWCOTariff = HSCodeInputWCOTariff.getText();
			String ActRegional = HSCodeRegional.getText();
			String ActHSCode = ActWCOTariff + ActRegional;
			log.info(ActHSCode);
			log.info(Actdescription);
			zoomOutUsingRobotClass();
			SubmitHSCode.click();
			Thread.sleep(3000);
			String Expdescription = commodityDescriptionTextArea.getAttribute("value");
			log.info(Expdescription);
			Thread.sleep(1000);
			Assert.assertEquals(Actdescription, Expdescription, "Commodity descriptions are not matched");
			String ExpHSCode = txtHSCode.getAttribute("value");
			log.info(ExpHSCode);
			Thread.sleep(1000);
			Assert.assertEquals(ActHSCode, ExpHSCode, "Selected HS codes are not matched");

		} catch (Exception e) {
			log.error("Could not search HS code", e);
		}
	}

	// ================================================================================================
	public void verify_filters() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			txtHSCode.clear();
			Thread.sleep(1000);
			txtHSCode.sendKeys("02");
			HSCodeSearchbox.click();
			Thread.sleep(1000);
			/*
			 * clickElementUsingJavaScript(WCOTariff); Thread.sleep(1000);
			 * clickElementUsingJavaScript(filterWCOTariff); Thread.sleep(1000);
			 * valuefilterTxtBox.sendKeys("020"); valuefilterTxtBox.clear();
			 * Thread.sleep(1000); clickElementUsingJavaScript(closefilter);
			 * filterRegional.click(); valuefilterTxtBox.sendKeys("00");
			 * valuefilterTxtBox.clear(); Thread.sleep(1000); closefilter.click();
			 * filterUOM.click(); valuefilterTxtBox.sendKeys("TN");
			 * valuefilterTxtBox.clear(); Thread.sleep(1000); closefilter.click();
			 * filterDescription.click(); valuefilterTxtBox.sendKeys("CONTROL");
			 * valuefilterTxtBox.clear(); Thread.sleep(1000); closefilter.click();
			 */
			clickElementUsingJavaScript(WCOTariff);
			clickElementUsingJavaScript(Regional);
			clickElementUsingJavaScript(UOM);
			clickElementUsingJavaScript(DescriptionHSCode);

		} catch (Exception e) {
			log.error("Filters are not working inside prediction table", e);
		}
	}

	// hSCodeCmdDetails
	public void typeHSCode() throws InterruptedException {
		try {
			if (hSCodeCmdDetails.isDisplayed()) {
				hSCodeCmdDetails.sendKeys("10011");
			} else {
				log.info("HsCode could not be typed");
			}
		} catch (Exception e) {
			log.error("HsCode could not be typed", e);
		}
	}

	// btnHSCodeSearch
	public void clickHSCodeSearch() throws InterruptedException {
		try {

			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnHSCodeSearch);
			scrollDownUsingJavaScript();

			if (btnHSCodeSearch.isDisplayed()) {
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", btnHSCodeSearch);
				log.info("HSCode grid popup should be displayed");

			} else {
				log.info("HSCode grid popup should be displayed");
			}

		} catch (Exception e) {
			log.error("HSCode grid popup should be displayed", e);
		}
	}

	// In HSCodePredication table, scroll horizontally to the column "Levy Code" and
	// then to "WCO Tariff"
	@SuppressWarnings("unused")
	public void scrollHsCodeTable() throws InterruptedException {

		List<WebElement> colHead = driver
				.findElements(By.xpath("//th//span[@class='datatable-header-cell-label draggable']"));

		int Head_Count = colHead.size();

		for (int column = 0; column < Head_Count; column++) {
			String strColHead = colHead.get(column).getText();

			switch (strColHead) {
			case "WCO Tariff":
				log.info("scrolled to WCO Tariff");
			case "Regional":
				log.info("scrolled to Regional");
			case "Nat 1":
				log.info("scrolled to Nat 1");
			case "Nat 2":
				log.info("scrolled to Nat 2");
			case "UOM":
				log.info("scrolled to UOM");
			case "Description":
				log.info("scrolled to Description");
			case "Source":
				log.info("scrolled to Source");
			case "AddIn UOM":
				log.info("scrolled to AddIn UOM");
			case "Levy Code":
				log.info("scrolled to Levy Code");
			}
			break;
		}
		hSCodeCmdDetails.clear();
		Thread.sleep(500);
		cancel_PrdictionTbl();

	}

	// Gomathi
	/* Click the Route Refresh Information Button */
	public void clickRouteRefreshInformationButton() {
		try {
			// Thread.sleep(3000);
			waitTillElementVisible(routeRefreshInformation);
			routeRefreshInformation.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String SelectAnyUserforAssignment() throws InterruptedException {
		waitTillElementVisible(selectUser);
		scrollIntoViewUsingJavaScript(selectUser);
		Thread.sleep(1000);
		selectUser.click();
		memberIdtoAssign = userIdToAssign.getText();
		waitTillElementVisible(btnSave);
		clickElementUsingJavaScript(btnSave);
		return memberIdtoAssign;
	}

	public void set_Search_Value(String value) throws InterruptedException {
		try {
			// scrollDownUsingJavaScript();
			// Thread.sleep(1000);
			txtReassignSearch.clear();
			Thread.sleep(2000);
			scrollIntoViewUsingJavaScript(txtReassignSearch);
			clickElementUsingJavaScript(txtReassignSearch);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("document.getElementById('fx-gn-user-role-search-memberName').value='" + value + "';");
			txtReassignSearch.sendKeys(Keys.ENTER);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String SelectAnyNoUserforAssignment(int n) throws InterruptedException {
		waitTillElementVisible(selectUser);
		String memberIdtoAssign = "";
		for (int i = 0; i < n - 1; i++) {
			scrollIntoViewUsingJavaScript(selectUsers.get(i));
			clickElementUsingJavaScript(selectUsers.get(i));
			memberIdtoAssign = memberIdtoAssign + selectUsers.get(i).getText() + ",";
		}

		scrollIntoViewUsingJavaScript(memberId);
		Thread.sleep(3000);
		memberId.click();
		String[] splitName = userName.getText().split(" ");
		memberId.sendKeys(splitName[0].trim());
		memberId.clear();
		memberId.sendKeys(splitName[0].trim());
		// SelectAnyUserforAssignment();
		selectUser.click();
		String currentUser = selectUser.getText();
		ScenarioContext.setContext(Context.CURRENTUSER, currentUser);
		memberIdtoAssign = memberIdtoAssign + currentUser;
		elementToBeClickable(btnSave);
		clickElementUsingJavaScript(btnSave);
		return memberIdtoAssign;
	}

	public void text_verifyEntryBuild() throws InterruptedException {
		try {
			String txtEntryBuildAct = txtCompEntryBuild.getText().trim();
			String txtEntryBuildExp = "Entry Build";
			Assert.assertEquals(txtEntryBuildAct, txtEntryBuildExp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
