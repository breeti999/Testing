package com.FedEx.GeminiAutomationSG.PageObjects;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.IOException;
import java.io.FileReader;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class RestAssuredPage {

	private static final String accessUri = "https://purpleid-stage.oktapreview.com/oauth2/default/v1/token";
	private static final String clientId = "0oarrgqc2qXAymwpi0h7";
	private static final String clientSecret = "AbPIjtzFzAq20I3lWpHIY3ZOIv06v23tN9tRaaQ1";
	private static final String clientGrantType = "client_credentials";
	private static final String clientScope = "Custom_Scope";

	public String generateOktaToken() throws InterruptedException {
		String oktaNew = "";
		RequestSpecification httpRequest = null;
		httpRequest = RestAssured.given().auth().preemptive().basic(clientId, clientSecret).baseUri(accessUri)
				// .proxy(proxyHost, proxyPort)
				// .proxy(httpsproxyHost, httpsproxyPort)
				.header("accept", "application/json").header("cache-control", "no-cache")
				.header("content-type", "application/x-www-form-urlencoded").formParam("grant_type", clientGrantType)
				.formParam("scope", clientScope);
		System.out.println(httpRequest.toString());
		Thread.sleep(10000);
		Response response = httpRequest.post();
		Thread.sleep(10000);
		System.out.println("Response received : " + response.asString());
		JsonPath jsonPathEvaluator = response.jsonPath();
		oktaNew = jsonPathEvaluator != null
				? (jsonPathEvaluator.getString("token_type") + " " + jsonPathEvaluator.getString("access_token"))
				: "";
		System.out.println("OKTA TOKEN RECEIVED : " + oktaNew);
		return oktaNew;
	}
	
	public void verify_SanityRule_API() throws InterruptedException {

		RestAssured.baseURI = "https://gemini-spring-cloud-gateway-service-release.app.singdev1.paas.fedex.com";

		String countryCode = "SG";
		String carrier = "FEDEX";
		String clearanceProcedure = "IMPORTS";
		List<String> clearanceLocation = new ArrayList<>();
		clearanceLocation.add("SIN");
		
		String bearerToken = generateOktaToken();
		
		Response response =

				given().queryParam("countryCode", countryCode).queryParam("carrier", carrier)
				.queryParam("clearanceProcedure", clearanceProcedure)
				.queryParam("clearanceLocations", clearanceLocation).header("Content-Type", "application/json")
				.header("Userid", "5430949")
				.header("Xuserrole", "gemini_broker-lead-dev_sg_sin_app83").header("Carrier", "FEDEX")
				.header("Clearanceprocedure", "IMPORTS").header("Competencyid", "9")
				.header("Authorization", bearerToken).

						when().get("/gemini/all-maintenance-service/sanityRulesFetch").

						then().assertThat().statusCode(200).extract().response();

		System.out.println("Status Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.asString());
//		String response_Description = getValueByJSONPath(response, "data.responseDescription");
//		System.out.println("Response Description: " + response_Description);
	}

	public void verify_TeamRule_API() throws InterruptedException {

		RestAssured.baseURI = "https://gemini-spring-cloud-gateway-service-release.app.singdev1.paas.fedex.com";

		String countryCode = "SG";
		String carrier = "FEDEX";
		String clearanceProcedure = "IMPORTS";
		List<String> clearanceLocation = new ArrayList<>();
		clearanceLocation.add("SIN");

		String bearerToken = generateOktaToken();

		Response response =

				given().queryParam("countryCode", countryCode).queryParam("carrier", carrier)
						.queryParam("clearanceProcedure", clearanceProcedure)
						.queryParam("clearanceLocations", clearanceLocation).header("Content-Type", "application/json")
						.header("Userid", "5430949")
						.header("Xuserrole", "gemini_broker-lead-dev_sg_sin_app83").header("Carrier", "FEDEX")
						.header("Clearanceprocedure", "IMPORTS").header("Competencyid", "9")
						.header("Authorization", bearerToken).

						when().get("/gemini/all-maintenance-service/teamRuleFetch").

						then().assertThat().statusCode(200).extract().response();

		System.out.println("Status Code: " + response.getStatusCode());
		System.out.println("Response Body: " + response.asString());
		String response_Description = getValueByJSONPath(response, "responseDescription");
		System.out.println("Response Description: " + response_Description);
	}
	
	public void verify_UserMaintenance_API() throws InterruptedException {

		RestAssured.baseURI = "https://gemini-spring-cloud-gateway-service-release.app.singdev1.paas.fedex.com";
		
		String bearerToken = generateOktaToken();
		
		Response response =

				given().queryParam("carrier", "FEDEX").queryParam("clearanceProcedure", "IMPORTS")
				.queryParam("userid", "5430949").queryParam("locations", "SIN")
				.header("Authorization", bearerToken).

						when().get("/gemini/all-maintenance-service/get-teams-for-user");
                    
                    

		System.out.println("Status Code: " + response.getStatusCode());
//		System.out.println("Response Body: " + response.asString());
//		String response_Description = getValueByJSONPath(response, "data.responseDescription");
//		System.out.println("Response Description: " + response_Description);
	}

	public static String getValueByJSONPath(Response response, String path) {
		JsonPath jsonPath = response.jsonPath();
		String value = jsonPath.getString(path);
		return value;
	}
	
	
	// Change AWB Description in restAssured 
	public void changeDescription_InRestAssured() throws InterruptedException, FileNotFoundException, IOException, ParseException {
			
		String baseURI = "https://gemini-inbound-shipment-data-service-release.app.singdev1.paas.fedex.com";
		
		String bearerToken = generateOktaToken();
		
		JSONParser jsonParser = new JSONParser();
		
		Object jsonObject = jsonParser.parse(new FileReader(System.getProperty("user.dir") + "//src//test//resources//inputJson//jsonBody.json"));
        String jsonBody = jsonObject.toString();
        
        System.out.println("Body JSON : " + jsonBody);
		
		Response response =

				given().header("Authorization", bearerToken).baseUri(baseURI)
				.body(jsonBody).header("Content-Type", "application/json").
						when().post("/import-shipment/save-shipment");

		System.out.println("Status Code of changeDescription : " + response.getStatusCode());
		//System.out.println("Response Body: " + response.asString());
		
	}
	
	
	public void postSwaggerAPI() throws FileNotFoundException, IOException, ParseException {

		String baseURI = "https://new-kafka-api-to-topic-service-release.app.singdev1.paas.fedex.com";

		JSONParser jsonParser = new JSONParser();
		Object jsonObject = jsonParser.parse(new FileReader(System.getProperty("user.dir") + "//src//test//resources//inputJson//jsonBodySwaggerProcessflow.json"));
        String jsonBody = jsonObject.toString();
		//System.out.println("Body JSON : " + jsonBody);

		Response response = RestAssured.given()
						.baseUri(baseURI)
						.body(jsonBody).header("Content-Type", "application/json").
						when().post("/postAndConsume?producerTopic=FDSVIPC.GENIUS.IMPORTS.CLEARANCE.COUNTRY&consumerTopic=FDSVIPC.GENIUS.IMPORTS.CLEARANCE.COUNTRY&messageType=application%2Fjson&waitTime=1000");

		System.out.println("Status Code of postSwagger: " + response.getStatusCode());
		//System.out.println("Response Body: " + response.asString());

	}

	
}
