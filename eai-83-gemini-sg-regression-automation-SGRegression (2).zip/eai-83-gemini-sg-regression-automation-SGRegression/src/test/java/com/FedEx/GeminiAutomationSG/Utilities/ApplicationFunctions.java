package com.FedEx.GeminiAutomationSG.Utilities;

import java.awt.AWTException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class ApplicationFunctions extends BaseClass {

	// ==================== CONSTRUCTOR ==================== //
	public ApplicationFunctions(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@FindBy(xpath = "//div[@class='fx-gn-header-logo ng-star-inserted']")
	public WebElement GEMINI_Img;

	@FindBy(xpath = "//div[@class='gn-competencies-list']")
	public WebElement competencies_Lst;

	@FindBy(xpath = "//genius-team-toggle-switch[div]//following::input//following-sibling::label/span")
	public List<WebElement> Teams_Lst_Name;
	
	@FindBy(xpath = "//genius-team-toggle-switch[div]//following::input")
	public List<WebElement> enable_team_lst;

	@FindBy(id = "tools")
	public WebElement tools_Icn;

	@FindBy(xpath = "//input[@name='filterTxtBox']")
	public static WebElement filter_TxtBx;
	
	@FindBy(xpath = "//select[@class='manageSelectfilter']")
	public WebElement filter_Dpdn;

	@FindBy(xpath = "//span//button[@class='close-icon']")
	public WebElement closeFilter_Btn;

	@FindBy(id = "add-assigntome")
	public static WebElement assignToMe_Icn;

	@FindBy(id = "userlist")
	public static WebElement userList_Icn;

	@FindBy(id = "AWB-Number-0")
	public static WebElement AWB_Number;

	@FindBy(id = "Competency-0")
	public WebElement competency_Lbl;

	@FindBy(xpath = "//button[@id='selectSchemeConfirmButton']")
	WebElement Ok_Btn;

	@FindBy(xpath = "//button[@id='confirm']")
	WebElement confirm_Btn;

	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-0']")
	public WebElement first_Toggle_Btn;

	@FindBy(id = "btnSave")
	public WebElement save_Btn;

	@FindBy(css = "div.toast-message.ng-star-inserted")
	public 	WebElement toaster_Message;

	@FindBy(xpath = "//div[@class='document-upload-conatiner']")
	WebElement upload_Icn;

	@FindBy(xpath = "//select[@name='documentType']")
	WebElement documentType_Dpdn;

	@FindBy(xpath = "//label[text()='Browse Files']")
	WebElement browseFiles_Lnk;

	@FindBy(id = "nullify_assignment")
	public WebElement Unassign_Icn;

	@FindBy(id = "logOut")
	public WebElement logOut;
	
	@FindBy(xpath = "//span[@id='AWB-Number-0']")
	public WebElement awbNumTeamlist;
	
	@FindBy(xpath = "//*[@id='userListBody']")
	public WebElement userListBody;

	// ==================== ACTION METHODS ===================//
	public void click_GEMINI_Image() {
		clickElement(GEMINI_Img);
		checkElementIsVisible(GEMINI_Img);
		clickElementUsingJavaScript(GEMINI_Img);
	}

	/**
	 * Method to select any 'Competency' from the Headers
	 * 
	 * @param competency
	 */
	public void select_Competency(String competency) {
		waitTillElementVisible(competencies_Lst);
		clickElement(competencies_Lst);
		clickElement(driver.findElement(By.xpath("//li[@id='" + competency + "']")));
	}

	/**
	 * Method to select any particular 'Team' excluding 'Default' Team
	 * 
	 * @param team
	 * @throws InterruptedException 
	 */
	public void select_Team(String team) throws InterruptedException {
		Thread.sleep(2000);
		for(int i=0;i<Teams_Lst_Name.size();i++) {
			System.out.println("Team name is :" + Teams_Lst_Name.get(i).getText());
			if(Teams_Lst_Name.get(i).getText().contains(team)) {				
				BaseClass.clickElementUsingJavaScript(driver.findElement(By.xpath("(//genius-team-toggle-switch[div]//following::input)["+i+"+1"+"]")));
				//waitTillElementVisible(driver.findElement(By.xpath("(//genius-team-toggle-switch[div]//following::input)["+i+"]")));
				System.out.println("Toggle is switched on and the element is visible now");
				break;
			}			
		}		
	}

	/**
	 * Method to click on Toggle button
	 * 
	 * @param team
	 */
	public void click_Toggle_Button(String team) {
		clickElement(driver.findElement(By.xpath("//span[contains(text(),'" + team + "')]")));
	}

	/**
	 * Method to navigate to 'Maintenance' page
	 * 
	 * @param maintenance
	 * @throws InterruptedException
	 */
	public void navigate_To_Maintenance_Page(String maintenance) throws InterruptedException {
		clickElement(tools_Icn);
		Thread.sleep(5000);
		clickElement(driver.findElement(By.xpath("//button[@id='" + maintenance + "']")));
		Thread.sleep(5000);
	}

	/**
	 * Method to select 'Filter Icon' based on 'Column Name'
	 * 
	 * @param columnName
	 * @throws InterruptedException
	 */
	public void click_Filter_Icon(String columnName) throws InterruptedException {
		Thread.sleep(3000);
		waitTillElementVisible(driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		scrollIntoViewUsingJavaScript(
				driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		clickElement(driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		Thread.sleep(3000);
	}

	/**
	 * Method to enter 'Value' in 'Filter Text Box'
	 * 
	 * @param value
	 * @throws InterruptedException
	 */
	public void set_Filter_Value(String value) throws InterruptedException {
		enterValueIntoTextField(filter_TxtBx, value);
		Thread.sleep(3000);
	}

	/**
	 * Method to select any 'Value' from the 'Filter Drop down'
	 * 
	 * @param value
	 * @throws InterruptedException
	 */
	public void set_Filter_DropdownValue(String value) throws InterruptedException {
		selectUsingVisibleText(filter_Dpdn, value);
		Thread.sleep(3000);
	}

	/**
	 * Method to close the 'Filter Icon'
	 * @throws InterruptedException 
	 */
	public void close_Filter() throws InterruptedException {
		clickElement(closeFilter_Btn);
		Thread.sleep(3000);
	}

	/**
	 * Method to select 'Multiple Shipments' from the Grid Table
	 */
	public void select_Multiple_Shipments() {
		for (int i = 0; i <= 1; i++) {
			WebElement options = driver.findElement(By.id("AWB-Number-" + i + ""));
			Actions builder = new Actions(driver);
			builder.keyDown(Keys.CONTROL).click(options).build().perform();
		}
	}

	/**
	 * Method to click on 'Assign To Me' icon
	 */
	public void click_AssignToMe_Icon() {
		clickElement(assignToMe_Icn);
	}
	

	/**
	 * Method to click on 'User List' icon
	 */
	public void click_UserList_Icon() {
		clickElement(userList_Icn);
	}

	/**
	 * Method to 'Double Click' on the Shipment
	 * 
	 * @throws InterruptedException
	 */
	public void doubleClick_Shipment() throws InterruptedException {
		scrollIntoViewUsingJavaScript(userListBody);
		Thread.sleep(2000);
		Actions act = new Actions(driver);
		//act.doubleClick(awbNumTeamlist).perform();
		
		act.doubleClick(userListBody).perform();
		Thread.sleep(1000);
	}

	/**
	 * Method to vVerify 'Toaster Message' displayed
	 * 
	 * @return
	 */
	public String verify_ToasterMessage() {
		waitTillElementVisible(toaster_Message);
		return toaster_Message.getText();
	}

	/**
	 * Method to click on 'First Toggle' button
	 */
	public void click_First_Toggle_Button() {
//		webDriverWait(first_Toggle_Btn);
//		first_Toggle_Btn.click();
		clickElement(first_Toggle_Btn);
	}

	/**
	 * Method to click on 'Save' button
	 */
	public void click_Save_Button() {
		clickElement(save_Btn);
	}

	/**
	 * Method to select 'Upload' icon from Floating Panel
	 */
	public void select_Upload_Icon_From_FloatingPanel() {
		clickElement(upload_Icn);
	}

	/**
	 * Method to select any 'Value' from the 'Document Type' drop down
	 * 
	 * @param documentType
	 * @throws AWTException
	 */
	public void select_DocumentType(String value) throws AWTException {
		zoomOutUsingRobotClass();
		selectUsingVisibleText(documentType_Dpdn, value);
	}

	/**
	 * Method to click on 'Browse Files' link
	 * 
	 * @throws InterruptedException
	 */
	public void click_BrowseFiles_Link() throws InterruptedException {
		Thread.sleep(5000);
		waitTillElementVisible(browseFiles_Lnk);
		mouseHoverAndClick(browseFiles_Lnk);
		Thread.sleep(5000);
	}

	/**
	 * Method to 'UnAssign' All the Shipments
	 * 
	 * @throws InterruptedException
	 */
	public void click_UnAssign() {
		scrollUpUsingJavaScript();
		clickElement(AWB_Number);
		List<WebElement> Rows = driver.findElements(By.xpath("//*[@class='row-index-value ng-star-inserted']"));
		for (int i = 1; i <= Rows.size(); i++) {
			clickElement(Unassign_Icn);
		}
	}

	/**
	 * Method to Logout from the Application
	 * 
	 * @throws InterruptedException
	 */
	public void clickLogoutButton() {
		waitTillElementVisible(logOut);
		scrollIntoViewUsingJavaScript(logOut);		
		clickElementUsingJavaScript(logOut);
	}

	/**
	 * Method to select 'Date' Past, Present and Future
	 * 
	 * @param dt
	 * @throws InterruptedException
	 */
	public static void select_Date(int dt) throws InterruptedException {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dtformatter = new SimpleDateFormat("d/mm/yyyy");
		Date date = new Date();
		cal.setTime(date);
		cal.add(Calendar.DATE, dt); // minus number would decrement the days
		String strDate = dtformatter.format(cal.getTime());
		String[] strdateSplit = strDate.split("/");
//		selectUsingVisibleText(selMonth, strdateSplit[1]);
//		selectUsingVisibleText(selYear, strdateSplit[2]);
		Thread.sleep(3000);
		WebElement eleDate = driver
				.findElement(By.xpath("//div[text()='" + strdateSplit[0] + "'][@class='btn-light ng-star-inserted']"));
		clickElementUsingJavaScript(eleDate);
		Thread.sleep(3000);
	}
	/**
	 * Method to select 'Filter Icon' based on 'Column Name' when not visible in screen
	 * 
	 * @param columnName
	 * @throws InterruptedException
	 */
	public void click_Filter_Icon_Hidden(String columnName) throws InterruptedException {
		Thread.sleep(3000);
		//waitTillElementVisible(driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		scrollIntoViewUsingJavaScript(
		driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		clickElement(driver.findElement(By.xpath("(//span[text()='" + columnName + "']/../..//a)[1]")));
		Thread.sleep(3000);
	}

}
