package com.FedEx.GeminiAutomationSG.Utilities;

import java.util.HashMap;

public class ScenarioContext {
private static HashMap<String, Object> scenarioContext = new HashMap<>();
	
	public static void setContext(Context key, Object value) {
	    scenarioContext.put(key.toString(), value);
	}
	public static Object getContext(Context key){
	    return scenarioContext.get(key.toString());
	}
	
	public enum Context {
		AWB, CURRENTUSER;
		
	}
}

