package com.FedEx.GeminiAutomationSG.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class ReportsPage extends BaseClass {

	// ==================== CONSTRUCTOR ==================== //
	public ReportsPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@FindBy(xpath = "//a[text()='Shipment Raw Data Report']")
	public WebElement ShipmentRawDataReport_Lnk;

	@FindBy(xpath = "//a[text()='Shipment Raw Data Report (Multiple AWB Search)']")
	public WebElement ShipmentRawDataReportMultipleAWBSearch_Lnk;

	@FindBy(xpath = "//a[text()='G7 Billing Report']")
	public WebElement G7BillingReport_Lnk;

	@FindBy(xpath = "//a[text()='High GST Verification Report']")
	public WebElement HighGSTVerificationReport_Lnk;

	@FindBy(xpath = "(//div[@class='Handle sf-element sf-element-thumb TouchTarget'])[2]")
	public WebElement FromCycleDate_Dt;

	@FindBy(xpath = "(//div[@class='Handle sf-element sf-element-thumb TouchTarget'])[1]")
	public WebElement ToCycleDate_Dt;

	@FindBy(xpath = "(//div[@class='sf-element-text-box ValueLabel'])[1]")
	public WebElement FromCycleDate_Txt;

	@FindBy(xpath = "(//div[@class='sf-element-text-box ValueLabel'])[2]")
	public WebElement ToCycleDate_Txt;

	@FindBy(xpath = "(//div[@class='sf-element-list-box-item'])[2]")
	public WebElement CycleNumber_Txt;

	@FindBy(xpath = "//div[@class='sf-element-list-box-item sfpc-selected']")
	public WebElement CycleNumber_Selected_Txt;

	@FindBy(xpath = "//font[text()='Cycle Date From:']//..//span//span//span")
	public WebElement FromCycleDate_Hdr_Txt;

	@FindBy(xpath = "//font[text()='Cycle Date To:']//..//span//span//span")
	public WebElement To_CycleDate_Hdr_Txt;

	@FindBy(xpath = "//font[text()='Cycle Number:']//..//span//span//span")
	public WebElement CycleNumber_Hdr_Txt;

	@FindBy(xpath = "//input[@value='Welcome Page']")
	public WebElement welcomePage_Lnk;

	// ==================== ACTION METHODS ===================//
	public void verify_Reports_Displayed() throws InterruptedException {
		Thread.sleep(90000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(driver.findElement(By.tagName("object"))); // Inside Document
		scrollIntoViewUsingJavaScript(HighGSTVerificationReport_Lnk);
		checkElementIsVisible(ShipmentRawDataReport_Lnk);
		checkElementIsVisible(ShipmentRawDataReportMultipleAWBSearch_Lnk);
		checkElementIsVisible(G7BillingReport_Lnk);
		checkElementIsVisible(HighGSTVerificationReport_Lnk);
	}

	public void click_G7BillingReport_Link() {
		driver.switchTo().defaultContent();
		driver.switchTo().frame(driver.findElement(By.tagName("object"))); // Inside Document
		scrollIntoViewUsingJavaScript(G7BillingReport_Lnk);
		clickElementUsingJavaScript(G7BillingReport_Lnk);
	}

	public void click_HighGSTVerification_Link() {
		driver.switchTo().defaultContent();
		driver.switchTo().frame(driver.findElement(By.tagName("object"))); // Inside Document
		scrollIntoViewUsingJavaScript(HighGSTVerificationReport_Lnk);
		clickElementUsingJavaScript(HighGSTVerificationReport_Lnk);
	}

	public void select_Date_Range() throws InterruptedException {
		Actions builder = new Actions(driver);
//   	builder.dragAndDropBy(FromCycleDate_Txt, 10, 0).perform();
		builder.dragAndDropBy(ToCycleDate_Txt, 30, 0).perform();
		Thread.sleep(20000);
	}

	public void select_CycleNumber() throws InterruptedException {
		waitTillElementVisible(CycleNumber_Txt);
		clickElement(CycleNumber_Txt);
		Thread.sleep(10000);
	}

	public String get_FromDate() {
		return FromCycleDate_Txt.getText();
	}

	public String get_ToDate() {
		return ToCycleDate_Txt.getText();
	}

	public String get_CycleNumber() {
		return CycleNumber_Selected_Txt.getText();
	}

	public String get_CycleDateFrom_HeaderText() {
		return FromCycleDate_Hdr_Txt.getText();
	}

	public String get_CycleDateTo_HeaderText() {
		return To_CycleDate_Hdr_Txt.getText();
	}

	public String get_CycleNumber_HeaderText() {
		return CycleNumber_Hdr_Txt.getText();
	}

	public void verify_Reports_Data() {
		verifyStringsAreEqual(get_FromDate(), get_CycleDateFrom_HeaderText());
		verifyStringsAreEqual(get_ToDate(), get_CycleDateTo_HeaderText());
		verifyStringsAreEqual(get_CycleNumber(), get_CycleNumber_HeaderText());
	}

	public void click_WelcomePage_Link() {
		clickElement(welcomePage_Lnk);
	}

}
