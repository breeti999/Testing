package com.FedEx.GeminiAutomationSG.PageObjects;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.*;

import org.checkerframework.checker.units.qual.m;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.interactions.Actions;
import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;
import com.FedEx.GeminiAutomationSG.Utilities.ApplicationFunctions;
import com.FedEx.GeminiAutomationSG.Utilities.ScenarioContext;
import com.FedEx.GeminiAutomationSG.Utilities.ScenarioContext.Context;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class ManifestCheckPage extends BaseClass {
	
	
	EntryBuildPage entryBuildPage = new EntryBuildPage(driver);
	GlobalSearchPage globalSearchPage = new GlobalSearchPage(driver);
	EntryBuildPage entrybuild;
	public static String AWBno = "";
	public static String shipment;
	public static String shipment1;
	public static String shipment2;
	String ClearanceLocation;
	String FailureList;
	String awbNumber;
	
	// Menaka
	public String AWBSelected;

	// ==================== CONSTRUCTOR ==================== //
	public ManifestCheckPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@CacheLookup
	// CustomerMatching
	@FindBy(id = "MANIFEST_CHECK")
	public WebElement txtManifestCheck;

	// Search User Result
	@FindBy(xpath = "//*[@id='0']")
	public WebElement searchUserResult;

	// Reassign Save
	@FindBy(xpath = "//button[@title='Save']")
	public WebElement reassignSave;

	// ACCS Shipments Radio Button
	@FindBy(xpath = "//input[@id='undefined-ACCS Shipments']//following::div")
	public static WebElement accsShipmentsRadioBtn;

	// ACSS Shipments
	@FindBy(xpath = "//*[@name='teamsToggle']/following::span[starts-with(text(),'ACCS Shipments')]")
	public static WebElement acssShipmentstoggle;

	// Assign To
	@FindBy(xpath = "//*[@id='searchWorkListForm']//following::li/a")
	public WebElement assignTo;

	// Fifth Shipment
	@FindBy(xpath = "(//*[contains(@class,'datatable-row-wrapper')])[1]")
	public WebElement fifthShipment;

	// ACSS Shipments Teamleader List
	@FindBy(xpath = "//*[starts-with(text(),' ACCS Shipments')]")
	public static WebElement acssShipmentstoggleTeamLeader;

	// ACSS Shipments
	@FindBy(xpath = "//*[@class='manageSelectfilter']")
	public WebElement selectfilter;

	// filter Clearance Scheme
	@FindBy(id = "filter-icon-6")
	public WebElement filterClearanceScheme;
	// (//*[text()='Clearance Scheme']/parent::th/following-sibling::th/span/a)[1]

	// filter Consignee Company
	@FindBy(id = "filter-icon-39")
	public WebElement filterConsigneeCompany;

	// filter AWB number
	@FindBy(id = "filter-icon-2")
	public WebElement filterAWBNUmber;

	// filter AWB number EB
	@FindBy(id = "filter-icon-1")
	public WebElement filterAWBNUmberEB;

	// Clearance Scheme 'HV'
	@FindBy(xpath = "//*[@title='HV']")
	public WebElement clearanceSchemeHV;

	// Select All sort codes
	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-all']")
	public WebElement AllSortCodes_btn;

	// Blank Cells
	@FindBy(xpath = "//*[@class='manageSelectfilter']/option[2]")
	public WebElement blankCells;

	// AWB Number
	@FindBy(xpath = "(//*[text()='AWB Number']//following::span[@class='ng-star-inserted'])[1]")
	public static WebElement AWBNumber;
	
	@FindBy(xpath = "(((//genius-data-grid-table)[1]//following::datatable-body)[1]//following::datatable-body-row)[1]/div[2]/datatable-body-cell[2]")
	public static WebElement Row_GlobalSearch;

	// AWB Number1
	@FindBy(id = "AWB-Number-1")
	public static WebElement AWBNumber1;

	// AWB Number2
	@FindBy(id = "AWB-Number-2")
	public static WebElement AWBNumber2;

	// Global Search Icon
	@FindBy(id = "fx-gn-header-search-icon")
	public static WebElement globalSearchIcon;

	// Global Search Value
	@FindBy(id = "fx-gn-shipment-search-value")
	public static WebElement globalSearchValue;

	// Global Search Button
	@FindBy(xpath = "//*[@class='shipment-result-icon search-icon mt-1 enable']")
	public static WebElement globalSearchbutton;

	// Override
	@FindBy(id = "overirde")
	public WebElement override;

	// filterTextBox
	@FindBy(xpath = "//*[@name='filterTxtBox']")
	public WebElement filterTextBox;

	// closeIcon
	@FindBy(xpath = "//*[@class='close-icon'][1]")
	public WebElement closeIcon;

	// Consignee Company
	@FindBy(xpath = "//*[text()='Consignee Company']")
	public WebElement consigneeCompany;

	// Importer Company
	@FindBy(xpath = "//*[text()='Importer Company']")
	public WebElement importerCompany;

	// Assign To Me
	@FindBy(id = "add-assigntome")
	public static WebElement assignToMe;

	// Assign To Me
	@FindBy(id = "add-assign-to")
	public static WebElement assignToMeteam;

	@FindBy(xpath = "//div[contains(@class,'page-spinner')]")
	public static WebElement pageLoaderSpinner;

	@FindBy(xpath = "//div[contains(@class,'customer-invoice-page-spinner')]")
	public static WebElement pageSpinner;

	@FindBy(xpath = "//div[contains(@class,'shipment-document-upload_header')]/span")
	public WebElement staticText_upload;
	
	// Assign To Me
	@FindBy(id = "teamlist")
	public static WebElement teamList;

	// teamleader list
	@FindBy(id = "teamleaderlist")
	public static WebElement teamleaderlist;

	// User List
	@FindBy(id = "userlist")
	public static WebElement userList;

	@FindBy(id = "teamleaderlist")
	public static WebElement teamLeaderList;

	// ITAR Flag
	@FindBy(xpath = "//*[text()='ITAR Flag']")
	public WebElement ITARFlag;

	// filter Route
	@FindBy(id = "filter-icon-24")
	public WebElement filterRoute;

	// filter Route Entry Build
	@FindBy(id = "filter-icon-14")
	public WebElement filterRouteEntryBuild;

	// Teams
	@FindBy(xpath = "//*[text()='Teams']")
	public WebElement teams;

	// Sort Message
	@FindBy(xpath = "(//li[@id='sort-communication-icon'])[2]")
	public WebElement sortMessage;

	// Sort Message in Conveyance
	@FindBy(xpath = "(//li[@id='sort-communication-icon'])[1]")
	public WebElement sortMessageConveyance;

	// Sort Message INVIC
	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-13']")
	public WebElement sortMessageINVIC;

	// Sort Message DPIA
	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-0']")
	public static WebElement sortMessageDPIA;

	// Sort Message AGRI
	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-2']")
	public WebElement sortMessageAGRI;

	// Select all shipments
	@FindBy(xpath = "//*[@for='fx-gn-data-grid-select-all-toggle-global-component']")
	public WebElement selectAllShipments;

	// Sort Message save button
	@FindBy(id = "btnSave")
	public WebElement saveButton;

	// Sort Message add button
	@FindBy(xpath = "//*[@title='Add']")
	public WebElement buttonAdd;

	// Close shipment Search
	@FindBy(xpath = "//*[@title='Close']")
	public WebElement closeshipmentsearch;

	// Selection Code
	@FindBy(id = "Selection-Codes-0")
	public static WebElement selectionCode;

	// Selection Code header
	@FindBy(xpath = "//*[text()='Selection Codes']")
	public static WebElement selectionCodeheader;

	// Clearance Location
	@FindBy(id = "Clearance-Location-0")
	public WebElement clearanceLocation;

	// MOW Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'MOW')][1]")
	public WebElement MOWtoggle;

	// Phantom Not ETD Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'Phantom NOT ETD')][1]")
	public WebElement PhantomNotETDtoggle;

	// Exception Toggle
	@FindBy(xpath = "//*[text()='Teams:']/following::span[contains(text(),'Exception')][1]")
	public WebElement Exceptiontoggle;

	// Failure List
	@FindBy(xpath = "//*[@class='failure-list']/li/pre")
	public WebElement failureList;

	@FindBy(xpath = "//div[@class='fx-gn-header-logo ng-star-inserted']")
	public WebElement imgGEMINI;

	@FindBy(xpath = "//span[contains(text(),'ACCS Shipments')]")
	private WebElement btnACCSShipmentsTeam;

	@FindBy(xpath = "//span[contains(text(),'Default')]")
	private WebElement btnDefaultShipmentsTeam;

	@FindBy(xpath = "(//span[text()='AWB Number']/../..//a)[1]")
	public WebElement filterIcon_AWBNumber;

	@FindBy(xpath = "(//span[text()='Clearance Scheme']/../..//a)[1]")
	public WebElement filterIcon_ClearanceScheme;

	@FindBy(xpath = "(//span[text()='Arrival Date']/../..//a)[1]")
	public WebElement filterIcon_ArrivalDate;

	@FindBy(xpath = "(//span[text()='CI Flag']/../..//a)[1]")
	private WebElement filterIcon_CIFlag;

	@FindBy(xpath = "//*[text()='Cage Reason Codes']")
	public WebElement filterIcon_CageReasonCodes;

	@FindBy(name = "filterTxtBox")
	public WebElement filter_SearchTextBox;

	@FindBy(name = "filterCalendar")
	public WebElement filter_CalendarTextBox;

	@FindBy(xpath = "//select[@class='manageSelectfilter']")
	public WebElement dpdn_FilterValue;

	@FindBy(xpath = "(//button[@class='close-icon'])[1]")
	public WebElement filter_CloseIcon;

	@FindBy(id = "AWB-Number-0")
	WebElement first_Row;

	@FindBy(id = "AWB-Number-1")
	WebElement second_Row;

	@FindBy(id = "AWB-Number-2")
	WebElement third_Row;

	@FindBy(css = "#teamlist")
	private WebElement lnk_TeamList;

	@FindBy(css = "#add-assigntome")
	private WebElement lnk_AssignToMe;

	@FindBy(css = "#userlist")
	private WebElement lnk_UserList;

	@FindBy(xpath = "//button[@title='Override']")
	WebElement btn_Override;

	@FindBy(xpath = "//button[@title='Modify Clearance Scheme']")
	WebElement btn_ModifyClearanceScheme;

	@FindBy(xpath = "//span[contains(text(),'HV')]")
	WebElement option_HV;

	@FindBy(xpath = "//span[contains(text(),'X-HIGH')]")
	WebElement option_XHIGH;

	@FindBy(xpath = "//button[@id='selectSchemeConfirmButton']")
	WebElement btn_Ok;

	@FindBy(xpath = "//button[@id='confirm']")
	WebElement btn_Confirm;

	@FindBy(xpath = "//div[contains(text(),'Please wait while your data is loading')]")
	WebElement txt_WaitForDataLoading;

	@FindBy(xpath = "//div[@class='visible']")
	public WebElement grid_DataTable;

	@FindBy(css = "#div.customer-invoice-page-spinner-border.ng-star-inserted")
	private WebElement icn_Spinner;

	@FindBy(xpath = "//div[@id='toast-container']/div")
	public WebElement lblPopup;

	@FindBy(css = "div.toast-message.ng-star-inserted")
	WebElement toaster_Message;

	@FindBy(xpath = "//a[@class='upload-icon']")
	WebElement btn_Upload;

	@FindBy(xpath = "//div[@class='document-upload-conatiner']")
	WebElement btn_UploadIconFloatingPanel;

	@FindBy(xpath = "//a[@class='download-icon']")
	WebElement btn_Download;

	@FindBy(css = "#fx-gn-ci-next-window-screen-icon")
	private WebElement lnk_OpenInNewTab;

	@FindBy(xpath = "//select[@name='documentType']")
	WebElement dpdn_DocumentType;

	@FindBy(xpath = "//label[text()='Browse Files']")
	WebElement lnk_BrowseFiles;

	@FindBy(xpath = "//button[@id='btnSave']")
	public WebElement btn_Save;

	@FindBy(xpath = "//span[@id='CI-Flag-0']")
	public WebElement txt_CIFlag;

	@FindBy(id = "logOut")
	WebElement btn_Logout;

	@FindBy(css = "#selected-competencies-header")
	private WebElement pageTitle;

	@FindBy(xpath = "//input[@id='fx-gn-user-team-toggle-2']")
	private WebElement btn_TeamToggle;

	@FindBy(css = "#div.customer-invoice-page-spinner-border.ng-star-inserted")
	private WebElement spinner;

	@FindBy(xpath = "//a[@id='filter-icon-2']")
	public WebElement lnk_AWBFilter;

	@FindBy(xpath = "//a[@id='filter-icon-13']")
	public WebElement lnk_CIFlag;

	@FindBy(name = "filterTxtBox")
	public WebElement txtBx_AWBSearch;

	@FindBy(xpath = "(//button[@class='close-icon'])[1]")
	public WebElement btn_AWBSearchClose;

	@FindBy(xpath = "//div[@class='visible']")
	public WebElement grd_Data;

	@FindBy(xpath = "//a[@id='fx-gn-thumnailimage-0']")
	public WebElement img_CI;

	@FindBy(xpath = "//div[@id='pageWidgetContainer1']")
	public WebElement imageViewer;

	@FindBy(xpath = "//span[text()='CI']//ancestor::div[@class='document-details ng-star-inserted']//a[starts-with(@class,'fx-gn-thumnail__doc-image')]")
	public List<WebElement> lstCIDocImage;

	@FindBy(xpath = "//a[starts-with(@class,'fx-gn-thumnail__doc-image')]")
	public List<WebElement> lstDocImages;

	@FindBy(xpath = "//button[@id='fx-gn-bti-expanded-save']")
	public WebElement fileUploadingSaveBtn;

	@FindBy(xpath = "//table[@class='header-text']//th[1]/span")
	public List<WebElement> getAllColumnNames;

	@FindBy(id = "column-preference-icon")
	public WebElement threeDotsColumnConfig;

	@FindBy(xpath = "//input[@name='columnToggle']")
	public List<WebElement> columnToggle;

	@FindBy(id = "btn-save-toggle-column-preferecne")
	public WebElement saveColumnConfig;

	@FindBy(id = "btn-cancel-toggle-column-preferecne")
	public WebElement cancelColumnConfig;

	@FindBy(id = "logOut")
	public WebElement logout;

	@FindBy(id = "okta-signin-username")
	public WebElement usernameLoginPage;

	@FindBy(xpath = "//input[@name='memberId']")
	public WebElement memberId;
	
	@FindBy(xpath = "//form//input[@type='file']")
	public WebElement btnFloatUploadBrowseFiles;

	// ==================== ACTION METHODS ===================//

	public void getAllColumnHeaderNamesVerify() throws InterruptedException {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
				getAllColumnNames.get(getAllColumnNames.size() - 1));
		Thread.sleep(3000);
		List<String> columnNames = new ArrayList<String>();
		try {
			for (WebElement columnName : getAllColumnNames) {
				if (!(columnName.getText().equals("")))
					columnNames.add(columnName.getText());
			}
			Set<String> uniqueColumnName = new HashSet<>();
			for (String str : columnNames) {
				if (!uniqueColumnName.add(str)) {
					Assert.fail();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void getAllColumnHeaderCountVerify(int expectedCount) throws InterruptedException {
		try {
			if (expectedCount != getAllColumnNames.size())
				Assert.fail();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void enableAllColumnNames() throws InterruptedException {
		try {
			threeDotsColumnConfig.click();
			Thread.sleep(3000);
			for (WebElement eachcolumnToggle : columnToggle) {
				if (!(eachcolumnToggle.isSelected()))
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", eachcolumnToggle);
			}
			saveColumnConfig.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void editCloumnConfig() throws InterruptedException {
		try {

			int i = 1;
			threeDotsColumnConfig.click();
			Thread.sleep(3000);
			for (WebElement eachcolumnToggle : columnToggle) {
				System.out.println("the for value : " + eachcolumnToggle.getText());
				if (!(eachcolumnToggle.getAttribute("id").equalsIgnoreCase("AWB Number"))) {
					if (!(eachcolumnToggle.isSelected()) && i <= 2) {
						// ((JavascriptExecutor)
						// driver).executeScript("$('eachcolumnToggle').hover();");
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", eachcolumnToggle);
						Thread.sleep(1000);
					}
					if (eachcolumnToggle.isSelected() && (i == 3 || i == 4)) {
						// ((JavascriptExecutor)
						// driver).executeScript("$('eachcolumnToggle').hover();");
						((JavascriptExecutor) driver).executeScript("arguments[0].click();", eachcolumnToggle);
						Thread.sleep(1000);
					}
				}
				if (i > 4)
					break;
				i++;
				System.out.println("the integer count for loop" + i);
			}
			saveColumnConfig.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void logout() throws InterruptedException {
		try {
			waitTillElementVisible(txtManifestCheck);
			logout.click();
			waitTillElementVisible(usernameLoginPage);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void validateSavedColumnConfig() throws InterruptedException {
		try {
			int i = 1;
			threeDotsColumnConfig.click();
			Thread.sleep(3000);
			for (WebElement eachcolumnToggle : columnToggle) {
				if (!(eachcolumnToggle.getAttribute("id").equalsIgnoreCase("AWB Number"))) {
					if (!(eachcolumnToggle.isSelected()) && i <= 2)
						Assert.fail();
					if ((eachcolumnToggle.isSelected()) && (i == 3 || i == 4))
						Assert.fail();
				}
				if (i > 4)
					break;
				i++;
			}
			cancelColumnConfig.click();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_ManifestCheck() throws InterruptedException {
		try {
			waitTillElementVisible(txtManifestCheck);
			txtManifestCheck.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void mow_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(MOWtoggle);
			MOWtoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void phantomNotETD_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(PhantomNotETDtoggle);
			PhantomNotETDtoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Exception_module() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(Exceptiontoggle);
			Exceptiontoggle.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_ClearancesLocationSIN() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(clearanceLocation);
			Thread.sleep(2000);
			ClearanceLocation = clearanceLocation.getText();
			System.out.println(ClearanceLocation);
			if (ClearanceLocation.contains("SIN")) {
				System.out.println("SIN is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_FailureReasonScans() throws InterruptedException {
		try {
			Thread.sleep(1000);
			scrollIntoViewUsingJavaScript(failureList);
			Thread.sleep(2000);
			FailureList = failureList.getText();
			System.out.println(FailureList);
			if (FailureList.contains("Scans is equal to N")) {
				System.out.println("Scans is equal to N is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_ACSSShipments() throws InterruptedException {
		try {
			// Thread.sleep(3000);
			waitTillElementVisible(acssShipmentstoggle);
			acssShipmentstoggle.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_ACSSShipmentsTeamleader() throws InterruptedException {
		try {
			waitTillElementVisible(acssShipmentstoggleTeamLeader);
			acssShipmentstoggleTeamLeader.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_FilterIconManifestCheck() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("HV");
			closeIcon.click();
			scrollByUsingJavaScript();
			scrollIntoViewUsingJavaScript(importerCompany);
			waitTillElementVisible(filterConsigneeCompany);
			filterConsigneeCompany.click();
			filterTextBox.click();
			filterTextBox.sendKeys("A");
			closeIcon.click();
			AWBNumber.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void read_shipments() throws InterruptedException {
		try {
			Thread.sleep(10000);
			waitTillElementVisible(AWBNumber);
			shipment = AWBNumber.getText();
			shipment1 = AWBNumber1.getText();
			shipment2 = AWBNumber2.getText();
			System.out.println(shipment);
			System.out.println(shipment1);
			System.out.println(shipment2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_globalSearch() throws InterruptedException {
		try {
			waitTillElementVisible(globalSearchIcon);
			globalSearchIcon.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void entervalue_globalSearch() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(globalSearchValue);
			globalSearchValue.sendKeys(shipment);
			globalSearchValue.sendKeys(",");
			globalSearchValue.sendKeys(shipment1);
			globalSearchValue.sendKeys(",");
			globalSearchValue.sendKeys(shipment2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_globalSearchButton() throws InterruptedException {
		try {
			waitTillElementVisible(globalSearchbutton);
			globalSearchbutton.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_firstshipment() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			AWBNumber.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_SortMessage() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(sortMessage);
			clickElementUsingJavaScript(sortMessage);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void assign_invicSortCodes() throws InterruptedException {
		try {
			Thread.sleep(3000);
			waitTillElementVisible(sortMessageINVIC);
			sortMessageINVIC.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_SortMessageConveyance() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(sortMessageConveyance);
			clickElementUsingJavaScript(sortMessageConveyance);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_SortDescriptionAscDes() throws InterruptedException {
		try {
			Thread.sleep(1000);
			waitTillElementVisible(EntryBuildPage.sort_sortDescription);
			clickElementUsingJavaScript(EntryBuildPage.sort_sortDescription);
			Thread.sleep(1000);
			clickElementUsingJavaScript(EntryBuildPage.sort_sortDescription);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void assign_invicSortCodes(String SortCode) throws InterruptedException {
		try {
			Thread.sleep(1000);
			EntryBuildPage.SortFilter.click();
			Thread.sleep(1000);
			EntryBuildPage.txtFloatSortFilter.sendKeys(SortCode);
			Thread.sleep(1000);
			clickElementUsingJavaScript(EntryBuildPage.firstsortMessage_btn);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Unselect_allsortcodes() throws InterruptedException {
		try {
			Thread.sleep(1000);
			clickElementUsingJavaScript(AllSortCodes_btn);
			clickElementUsingJavaScript(AllSortCodes_btn);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void save_sortCodes() throws InterruptedException {
		try {
			scrollDownUsingJavaScript();
			Thread.sleep(1000);
			waitTillElementVisible(saveButton);
			clickElementUsingJavaScript(saveButton);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_allShipmentsInGrid() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(selectAllShipments);
			selectAllShipments.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void unselect_allShipmentsInGrid() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(selectAllShipments);
			selectAllShipments.click();
			Thread.sleep(1000);
			EntryBuildPage.GlobalSearchFirstAWB.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void add_multipleSortCodes() throws InterruptedException {
		try {
			Thread.sleep(1000);
			EntryBuildPage.SortFilter.click();
			Thread.sleep(1000);
			EntryBuildPage.txtFloatSortFilter.sendKeys("SEC");
			Thread.sleep(1000);
			clickElementUsingJavaScript(EntryBuildPage.MultiplefirstsortMessage_btn);
			Thread.sleep(2000);
			EntryBuildPage.txtFloatSortFilter.clear();
			Thread.sleep(1000);
			EntryBuildPage.txtFloatSortFilter.sendKeys("TNT");
			Thread.sleep(1000);
			clickElementUsingJavaScript(EntryBuildPage.MultiplefirstsortMessage_btn);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void add_sortCodes() throws InterruptedException {
		try {
			Thread.sleep(1000);
			waitTillElementVisible(saveButton);
			clickElementUsingJavaScript(saveButton);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void add_sortCodesPopup() throws InterruptedException {
		try {
			Thread.sleep(1000);
			waitTillElementVisible(buttonAdd);
			clickElementUsingJavaScript(buttonAdd);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close_shipmentSearch() throws InterruptedException {
		try {
			Thread.sleep(2000);
			waitTillElementVisible(closeshipmentsearch);
			closeshipmentsearch.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_addedSortCodesInMC() throws InterruptedException {
		try {
			Thread.sleep(5000);
			waitTillElementVisible(acssShipmentstoggle);
			acssShipmentstoggle.click();
			Thread.sleep(10000);
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterAWBNUmber);
			filterAWBNUmber.click();
			filterTextBox.click();
			filterTextBox.sendKeys(shipment);
			closeIcon.click();
			scrollByUsingJavaScript();
			scrollIntoViewUsingJavaScript(selectionCode);
			String codes = selectionCode.getText();
			System.out.println(codes);
			String exp = "DPIA";
			if (codes.contains(exp)) {
				System.out.println("Sort codes are displayed");
			} else {
				System.out.println("Sort codes are not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_addedrandomSortCodesInMC() throws InterruptedException {
		try {
			Thread.sleep(10000);
			waitTillElementVisible(acssShipmentstoggle);
			acssShipmentstoggle.click();
			Thread.sleep(10000);
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterAWBNUmber);
			filterAWBNUmber.click();
			filterTextBox.click();
			filterTextBox.sendKeys("612814294247");
			closeIcon.click();
			scrollByUsingJavaScript();
			scrollIntoViewUsingJavaScript(selectionCode);
			String codes = selectionCode.getText();
			System.out.println(codes);
			String exp = "DPIA";
			if (codes.contains(exp)) {
				System.out.println("Sort codes are displayed");
			} else {
				System.out.println("Sort codes are not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verify_addedSortCodesInEB() throws InterruptedException {
		try {
			Thread.sleep(5000);
			waitTillElementVisible(acssShipmentstoggle);
			acssShipmentstoggle.click();
			Thread.sleep(10000);
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterAWBNUmberEB);
			filterAWBNUmberEB.click();
			filterTextBox.click();
			filterTextBox.sendKeys(shipment);
			closeIcon.click();
			scrollByUsingJavaScript();
			scrollIntoViewUsingJavaScript(selectionCode);
			String codes = selectionCode.getText();
			System.out.println(codes);
			String exp = "DPIA";
			if (codes.contains(exp)) {
				System.out.println("Sort codes are displayed");
			} else {
				System.out.println("Sort codes are not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_AssignToMe() throws InterruptedException {
		try {
			elementToBeClickable(assignToMe);
			assignToMe.click();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void click_AssignToMeTeam() throws InterruptedException {
		try {
			Thread.sleep(1000);
			elementToBeClickable(assignToMeteam);
			assignToMeteam.click();
			Thread.sleep(2000);
			int loopcnt = 20;
			// this is to handle username loading issues, Do not delete
			do {
				try {
					memberId.isDisplayed();
					break;

				} catch (NoSuchElementException e) {
					mouseHover(AWBNumber);
					System.out.print("catch");
				}
				loopcnt = loopcnt - 1;
			} while (loopcnt > 0);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void pageLoader() throws InterruptedException {
		try {
			Thread.sleep(1000);
			waitTillElementInVisible(pageLoaderSpinner, 30);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_UserList() throws InterruptedException {
		try {
			waitTillElementVisible(userList);
			userList.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_TeamleaderList() throws InterruptedException {
		try {
			waitTillElementVisible(teamleaderlist);
			teamleaderlist.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_Override() throws InterruptedException {
		try {
			AWBno = AWBNumber.getText();
			System.out.println(AWBno);
			override.click();
			Thread.sleep(2000);
			// return AWBno;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void click_FilterIconManifestCheckXhigh() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("X-HIGH");
			closeIcon.click();
			scrollDownUsingJavaScript();
			scrollIntoViewUsingJavaScript(importerCompany);
			waitTillElementVisible(filterConsigneeCompany);
			filterConsigneeCompany.click();
			filterTextBox.click();
			filterTextBox.sendKeys("A");
			closeIcon.click();
			AWBNumber.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_XhighEntryBuild() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("X-HIGH");
			closeIcon.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_FilterIconManifestCheckLVWithTruck() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("LV");
			closeIcon.click();
			Thread.sleep(3000);
			scrollDownUsingJavaScript();
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(ITARFlag);
			filterRoute.click();
			filterTextBox.click();
			filterTextBox.sendKeys("KS666");
			closeIcon.click();
			AWBNumber.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_EntryBuildLVWithTruck() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("LV");
			closeIcon.click();
			Thread.sleep(3000);
			scrollDownUsingJavaScript();
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(teams);
			filterRouteEntryBuild.click();
			filterTextBox.click();
			filterTextBox.sendKeys("KS666");
			closeIcon.click();
			AWBNumber.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_filter() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("HV");
			closeIcon.click();
			Thread.sleep(5000);
			scrollDownUsingJavaScript();
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(importerCompany);
			waitTillElementVisible(filterConsigneeCompany);
			filterConsigneeCompany.click();
			Thread.sleep(3000);
			blankCells.click();
			// selectByVisibleText(selectfilter," Blank Cells ");
			closeIcon.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_filterXHIGH() throws InterruptedException {
		try {
			waitTillElementVisible(AWBNumber);
			waitTillElementVisible(filterClearanceScheme);
			filterClearanceScheme.click();
			filterTextBox.click();
			filterTextBox.sendKeys("XHIGH");
			closeIcon.click();
			Thread.sleep(5000);
			scrollDownUsingJavaScript();
			Thread.sleep(3000);
			scrollIntoViewUsingJavaScript(importerCompany);
			waitTillElementVisible(filterConsigneeCompany);
			filterConsigneeCompany.click();
			Thread.sleep(3000);
			blankCells.click();
			// selectByVisibleText(selectfilter," Blank Cells ");
			closeIcon.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//Action Methods

	public void clickUploadButtonFromFloatingPanel() throws InterruptedException {
		try {
			Thread.sleep(5000);
			btn_UploadIconFloatingPanel.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickBrowseFiles() throws InterruptedException {
		try {
			Thread.sleep(5000);
			Actions builder = new Actions(driver);
			builder.moveToElement(lnk_BrowseFiles).click().perform();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String verifyToasterMessage() throws InterruptedException {
		waitTillElementVisible(toaster_Message);
		return toaster_Message.getText();
	}

	public String verifyCIFlagValue() throws InterruptedException {
		Thread.sleep(20000);
		waitTillElementVisible(txt_CIFlag);
		scrollIntoViewUsingJavaScript(txt_CIFlag);
		if (txt_CIFlag.getAttribute("title").equals("Y")) {
			System.out.println("CI Flag updated to : " + txt_CIFlag.getText());
		} else {
			System.out.println("CI Flag Not Updated to : " + txt_CIFlag.getText());
		}
		return txt_CIFlag.getText();
	}

	public void clickOpenInNewTabIcon() {
		try {
			waitTillElementVisible(lnk_OpenInNewTab);
			lnk_OpenInNewTab.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyShipmentIsAvailableInTheGrid() throws InterruptedException {
		try {
			waitTillElementVisible(grd_Data);
			if (grd_Data.isDisplayed()) {
				System.out.println("!!! Shipment is available in the Grid !!!");
				// waitForInvisibilityOfWebElement(spinner);
			} else {
				System.out.println("!!! Shipment is not available in the Grid !!!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String captureToasterMessage() {
		String actualMessage = null;
		try {
			if (toaster_Message.isDisplayed()) {
				actualMessage = toaster_Message.getAttribute("aria-label");
				System.out.println("Toaster Message Displayed is: " + actualMessage);
			}
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		return actualMessage;
	}

	public void searchShipment_InGlobalSearch(String awbNumbers) {
		try {
			waitTillElementVisible(globalSearchValue);
			globalSearchValue.sendKeys(awbNumbers);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void toasterMessageValidation(String expToasterMsg) throws InterruptedException {
		String strGetMsg = verifyToasterMessage();
		Assert.assertEquals(strGetMsg.trim(), expToasterMsg.trim(),
				"Toaster Message not displayed as " + expToasterMsg);
		waitForInvisibility(toaster_Message, 10);

	}

	public void waitForInvisibility(WebElement webElement, int maxSeconds) {
		Long startTime = System.currentTimeMillis();
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
			while (System.currentTimeMillis() - startTime < maxSeconds * 1000 && webElement.isDisplayed()) {
			}
		} catch (NoSuchElementException e) {
			return;
		} catch (StaleElementReferenceException e) {
			return;
		} finally {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		}
	}

	public void CIDocNoDuplicate() {
		Assert.assertTrue(lstCIDocImage.size() == 1, "CI documents duplicate images present");
	}

	public void detachedDocuments() throws InterruptedException {
		String winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		detachedView();
		Thread.sleep(2000);
		driver.close();
		driver.switchTo().window(winHandleBefore);

	}

	public void detachedView() {
		Assert.assertTrue(lstDocImages.size() >= 1, "Documents are not present in new tab");
	}

	public void clickFileUploadingSaveButton() throws InterruptedException {
		try {
			Thread.sleep(5000);
			fileUploadingSaveBtn.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ######################## Varadaraj New ########################

	// Web Elements

	@FindBy(id = "overirde")
	public WebElement override_Btn;

	@FindBy(xpath = "//button[@title='Modify Clearance Scheme']")
	WebElement modifyClearanceScheme_Btn;

	@FindBy(xpath = "//span[contains(text(),'LV')]")
	WebElement LV_Opn;

	@FindBy(xpath = "//span[contains(text(),'HV')]")
	WebElement HV_Opn;

	@FindBy(xpath = "//span[contains(text(),'X-HIGH')]")
	WebElement XHIGH_Opn;

	@FindBy(xpath = "//button[@id='selectSchemeConfirmButton']")
	WebElement Ok_Btn;

	@FindBy(xpath = "//button[@id='confirm']")
	WebElement confirm_Btn;

	@FindBy(id = "sort-communication")
	public WebElement sortMessage_Icn;

	@FindBy(id = "btnFilter")
	public WebElement selectionCode_Filter_Icn;

	@FindBy(xpath = "//input[@id='sortCd']")
	public WebElement selectionCode_Filter_TxtBx;

	@FindBy(xpath = "//*[@for='fx-gn-sort-msg-toggle-0']")
	public WebElement first_Toggle_Btn;

	@FindBy(id = "btnSave")
	public WebElement save_Btn;

	@FindBy(id = "Selection-Codes-0")
	public WebElement selectionCode_Lbl;

	@FindBy(xpath = "//span[@id='CI-Flag-0']")
	public WebElement CI_Flag_Txt;

	@FindBy(xpath = "//a[@id='userlist']")
	public WebElement userlist_Icn;

	@FindBy(id = "Competency-0")
	public WebElement competency_Lbl;

	// Action Methods
	public void click_Override_Button() throws InterruptedException {
		waitTillElementVisible(override_Btn);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(override_Btn));
		if (override_Btn.isEnabled()) {
			clickElementUsingJavaScript(override_Btn);
			Thread.sleep(3000);
		} else {
			Assert.fail("Override not enabled");
		}
		// clickElement(override_Btn);
	}

	public void click_ModifyClearanceScheme_Button() {
		clickElement(modifyClearanceScheme_Btn);
	}

	public void modify_ClearanceScheme(String clrScheme) {
		if (clrScheme.equals("LV")) {
			clickElement(LV_Opn);
			clickElement(Ok_Btn);
			clickElement(confirm_Btn);
		} else if (clrScheme.equals("HV")) {
			clickElement(HV_Opn);
			clickElement(Ok_Btn);
			clickElement(confirm_Btn);
		} else if (clrScheme.equals("X-HIGH")) {
			clickElement(XHIGH_Opn);
			clickElement(Ok_Btn);
			clickElement(confirm_Btn);
		}
	}

	public void select_SortMessage_Icon_From_FloatingPanel() {
		waitTillElementVisible(sortMessage_Icn);
		clickElementUsingJavaScript(sortMessage_Icn);
	}

	public void click_SelectionCode_Filter() {
		clickElement(selectionCode_Filter_Icn);
	}

	public void set_SelectionCode_Value(String value) {
		enterValueIntoTextField(selectionCode_Filter_TxtBx, value);
	}

	public void click_First_Toggle_Button() {
		clickElement(first_Toggle_Btn);
	}

	public void click_Save_Button() {
		clickElement(save_Btn);
	}

	public void verify_SelectionCode(String selectionCode) {
		try {
			Thread.sleep(20000);
			scrollIntoViewUsingJavaScript(selectionCode_Lbl);
			String selCode = selectionCode_Lbl.getText();
			if (selCode.contains(selectionCode)) {
				System.out.println("" + selectionCode + " is displayed");
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String verify_CIFlag_Value(String value) throws InterruptedException {
		Thread.sleep(20000);
		clickElementUsingJavaScript(userlist_Icn);
		Thread.sleep(10000);
		waitTillElementVisible(CI_Flag_Txt);
		scrollIntoViewUsingJavaScript(CI_Flag_Txt);
		if (CI_Flag_Txt.getAttribute("title").equals(value)) {
			System.out.println("CI Flag Updated to: " + CI_Flag_Txt.getText());
		} else {
			System.out.println("CI Flag Not Updated to: " + CI_Flag_Txt.getText());
		}
		return CI_Flag_Txt.getText();
	}

	public boolean verify_Shipment_Is_Not_In_ManifestCheck_Competency() throws InterruptedException {
		try {
			waitTillElementVisible(competency_Lbl);
			scrollIntoViewUsingJavaScript(competency_Lbl);
			String competency = competency_Lbl.getText();
			if (!competency.equals("Manifest Check")) {
				System.out.println("Shipment moved to '" + competency + "' Competency");
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public void selectMultipleShipmentandSaveAWB(int startNo, int n) {
		try {
			AWBSelected = "";
			Actions builder = new Actions(driver);
			// waitTillElementVisible(AWBNumber);
			int j=0;
			while(j<100)
			{
				if(documentReadyState().equalsIgnoreCase("Complete"))
						{break;}
				else {Thread.sleep(1000);}
				j++;
				System.out.print("loop");
				
			}			
			//Thread.sleep(1000);
			n = startNo + n;
			WebElement option = driver.findElement(By.id("AWB-Number-0"));
			builder.keyDown(Keys.CONTROL).click(option).build().perform();	
			Thread.sleep(1000);
			if(driver.findElement(By.xpath("//span[starts-with(@id,'AWB-Number-0')]//ancestor::datatable-body-row")).getAttribute("ng-reflect-is-selected").equals("true"))
			{
				Actions builder1 = new Actions(driver);
				builder1.keyDown(Keys.CONTROL).click(option).build().perform();
			}	
			Thread.sleep(1000);
			WebElement options;
			for (int i = startNo; i < n; i++) {
				options = driver.findElement(By.id("AWB-Number-" + i + ""));
				Thread.sleep(1000);
				AWBSelected = AWBSelected
						+ driver.findElement(By.xpath("//span[starts-with(@id,'AWB-Number-" + i + "')]/parent::span"))
								.getText().trim() + ",";
				builder.keyDown(Keys.CONTROL).click(options);
			}
			builder.build().perform();
			if(driver.findElement(By.xpath("//span[starts-with(@id,'AWB-Number-0')]//ancestor::datatable-body-row")).getAttribute("ng-reflect-is-selected").equals("false"))
			{
				Actions builder1 = new Actions(driver);
				WebElement option1 = driver.findElement(By.id("AWB-Number-0"));
				builder1.keyDown(Keys.CONTROL).click(option1).build().perform();
			}
				
		} catch (Exception e) {
			e.printStackTrace();
		}
 
	}

	public void verifyColumnValue(String ColumnName, String Value) {
		try {
			String modifiedColumnName = "";
			boolean assigned = true;
			modifiedColumnName = ColumnName.trim().replace(" ", "-");
			String byName = "//div[@class='shipment-search-result-grid']//span[starts-with(@id,'" + modifiedColumnName
					+ "')]";
			List<WebElement> lstAssignedto = driver.findElements(By.xpath(byName));
			for (WebElement eleAssigned : lstAssignedto) {
				scrollIntoViewUsingJavaScript(eleAssigned);
				if (!eleAssigned.getText().trim().equals(Value)) {
					assigned = false;
				}
			}
			Assert.assertTrue(assigned, "Few Columns not displayed with value" + Value);
			;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getAWBNoToSearch() {
		return AWBSelected;
	}

	public void click_ACCSShipmentsRadio() throws InterruptedException {
		try {
			// Thread.sleep(3000);
			waitTillElementVisible(accsShipmentsRadioBtn);
			accsShipmentsRadioBtn.click();
			Thread.sleep(2000);
			System.out.println("The ACCS Shipment radio button has been clicked..");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectMultipleShipments() throws InterruptedException {
		// Select first 5 shipments in Customer Matching (Team Leader List) - Shipment
		// Result(s)
		for (int i = 1; i <= 5; i++) {
			WebElement options = driver
					.findElement(By.xpath("(//*[contains(@id,'AWB-Number')]//ancestor::span)[" + i + "]"));
			System.out.println("AWBNumber-" + i + ": " + options.getText());
			Actions builder = new Actions(driver);
			builder.keyDown(Keys.CONTROL).click(options).build().perform();
			Thread.sleep(1000);
		}
	}

	public void click_AssignTo() throws InterruptedException {
		try {
			mouseHoverAndClick(assignTo);
			Thread.sleep(1000);
			System.out.println("Assign To got clicked");
			mouseHover(fifthShipment);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_Save() throws InterruptedException {
		try {
			elementToBeClickable(reassignSave);
			reassignSave.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_user() throws InterruptedException {
		try {
			elementToBeClickable(searchUserResult);
			searchUserResult.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void click_floatUploadBrowseFile() throws InterruptedException {
		 btnFloatUploadBrowseFiles.sendKeys(System.getProperty("user.dir") + "\\Documents\\Test.pdf");

	}

	public void checkRoundRobin(int n,String selectedUsers) {
		//3 is the number of users
		int m = n/3; //int i=0;
		try {
			String modifiedColumnName = "";
			boolean assigned = true; String failedNames="";
			String[] strAssignedTo = selectedUsers.split(",");
			HashMap<String,Integer> objMap = new HashMap<String,Integer>();
			//modifiedColumnName = "Assigned To".trim().replace(" ", "-");
			int col=0; String AssignedAWB="";
			String byCol = "//datatable-header//th//span[@class='datatable-header-cell-label draggable']";
			List<WebElement> lstAllCols = driver.findElements(By.xpath(byCol));
			for (WebElement eleAssignedToCol : lstAllCols) {
				col=col+1;
				scrollIntoViewUsingJavaScript(eleAssignedToCol);
				waitTillElementVisible(eleAssignedToCol);
				if(eleAssignedToCol.getText().equals("Assigned To")) {
					break;					
				}
			}
		
			WebElement eleAssignedTo,eleAWB;
			for (int i=1;i<=n;i++) {				
				eleAssignedTo = driver.findElement(By.xpath("((//datatable-body//datatable-body-row)["+i+"]//span[@class='ng-star-inserted'])["+col+"]"));
				eleAWB = driver.findElement(By.xpath("(//datatable-body//datatable-body-row)["+i+"]//span[starts-with(@id,'AWB-Number')]/parent::span"));
				System.out.print(i);
				if(i>n)
				{
					break;
				}
				if(objMap.containsKey(eleAssignedTo.getText()))
				{
					objMap.put(eleAssignedTo.getText(), objMap.get(eleAssignedTo.getText())+1);
					
				}
				else {
					objMap.put(eleAssignedTo.getText(), 1);
				}
				if(eleAssignedTo.getText().equals(ScenarioContext.getContext(Context.CURRENTUSER))) {
					AssignedAWB = AssignedAWB+","+eleAWB.getText().trim();
				}
				System.out.println(objMap);
			}
			System.out.print(AssignedAWB);
			ScenarioContext.setContext(Context.AWB,AssignedAWB);
			for(String names:strAssignedTo) {
				System.out.println(objMap.get(names));
				/*if(objMap.get(names)!=m)
				{
					assigned = false;
					failedNames = failedNames+objMap.get(names)+",";
				}*/
						
			}
			Assert.assertTrue(assigned,"User not assigned in Round Robin for users: "+failedNames);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public void verifySelectedShipments() {
		
		WebElement eleAWB;
		String AWBassigned = ScenarioContext.getContext(Context.AWB).toString();
		int cntAWB=0;
		waitTillElementVisible(override_Btn);
		List<WebElement> eleAWBS = driver.findElements(By.xpath("(//datatable-body//datatable-body-row)"));
		for (int i=1;i<=eleAWBS.size();i++) {				
			eleAWB = driver.findElement(By.xpath("(//datatable-body//datatable-body-row)["+i+"]//span[starts-with(@id,'AWB-Number')]//parent::span"));
			if(AWBassigned.contains(eleAWB.getText().trim())) {
				cntAWB++;
				//failedAWBs = failedAWBs+eleAWB.getText();
			}
		}
		int AWBassignedNo = AWBassigned.split(",").length-1; // -1 to eliminate last empty string
		Assert.assertTrue(AWBassignedNo==cntAWB,"Assigned Shipments not found in Userlist");	
		
	}
	

}
