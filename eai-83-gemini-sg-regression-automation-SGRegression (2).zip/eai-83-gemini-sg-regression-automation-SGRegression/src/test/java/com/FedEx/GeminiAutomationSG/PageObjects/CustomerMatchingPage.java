package com.FedEx.GeminiAutomationSG.PageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import java.util.Random;

import com.FedEx.GeminiAutomationSG.TestBase.BaseClass;

public class CustomerMatchingPage extends BaseClass {

	ManifestCheckPage manifest;
	public String randomConsigneeCompanyName;
	public String strImporterCompanyName;

	// ==================== CONSTRUCTOR ==================== //
	public CustomerMatchingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// ==================== WEB ELEMENTS ==================== //
	@CacheLookup
	// CustomerMatching
	@FindBy(xpath = "//li[@id='CUSTOMER_MATCHING']")
	public WebElement txtCustomerMatching;

	// Unassign
	@FindBy(xpath = "//*[@title='Unassign']")
	public WebElement txtUnassign;

	// Shipment Assigned Removed
	@FindBy(xpath = "//*[contains(text(),'Assignment Removed')]")
	public WebElement shipUnassignToasterMsg;

	// Shipment Assigned To User Successfully
	@FindBy(xpath = "//*[contains(text(),'Assigned To User Successfully')]")
	public WebElement shipAssignToasterMsg;

	// Assigned User ID
	@FindBy(xpath = "//*[contains(@id,'Assigned-User-ID')]")
	public WebElement txtAssignedUserIdRes;

	// UserName
	@FindBy(xpath = "//*[@class='user-name']")
	public WebElement txtUsername;

	// Assigned To
	@FindBy(xpath = "(//*[text()='Assigned To']//following::p-overlaypanel//preceding-sibling::span)[1]")
	public WebElement txtAssignedToRes;

	// Arrival Date
	@FindBy(xpath = "//*[text()='Arrival Date']")
	public WebElement txtArrivalDate;

	// Assigned To
	@FindBy(xpath = "//*[text()='Assigned To']")
	public WebElement txtAssignedTo;

	// Team Leader List
	@FindBy(xpath = "//*[@id='teamleaderlist']")
	public WebElement txtTeamLeaderList;

	// Search Consignee
	@FindBy(xpath = "//*[@title='Search Consignee']")
	public WebElement searchConsignee;

	// Create Consignee
	@FindBy(xpath = "//*[@title='Create New Consignee']")
	public WebElement CreateConsignee;

	// Compnay Name
	@FindBy(xpath = "//*[@name='companyName']")
	public WebElement companyName;

	// Go Button
	@FindBy(xpath = "//*[text()=' GO ']")
	public static WebElement GoButton;

	// Clear Button
	@FindBy(xpath = "//*[text()=' CLEAR ']")
	public WebElement ClearButton;

	// Link Importer
	@FindBy(xpath = "(//*[@title='Link Importer'])[1]")
	public WebElement linkImporter;

	// Title Importer
	@FindBy(xpath = "(//div[contains(@class,'importerDiv ng-star-inserted')])[2]")
	public WebElement Importer;

	// No Data Is Available
	@FindBy(xpath = "//*[text()='No data is available']")
	public WebElement NoDataIsAvailable;

	// Postal Code
	@FindBy(xpath = "//*[@name='zipCode']")
	public WebElement postalCode;

	// IOR
	@FindBy(xpath = "//*[@name='eori']")
	public WebElement ior;

	// Consignee
	@FindBy(xpath = "//*[text()=' Consignee ']")
	public WebElement Consignee;

	// Importer
	@FindBy(xpath = "//*[text()=' Importer ']")
	public WebElement importer;

	/****** Gomathi ******/
	// Consignee Company Name
	@FindBy(id = "fx-gn-cm-create-new-companyName")
	public WebElement consigneeCompanyNameText;

	// ContactName
	@FindBy(xpath = "//input[@name='contactName']")
	public WebElement contactName;

	// Language Pref
	@FindBy(xpath = "//select[@name='languagePreference']")
	public WebElement languagePreference;

	// Save Button
	@FindBy(id = "fx-gn-cm-create-icon")
	public WebElement saveButton;

	// Toggle Button
	@FindBy(xpath = "//input[@name='roleToggle']")
	public WebElement toggleButton;

	// Gomathi
	// Importer Company Name
	@FindBy(id = "fx-gn-importer-search-companyName")
	public WebElement importerCompanyNameText;

	@FindBy(xpath = "//a[text()='YES']")
	public WebElement saveConsgineePopup;

	// Gomathi
	// Importer Body
	@FindBy(xpath = "//div[@class='result-grid-importer__body']")
	public WebElement importerBody;

	// Gomathi
	// Link Importer
	@FindBy(xpath = "//a[@id='fx-gn-is-link-icon']")
	public WebElement linkImporterIcon;

	// Gomathi
	// ImporterCompany Name
	@FindBy(xpath = "//div[@class='result-grid-importer__header']/div/p")
	public WebElement importerCompanyName;

	// ==================== ACTION METHODS ===================//
	public void click_CustomerMatching() throws InterruptedException {
		try {
			txtCustomerMatching.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_CustomerMatchingCompetency() throws InterruptedException {
		try {
			scrollUpUsingJavaScript();
			Thread.sleep(4000);
			txtCustomerMatching.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_multipleShipments() throws InterruptedException {
		try {
			ManifestCheckPage.AWBNumber.click();
			ManifestCheckPage.assignToMe.click();
			Thread.sleep(2000);
			ManifestCheckPage.AWBNumber.click();
			ManifestCheckPage.assignToMe.click();
			Thread.sleep(2000);
			ManifestCheckPage.AWBNumber.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doubleClick_shipment() throws InterruptedException {
		try {
			Thread.sleep(4000);
			waitTillElementVisible(ManifestCheckPage.AWBNumber);
			Thread.sleep(4000);
			String javascript = "var clickEvent  = document.createEvent ('MouseEvents');\r\n"
					+ "clickEvent.initEvent ('dblclick', true, true);\r\n" + "arguments[0].dispatchEvent (clickEvent);";
			// double click on the element
			JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
			javascriptExecutor.executeScript(javascript, ManifestCheckPage.AWBNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void doubleClick_GS_shipment() throws InterruptedException {
		try {
			Thread.sleep(4000);
			waitTillElementVisible(ManifestCheckPage.Row_GlobalSearch);
			Thread.sleep(4000);
			String javascript = "var clickEvent  = document.createEvent ('MouseEvents');\r\n"
					+ "clickEvent.initEvent ('dblclick', true, true);\r\n" + "arguments[0].dispatchEvent (clickEvent);";
			// double click on the element
			JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
			javascriptExecutor.executeScript(javascript, ManifestCheckPage.Row_GlobalSearch);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doubleClick_shipmentGS() throws InterruptedException {
		try {
			Thread.sleep(4000);
			waitTillElementVisible(EntryBuildPage.GlobalSearchFirstAWB);
			Thread.sleep(4000);
			String javascript = "var clickEvent  = document.createEvent ('MouseEvents');\r\n"
					+ "clickEvent.initEvent ('dblclick', true, true);\r\n" + "arguments[0].dispatchEvent (clickEvent);";
			// double click on the element
			JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
			javascriptExecutor.executeScript(javascript, EntryBuildPage.GlobalSearchFirstAWB);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doubleClick_SecshipmentGS() throws InterruptedException {
		try {
			Thread.sleep(4000);
			waitTillElementVisible(EntryBuildPage.GlobalSearchSecondAWB);
			Thread.sleep(4000);
			String javascript = "var clickEvent  = document.createEvent ('MouseEvents');\r\n"
					+ "clickEvent.initEvent ('dblclick', true, true);\r\n" + "arguments[0].dispatchEvent (clickEvent);";
			// double click on the element
			JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
			javascriptExecutor.executeScript(javascript, EntryBuildPage.GlobalSearchSecondAWB);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Link_importer() throws InterruptedException {
		try {
			Thread.sleep(3000);
			if (CreateConsignee.isEnabled()) {
				checkElementIsVisible(searchConsignee);
				searchConsignee.click();
				ClearButton.click();
				companyName.sendKeys("a");
				GoButton.click();
				Thread.sleep(2000);
				mouseHover(Importer);
				Thread.sleep(2000);
				linkImporter.click();
				Thread.sleep(5000);
			} else {
				ClearButton.click();
				companyName.sendKeys("a");
				GoButton.click();
				Thread.sleep(2000);
				mouseHover(Importer);
				Thread.sleep(2000);
				linkImporter.click();
				Thread.sleep(150000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void text_noDataAvailable() throws InterruptedException {
		try {
			String NoDataAct = NoDataIsAvailable.getText();
			String NoDataExp = "No data is available";
			Assert.assertEquals(NoDataAct, NoDataExp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void select_shipment() throws InterruptedException {
		try {
			Thread.sleep(5000);
			waitTillElementVisible(ManifestCheckPage.AWBNumber);
			ManifestCheckPage.AWBNumber.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clear_search() throws InterruptedException {
		try {
			ClearButton.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void enter_companypostalcode() throws InterruptedException {
		try {
			companyName.sendKeys("centronics");
			ior.sendKeys("201422429H");
			postalCode.sendKeys("539212");
			GoButton.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void result_consigneeimporter() throws InterruptedException {
		try {
			waitTillElementVisible(Consignee);
			verifyElementPresent(Consignee);
			verifyElementPresent(importer);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/******** Gomathi ******/
	public void createNewConsigneeAndSameAsImporter(String toggleStatus) {

		try {
			// Random rand = new Random();
			Random rand = new Random();
			int randNumber = rand.nextInt(1000);
			String strRandNum = Integer.toString(randNumber);
			randomConsigneeCompanyName = "NewConsigneeCompany " + strRandNum;

			if (CreateConsignee.isEnabled()) {
				checkElementIsVisible(searchConsignee);
				searchConsignee.click();
			}
			companyName.clear();
			companyName.sendKeys("a");
			GoButton.click();
			Thread.sleep(10000);
			CreateConsignee.click();
			consigneeCompanyNameText.clear();
			consigneeCompanyNameText.sendKeys(randomConsigneeCompanyName);
			contactName.clear();
			contactName.sendKeys("1234567890");
			scrollDownUsingJavaScript();
			selectUsingVisibleText(languagePreference, "ENGLISH");

			if (toggleStatus.equalsIgnoreCase("Toggle On")) {
				saveButton.click();
				Thread.sleep(2000);
				scrollDownUsingJavaScript();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", saveConsgineePopup);
				// saveConsgineePopup.click();
				Thread.sleep(2000);
			} else if (toggleStatus.equalsIgnoreCase("Toggle Off")) {
//				consigneeCompanyNameText.clear();
//				consigneeCompanyNameText.sendKeys(randomConsigneeCompanyName);
//				selectUsingVisibleText(languagePreference, "ENGLISH");
				toggleButton.click();
				importerCompanyNameText.sendKeys("a");
				GoButton.click();
				Thread.sleep(20000);
				scrollDownUsingJavaScript();
				importerBody.click();
				strImporterCompanyName = importerCompanyName.getText().trim();
				linkImporterIcon.click();
				Thread.sleep(5000);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_TeamLeaderList() throws InterruptedException {
		try {
			txtTeamLeaderList.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doubleClick_ArrivalDate() throws InterruptedException {
		try {
			txtArrivalDate.click();
			txtArrivalDate.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_AssignedTo() throws InterruptedException {
		try {
			txtAssignedTo.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void text_shipmentAssignedSuccess() throws InterruptedException {
		try {
			String shipAssignToasterAct = shipAssignToasterMsg.getText().trim();
			String shipAssignToasterExp = "Shipments Assigned To User Successfully";
			Assert.assertEquals(shipAssignToasterAct, shipAssignToasterExp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click_unAssign() throws InterruptedException {
		try {
			txtUnassign.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void text_shipmentUnassignedSuccess() throws InterruptedException {
		try {
			String shipUnassignToasterAct = shipUnassignToasterMsg.getText().trim();
			String shipUnassignToasterExp = "User Assignment Removed";
			Assert.assertEquals(shipUnassignToasterAct, shipUnassignToasterExp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
