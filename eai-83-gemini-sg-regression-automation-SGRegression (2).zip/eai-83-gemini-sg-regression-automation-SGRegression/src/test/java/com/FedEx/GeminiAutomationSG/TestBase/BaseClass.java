package com.FedEx.GeminiAutomationSG.TestBase;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {	
	public static WebDriver driver;
	public static Logger log;
	public ResourceBundle resourceBundle;
	String browser;
	String url;
	String exeFilePath = System.getProperty("user.dir") + "\\Documents\\FileUpload.exe";
	String pdfFilePath = System.getProperty("user.dir") + "\\Documents\\Test.pdf";
	JavascriptExecutor js= (JavascriptExecutor)driver;

	 //@Before
	public void setUp() {
		try {
			log = LogManager.getLogger(this.getClass());
			resourceBundle = ResourceBundle.getBundle("config");
			browser = resourceBundle.getString("Browser");
			url = resourceBundle.getString("QA_URL");
			ChromeOptions options = new ChromeOptions();
//			options.addArguments("--incognito");
			options.addArguments("--remote-allow-origins=*");
			options.addArguments("--force-device-scale-factor=0.80");
			if (browser.equalsIgnoreCase("chrome")) {
				// WebDriverManager.chromedriver().clearDriverCache().setup();
				driver = WebDriverManager.chromedriver().capabilities(options).create();
				log.info("Browser Launched Successfully: " + browser);
			} else if (browser.equalsIgnoreCase("edge")) {
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				log.info("Browser Launched Successfully: " + browser);
			}
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.get(url);
			log.info("URL opened: " + url);
			driver.manage().window().maximize();
		} catch (Exception e) {
			log.error("Browser launch unsuccessful", e);
		}
	}

	// ======================= REUSABLE FUNCTIONS ======================= //

	/**
	 * Method for decoding the encrypted value to Base64 value
	 * 
	 * @param value
	 * @return
	 */
	public String decodeBase64Value(String value) {
		try {
			byte[] decoded = Base64.getDecoder().decode(value);
			String decodedValue = new String(decoded, StandardCharsets.UTF_8);
			log.info("Value was decoded successfuly");
			return decodedValue;
		} catch (Exception e) {
			log.error("Failed to decode the value", e);
			return null;
		}
	}
	
	public String encodeBase64Value(String value) {
		try {
			byte[] bytes  =value.getBytes();
			byte[] encoded = Base64.getEncoder().encode(bytes);
			String encodedValue = new String(encoded, StandardCharsets.UTF_8);
			log.info("Encoded successfully");
			return encodedValue;
		} catch (Exception e) {
			log.error("Failed to encode the value", e);
			return null;
		}
	}
	

	/**
	 * Method for entering value into Text Field
	 * 
	 * @param element
	 * @param data
	 */
	public void enterValueIntoTextField(WebElement element, String data) {
		String readyState = documentReadyState();
		try {
			if(readyState.equalsIgnoreCase("complete")) {
				try {
					waitTillElementVisible(element);
					String labelName = element.getAttribute("name");
					element.clear();
					element.sendKeys(data);
					log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
							
			} catch (NoSuchElementException e) {
				refreshWebPage();
				log.info("WebPage was not loaded properly, Hence refreshed the URL for reloading....");
				waitTillElementVisible(element);
				String labelName = element.getAttribute("name");
				element.clear();
				element.sendKeys(data);
				log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
				throw e;
			}
			catch (Exception e) {			
				log.error("Failed to enter value '" + encodeBase64Value(data) + "' into the text field'", e);
				throw e;
			}
			}
		} catch (TimeoutException ex) {
			refreshWebPage();
			log.info("Document state is not complete, Hence Refreshing...");
			waitTillElementVisible(element);
			String labelName = element.getAttribute("name");
			element.clear();
			element.sendKeys(data);
			log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
		}
		
		
		
	}
	
	public void enterValueIntoTextField1(WebElement element, String data) {
		try {
				try {
					waitTillElementVisible(element);
					String labelName = element.getAttribute("name");
					element.clear();
					element.sendKeys(data);
					log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
							
			} catch (NoSuchElementException e) {
				refreshWebPage();
				log.info("WebPage was not loaded properly, Hence refreshed the URL for reloading....");
				waitTillElementVisible(element);
				String labelName = element.getAttribute("name");
				element.clear();
				element.sendKeys(data);
				log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
				throw e;
			}
			catch (Exception e) {			
				log.error("Failed to enter value '" + encodeBase64Value(data) + "' into the text field'", e);
				throw e;
			}
			
		} catch (TimeoutException ex) {
			refreshWebPage();
			log.info("Document state is not complete, Hence Refreshing...");
			waitTillElementVisible(element);
			String labelName = element.getAttribute("name");
			element.clear();
			element.sendKeys(data);
			log.info("Entered value '" + encodeBase64Value(data) + "' into the '" + labelName + "' field");
		}
		
		
		
	}


	/**
	 * Method for clicking on WebElements such as Button, RadioButton, CheckBox,
	 * Links, etc
	 * 
	 * @param element
	 */
	public void clickElement(WebElement element) {
		try {
			waitTillElementVisible(element);
			String labelName = element.getAttribute("title");
			element.click();
			log.info("Click action performed on WebElement successfully '" + labelName + "'");
		} catch (Exception e) {
			log.error("Failed to click on Element due to some Exception", e);
		}
	}

	// ======================= WEBDRIVER WAITS ======================= //

	/**
	 * Method to wait for particular time till the Element is Visible
	 * 
	 * @param element
	 * @return
	 */
	public WebElement waitTillElementVisible(WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(element));
		} catch (TimeoutException e) {
			// e.printStackTrace();
			log.error("Element is not visible", e);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("Element is not visible", e);
		}
		return element;
	}

	/**
	 * Method to wait for particular time till the Element is Visible
	 * 
	 * @param element
	 * @param seconds
	 */
	public void waitTillElementVisible(WebElement element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	/**
	 * Method to wait for particular time till the Element is Not Visible
	 * 
	 * @param element
	 */
	public static void waitTillElementInVisible(WebElement element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		wait.until(ExpectedConditions.invisibilityOf(element));
	}

	/**
	 * Method to wait for particular time till the Element is Clickable
	 * 
	 * @param element
	 */
	public static void elementToBeClickable(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	// ======================= JAVA SCRIPT EXECUTOR ======================= //

	/**
	 * Method for clicking on WebElement using Java Script
	 * 
	 * @param element
	 */
	public static void clickElementUsingJavaScript(WebElement element) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();", element);
			log.info("Clicked o the element");
		} catch (Exception e) {
			log.error("Failed to click on Element due to some Exception", e);
			throw e;
		}
	}

	/**
	 * Method for scrolling the web page until the specific element is in View
	 */
	public static void scrollIntoViewUsingJavaScript(WebElement element) {
		try {
//			waitTillElementVisible(element);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView()", element);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error("Failed to scroll to the Element", e);
		}
	}

	/**
	 * Method for scrolling up the web page by specified pixel
	 */
	public static void scrollUpUsingJavaScript() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-2000)");
	}

	/**
	 * Method for scrolling down the web page by specified pixel
	 */
	public static void scrollDownUsingJavaScript() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,10000)");
	}

	/**
	 * Method for scrolling the document in the window by specified value
	 */
	public static void scrollByUsingJavaScript() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
	}

	// ======================= ACTION CLASS ======================= //

	/**
	 * Method for performing mouse Hover action
	 * 
	 * @param element
	 */
	public void mouseHover(WebElement element) {
		try {
			Actions builder = new Actions((driver));
			builder.moveToElement(element).build().perform();
			log.info("Mouse Hover on the WebElement Successfully");
		} catch (Exception e) {
			log.error("Failed to Mouse Hover on WebElement", e);
		}
	}

	/**
	 * Method for performing mouse Hover action and click on the WebElement
	 * 
	 * @param element
	 */
	public void mouseHoverAndClick(WebElement element) {
		try {
			Actions builder = new Actions(driver);
			builder.moveToElement(element).click().perform();
			log.info("Mouse Hover on the WebElement and performed click action Successfully");
		} catch (Exception e) {
			log.error("Fialed to Mouse Hover and click on the WebElement", e);
		}
	}

	/**
	 * Method for performing Double Click action on the WebElement
	 * 
	 * @param element
	 */
	public static void doubleClick(WebElement element) {
		try {
			Actions builder = new Actions(driver);
			builder.doubleClick(element).perform();
			log.info("Successfully performed Double Click on the WebElement");
		} catch (Exception e) {
			log.error("Failed to perform Double Click Action on the WebElement", e);
			// e.printStackTrace();
		}
	}

	/**
	 * Method for Drag and Drop actions on the WebElement
	 * 
	 * @param sourceElement
	 * @param targetElement
	 */
	public void dragAndDrop(WebElement sourceElement, WebElement targetElement) {
		try {
			Actions builder = new Actions((driver));
			builder.dragAndDrop(sourceElement, targetElement).build().perform();
			log.info("Successfully performed Drag and Drop Action on the WebElement");
		} catch (Exception e) {
			log.error("Failed to perform Drag and Drop Action on the WebElement", e);
		}
	}

	// ======================= SELECT CLASS ======================= //

	/**
	 * Method for selecting the value using Displayed Text
	 * 
	 * @param element
	 * @param text
	 */
	public void selectUsingVisibleText(WebElement element, String text) {
		try {
			waitTillElementVisible(element);
			String labelName = element.getAttribute("name");
			Select dropDown = new Select(element);
			dropDown.selectByVisibleText(text);
			log.info("Successfully selected value '" + text + "' in the '" + labelName + "' dropdown");
		} catch (Exception e) {
			log.error("Failed to select value '" + text + "' from the drop down'", e);
			// e.printStackTrace();
		}
	}

	/**
	 * Method for printing all the options available in the drop down
	 * 
	 * @param element
	 */
	public static void getOptions(WebElement element) {
		Select objSelect = new Select(element);
		List<WebElement> DropDownValues = objSelect.getOptions();
		for (WebElement options : DropDownValues) {
			// System.out.println(options.getText());
			log.info(options.getText());
		}
	}

	/**
	 * Method for retrieving the currently selected Option from the drop down
	 * 
	 * @param element
	 * @return
	 */
	public static String getFirstSelectedOption(WebElement element) {
		Select objSelect = new Select(element);
		WebElement option = objSelect.getFirstSelectedOption();
		String selectedoption = option.getText();
		// System.out.println("Selected element: " + selectedoption);
		log.info("Selected element: " + selectedoption);
		return selectedoption;
	}

	// ======================= ALERT CLASS ======================= //

	/**
	 * Method for switching to alert and accepting it
	 */
	public void acceptAlert() {
		driver.switchTo().alert().accept();
		log.info("Handled the alert successfully");
	}

	/**
	 * Method for switching to alert and rejecting it
	 */
	public void dismissAlert() {
		driver.switchTo().alert().dismiss();
		log.info("Handled the alert successfully");
	}

	/**
	 * Method for switching to alert and getting text
	 */
	public String getAlertText() {
		String text = driver.switchTo().alert().getText();
		return text;
	}

	// ======================= VERIFICATION ======================= //

	/**
	 * Method for verifying the element is Visible
	 * 
	 * @param element
	 */
	public void verifyElementPresent(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			log.info(element + "was found");
		} catch (Exception e) {
			log.error("Unable to find the element" + element + ":" + e);
		}
	}

	/**
	 * Method for verifying the element is Visible and returning true or false
	 * 
	 * @param element
	 * @return
	 */
	public static boolean checkElementIsVisible(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(element));
		return element.isDisplayed();
	}

	/**
	 * Method for validating the element is Editable
	 * 
	 * @param element
	 */
	public static void Enabled(WebElement element) {
		Assert.assertEquals(true, element.isEnabled(), "Element is not editable");
		Assert.assertEquals(true, element.isDisplayed(), "Element is not Displayed");
	}

	/**
	 * Method for validating the element is Non-Editable
	 * 
	 * @param element
	 */
	public static void NonEditable(WebElement element) {
		String readonly = element.getAttribute("readonly");
		Assert.assertNull(readonly, "Text field is Editable");
	}

	/**
	 * Method for verifying if 2 Strings are equal
	 * 
	 * @param firstString
	 * @param secondString
	 */
	public static void verifyStringsAreEqual(String firstString, String secondString) {
		log.info(firstString + "<equals>" + secondString);
		Assert.assertEquals(firstString, secondString);
	}

	// ======================= ROBOT CLASS ======================= //

	/**
	 * Method for performing Zoom Out Action using Robot Class
	 * 
	 * @throws AWTException
	 */
	public static void zoomOutUsingRobotClass() throws AWTException {
		Robot robot = new Robot();
		for (int i = 1; i <= 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_MINUS);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_MINUS);
		}
	}

	/**
	 * Method to 'Upload File' using 'Robot Class'
	 * 
	 * @param filePath
	 * @throws AWTException
	 */
	public void uploadFileUsingRobotClass(String filePath) throws AWTException {
		StringSelection stringSelection = new StringSelection(filePath);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
		Robot robot;
		try {
			robot = new Robot();
			robot.delay(3000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.delay(3000);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			robot.delay(3000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(3000);
			System.out.println("!!! Document Uploaded Successfully !!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ======================= AUTO IT ======================= //

	/**
	 * Method to 'Upload File' using 'Auto IT'
	 * 
	 * @throws IOException
	 */
	public void uploadFileUsingAutoIT() throws IOException {
		try {
			Runtime.getRuntime().exec(exeFilePath + " " + pdfFilePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// @After
	public static void tearDown() {
		driver.quit();
	}

	public String captureScreenshot(String scenarioName) throws IOException {
		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "\\screenshots\\" + scenarioName + "_" + timeStamp
				+ ".png";
		try {
			FileUtils.copyFile(source, new File(destination));
		} catch (Exception e) {
			e.getMessage();
		}
		return destination;
	}

	public static byte[] getByteScreenshot() throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		byte[] fileContent = FileUtils.readFileToByteArray(src);
		return fileContent;
	}
	
	/**
	 * Method to check the value in dropdown
	 * 
	 * @param eleSelectParam
	 * @param Value
	 * @throws InterruptedException
	 */
	public static boolean value_In_Dropdown(WebElement eleSelectParam, String Value) throws InterruptedException {
		Select eleSelect = new Select(eleSelectParam);
		List<WebElement> eleOptions = eleSelect.getOptions();
		for(WebElement eleOption:eleOptions)
		{
			if(eleOption.getText().trim().equals(Value)) {
				return true;
			}
		}
		return false;
		
	}
	
	public void refreshWebPage() {
		driver.navigate().refresh();		
	}
	
	public  String documentReadyState() {
		return (String) js.executeScript("return document.readyState");
		
	}	
	

}
