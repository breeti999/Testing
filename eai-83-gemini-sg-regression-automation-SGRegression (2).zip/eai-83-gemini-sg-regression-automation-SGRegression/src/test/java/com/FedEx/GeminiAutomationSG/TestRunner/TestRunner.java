package com.FedEx.GeminiAutomationSG.TestRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"Features"},

		glue = "stepDefinitions", stepNotifications = true, plugin = { "pretty", "html:test-output/myreport.html",
				"json:test-output/myreport.json",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", },
		tags = "@CICD", dryRun = false, monochrome = true)

public class TestRunner {

	
}
